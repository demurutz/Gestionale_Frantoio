@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Installa Node.js 24 e riapri questo file.
 pause
 exit /b 1
)
if not exist "node_modules\.modules.yaml" (
 call npx --yes pnpm@11.19.0 install --frozen-lockfile
 if errorlevel 1 (
  pause
  exit /b 1
 )
)
node scripts/local.mjs start
pause
