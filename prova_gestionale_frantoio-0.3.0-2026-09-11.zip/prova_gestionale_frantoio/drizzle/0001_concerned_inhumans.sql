CREATE TABLE `containers` (
	`id` text PRIMARY KEY NOT NULL,
	`facility_id` text NOT NULL,
	`code` text NOT NULL,
	`capacity_g` integer NOT NULL,
	FOREIGN KEY (`facility_id`) REFERENCES `facilities`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_container_code` ON `containers` (`facility_id`,`code`);--> statement-breakpoint
CREATE TABLE `events` (
	`seq` integer PRIMARY KEY NOT NULL,
	`id` text NOT NULL,
	`action` text NOT NULL,
	`date` text NOT NULL,
	`created_at` text NOT NULL,
	`payload_json` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `events_id_unique` ON `events` (`id`);--> statement-breakpoint
CREATE TABLE `facilities` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`sian_code` text DEFAULT '' NOT NULL,
	`cuaa` text DEFAULT '' NOT NULL,
	`address` text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE `oil_lots` (
	`id` text PRIMARY KEY NOT NULL,
	`label` text NOT NULL,
	`batch_id` integer,
	`date` text NOT NULL,
	`ownership` text NOT NULL,
	`owner_id` text,
	`supplier_id` text,
	`source` text NOT NULL,
	`quality` text NOT NULL,
	`designation` text DEFAULT '' NOT NULL,
	`origin` text NOT NULL,
	`category` text NOT NULL,
	FOREIGN KEY (`batch_id`) REFERENCES `batches`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`owner_id`) REFERENCES `producers`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`supplier_id`) REFERENCES `producers`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_lot_batch` ON `oil_lots` (`batch_id`);--> statement-breakpoint
CREATE TABLE `oil_stocks` (
	`id` text PRIMARY KEY NOT NULL,
	`lot_id` text NOT NULL,
	`container_id` text NOT NULL,
	`amount_g` integer NOT NULL,
	FOREIGN KEY (`lot_id`) REFERENCES `oil_lots`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`container_id`) REFERENCES `containers`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_stock_lot_container` ON `oil_stocks` (`lot_id`,`container_id`);--> statement-breakpoint
CREATE TABLE `packages` (
	`id` text PRIMARY KEY NOT NULL,
	`lot_id` text NOT NULL,
	`facility_id` text NOT NULL,
	`code` text NOT NULL,
	`date` text NOT NULL,
	`unit_ml` integer NOT NULL,
	`initial_units` integer NOT NULL,
	`units` integer NOT NULL,
	`consumed_g` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`lot_id`) REFERENCES `oil_lots`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`facility_id`) REFERENCES `facilities`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `sales` (
	`id` text PRIMARY KEY NOT NULL,
	`package_id` text NOT NULL,
	`customer_id` text NOT NULL,
	`date` text NOT NULL,
	`units` integer NOT NULL,
	`document` text NOT NULL,
	`document_date` text NOT NULL,
	FOREIGN KEY (`package_id`) REFERENCES `packages`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`customer_id`) REFERENCES `producers`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
ALTER TABLE `batches` ADD `facility_id` text REFERENCES facilities(id);--> statement-breakpoint
ALTER TABLE `batches` ADD `olive_source` text DEFAULT 'unknown' NOT NULL;--> statement-breakpoint
ALTER TABLE `batches` ADD `quality` text DEFAULT 'unknown' NOT NULL;--> statement-breakpoint
ALTER TABLE `batches` ADD `designation` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `batches` ADD `document` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `batches` ADD `document_date` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `producers` ADD `fiscal_id` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `producers` ADD `address` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `producers` ADD `country` text DEFAULT 'IT' NOT NULL;