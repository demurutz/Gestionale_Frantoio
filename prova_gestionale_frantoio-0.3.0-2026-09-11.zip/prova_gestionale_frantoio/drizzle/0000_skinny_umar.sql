CREATE TABLE `batches` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`request_id` text NOT NULL,
	`producer_id` text NOT NULL,
	`date` text NOT NULL,
	`variety` text NOT NULL,
	`origin` text NOT NULL,
	`gross_g` integer NOT NULL,
	`tare_g` integer NOT NULL,
	`net_g` integer NOT NULL,
	`status` text DEFAULT 'waiting' NOT NULL,
	`oil_g` integer DEFAULT 0 NOT NULL,
	`tank` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`last_request` text DEFAULT '' NOT NULL,
	`started_at` text,
	`completed_at` text,
	FOREIGN KEY (`producer_id`) REFERENCES `producers`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `batches_request_id_unique` ON `batches` (`request_id`);--> statement-breakpoint
CREATE INDEX `idx_batches_producer` ON `batches` (`producer_id`);--> statement-breakpoint
CREATE INDEX `idx_batches_date` ON `batches` (`date`);--> statement-breakpoint
CREATE TABLE `deliveries` (
	`id` text PRIMARY KEY NOT NULL,
	`batch_id` integer NOT NULL,
	`amount_g` integer NOT NULL,
	`date` text NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`batch_id`) REFERENCES `batches`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_deliveries_batch` ON `deliveries` (`batch_id`);--> statement-breakpoint
CREATE TABLE `producers` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`city` text NOT NULL,
	`phone` text DEFAULT '' NOT NULL
);
