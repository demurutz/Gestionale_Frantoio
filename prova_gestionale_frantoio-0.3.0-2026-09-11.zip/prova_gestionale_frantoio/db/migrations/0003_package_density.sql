ALTER TABLE packages ADD COLUMN density_g_l integer CHECK(density_g_l BETWEEN 1 AND 10000);
