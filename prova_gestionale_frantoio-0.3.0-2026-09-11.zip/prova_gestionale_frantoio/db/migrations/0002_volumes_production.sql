ALTER TABLE containers ADD COLUMN capacity_ml integer CHECK(capacity_ml > 0);
ALTER TABLE containers DROP CONSTRAINT containers_capacity_g_check;
ALTER TABLE containers ADD CHECK(capacity_g >= 0 AND (capacity_g > 0 OR capacity_ml IS NOT NULL));
ALTER TABLE oil_stocks ADD COLUMN amount_ml integer CHECK(amount_ml >= 0);
ALTER TABLE batches ADD COLUMN oil_ml integer CHECK(oil_ml >= 0);
ALTER TABLE batches ADD COLUMN pomace_g integer CHECK(pomace_g >= 0);
ALTER TABLE batches ADD COLUMN wastewater_ml integer CHECK(wastewater_ml >= 0);
ALTER TABLE batches ADD COLUMN production_date text NOT NULL DEFAULT '';
UPDATE batches b SET production_date = e.date FROM events e
 WHERE b.tenant_id=e.tenant_id AND e.action='batch.complete'
 AND (e.payload_json::jsonb->>'batch_id')=b.id::text;
ALTER TABLE deliveries ADD COLUMN amount_ml integer CHECK(amount_ml > 0);
ALTER TABLE deliveries DROP CONSTRAINT deliveries_amount_g_check;
ALTER TABLE deliveries ADD CHECK(amount_g >= 0 AND (amount_g > 0 OR amount_ml IS NOT NULL));
CREATE TABLE packaging_formats (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL,
 name text NOT NULL, capacity_ml integer NOT NULL CHECK(capacity_ml BETWEEN 1 AND 1000000),
 active boolean NOT NULL DEFAULT true,
 PRIMARY KEY(tenant_id,id), UNIQUE(tenant_id,name)
);
ALTER TABLE packaging_formats ENABLE ROW LEVEL SECURITY;
ALTER TABLE packaging_formats FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON packaging_formats
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT,INSERT,UPDATE ON packaging_formats TO frantoio_app;
ALTER TABLE packages ADD COLUMN format_id text;
ALTER TABLE packages ADD COLUMN format_name text NOT NULL DEFAULT '';
ALTER TABLE packages ADD COLUMN consumed_ml integer CHECK(consumed_ml >= 0);
ALTER TABLE packages ADD FOREIGN KEY(tenant_id,format_id) REFERENCES packaging_formats(tenant_id,id);
ALTER TABLE packages DROP CONSTRAINT packages_unit_ml_check;
ALTER TABLE packages ADD CHECK(unit_ml BETWEEN 1 AND 1000000);
