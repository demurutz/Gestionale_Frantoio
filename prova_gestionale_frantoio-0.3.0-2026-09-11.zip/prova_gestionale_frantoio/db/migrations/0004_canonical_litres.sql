-- Unica quantità operativa: millilitri. Densità convenzionale richiesta: 0,916 kg/L.
-- I campi kg e gli eventi originari vengono conservati, senza riscrivere il giornale.
UPDATE containers SET capacity_ml=round(capacity_g::numeric*1000/916)::integer WHERE capacity_ml IS NULL;
UPDATE oil_stocks SET amount_ml=round(amount_g::numeric*1000/916)::integer WHERE amount_ml IS NULL;
UPDATE batches SET oil_ml=round(oil_g::numeric*1000/916)::integer WHERE oil_ml IS NULL AND status='done';
UPDATE deliveries SET amount_ml=round(amount_g::numeric*1000/916)::integer WHERE amount_ml IS NULL;
UPDATE packages SET consumed_ml=round(consumed_g::numeric*1000/916)::integer WHERE consumed_ml IS NULL;
UPDATE packages SET density_g_l=916 WHERE density_g_l IS NULL AND consumed_ml>0;
