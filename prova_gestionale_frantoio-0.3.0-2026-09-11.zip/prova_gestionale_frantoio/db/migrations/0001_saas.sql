CREATE TABLE companies (
 id uuid PRIMARY KEY, name text NOT NULL, fiscal_id text NOT NULL DEFAULT '',
 address text NOT NULL DEFAULT '', active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE users (
 id uuid PRIMARY KEY, email text NOT NULL UNIQUE CHECK(email=lower(email)),
 name text NOT NULL, password_hash text NOT NULL, active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE memberships (
 company_id uuid NOT NULL REFERENCES companies(id), user_id uuid NOT NULL REFERENCES users(id),
 role text NOT NULL CHECK(role IN ('admin','operator','viewer')),
 active boolean NOT NULL DEFAULT true, PRIMARY KEY(company_id,user_id)
);
CREATE TABLE sessions (
 token_hash text PRIMARY KEY, user_id uuid NOT NULL REFERENCES users(id),
 csrf_token text NOT NULL, expires_at timestamptz NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sessions_expiry ON sessions(expires_at);
CREATE TABLE login_attempts (
 key text PRIMARY KEY, attempts integer NOT NULL, expires_at timestamptz NOT NULL
);
CREATE TABLE security_events (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 company_id uuid REFERENCES companies(id), actor_id uuid REFERENCES users(id),
 action text NOT NULL, details jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE producers (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL, name text NOT NULL,
 city text NOT NULL, phone text NOT NULL DEFAULT '', fiscal_id text NOT NULL DEFAULT '',
 address text NOT NULL DEFAULT '', country text NOT NULL DEFAULT 'IT', PRIMARY KEY(tenant_id,id)
);
CREATE TABLE facilities (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL, name text NOT NULL,
 sian_code text NOT NULL DEFAULT '', cuaa text NOT NULL DEFAULT '', address text NOT NULL DEFAULT '',
 PRIMARY KEY(tenant_id,id)
);
CREATE TABLE containers (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL, facility_id text NOT NULL,
 code text NOT NULL, capacity_g integer NOT NULL CHECK(capacity_g>0),
 PRIMARY KEY(tenant_id,id), UNIQUE(tenant_id,facility_id,code),
 FOREIGN KEY(tenant_id,facility_id) REFERENCES facilities(tenant_id,id)
);
CREATE TABLE batches (
 tenant_id uuid NOT NULL REFERENCES companies(id), id integer NOT NULL CHECK(id>0),
 request_id text NOT NULL, producer_id text NOT NULL, date text NOT NULL, variety text NOT NULL,
 origin text NOT NULL, gross_g integer NOT NULL CHECK(gross_g>0), tare_g integer NOT NULL CHECK(tare_g>=0),
 net_g integer NOT NULL CHECK(net_g=gross_g-tare_g AND net_g>0),
 status text NOT NULL CHECK(status IN ('waiting','working','done')),
 oil_g integer NOT NULL DEFAULT 0 CHECK(oil_g>=0 AND oil_g<=net_g),
 tank text NOT NULL DEFAULT '', notes text NOT NULL DEFAULT '', revision integer NOT NULL DEFAULT 0,
 last_request text NOT NULL DEFAULT '', started_at text, completed_at text, facility_id text,
 olive_source text NOT NULL, quality text NOT NULL, designation text NOT NULL DEFAULT '',
 document text NOT NULL DEFAULT '', document_date text NOT NULL DEFAULT '',
 PRIMARY KEY(tenant_id,id), UNIQUE(tenant_id,request_id),
 FOREIGN KEY(tenant_id,producer_id) REFERENCES producers(tenant_id,id),
 FOREIGN KEY(tenant_id,facility_id) REFERENCES facilities(tenant_id,id)
);
CREATE TABLE deliveries (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL, batch_id integer NOT NULL,
 amount_g integer NOT NULL CHECK(amount_g>0), date text NOT NULL, note text NOT NULL DEFAULT '',
 created_at text NOT NULL, PRIMARY KEY(tenant_id,id),
 FOREIGN KEY(tenant_id,batch_id) REFERENCES batches(tenant_id,id)
);
CREATE TABLE oil_lots (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL, label text NOT NULL,
 batch_id integer, date text NOT NULL, ownership text NOT NULL CHECK(ownership IN ('own','third_party')),
 owner_id text, supplier_id text, source text NOT NULL, quality text NOT NULL, designation text NOT NULL DEFAULT '',
 origin text NOT NULL, category text NOT NULL CHECK(category IN ('pending','extra','virgin','lampante')),
 PRIMARY KEY(tenant_id,id), UNIQUE(tenant_id,batch_id),
 CHECK((ownership='third_party' AND owner_id IS NOT NULL) OR (ownership='own' AND owner_id IS NULL)),
 FOREIGN KEY(tenant_id,batch_id) REFERENCES batches(tenant_id,id),
 FOREIGN KEY(tenant_id,owner_id) REFERENCES producers(tenant_id,id),
 FOREIGN KEY(tenant_id,supplier_id) REFERENCES producers(tenant_id,id)
);
CREATE TABLE oil_stocks (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL, lot_id text NOT NULL,
 container_id text NOT NULL, amount_g integer NOT NULL CHECK(amount_g>=0),
 PRIMARY KEY(tenant_id,id), UNIQUE(tenant_id,lot_id,container_id),
 FOREIGN KEY(tenant_id,lot_id) REFERENCES oil_lots(tenant_id,id),
 FOREIGN KEY(tenant_id,container_id) REFERENCES containers(tenant_id,id)
);
CREATE TABLE packages (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL, lot_id text NOT NULL,
 facility_id text NOT NULL, code text NOT NULL, date text NOT NULL,
 unit_ml integer NOT NULL CHECK(unit_ml BETWEEN 1 AND 5000),
 initial_units integer NOT NULL CHECK(initial_units>0), units integer NOT NULL CHECK(units>=0 AND units<=initial_units),
 consumed_g integer NOT NULL DEFAULT 0 CHECK(consumed_g>=0),
 PRIMARY KEY(tenant_id,id), UNIQUE(tenant_id,facility_id,code),
 FOREIGN KEY(tenant_id,lot_id) REFERENCES oil_lots(tenant_id,id),
 FOREIGN KEY(tenant_id,facility_id) REFERENCES facilities(tenant_id,id)
);
CREATE TABLE sales (
 tenant_id uuid NOT NULL REFERENCES companies(id), id text NOT NULL, package_id text NOT NULL,
 customer_id text NOT NULL, date text NOT NULL, units integer NOT NULL CHECK(units>0),
 document text NOT NULL, document_date text NOT NULL, PRIMARY KEY(tenant_id,id),
 FOREIGN KEY(tenant_id,package_id) REFERENCES packages(tenant_id,id),
 FOREIGN KEY(tenant_id,customer_id) REFERENCES producers(tenant_id,id)
);
CREATE TABLE events (
 tenant_id uuid NOT NULL REFERENCES companies(id), seq integer NOT NULL CHECK(seq>0), id text NOT NULL,
 action text NOT NULL, date text NOT NULL, created_at text NOT NULL, payload_json text NOT NULL,
 actor_id uuid REFERENCES users(id), PRIMARY KEY(tenant_id,seq), UNIQUE(tenant_id,id)
);
CREATE INDEX batches_company_date ON batches(tenant_id,date);
CREATE INDEX stocks_company_container ON oil_stocks(tenant_id,container_id);
CREATE INDEX members_user ON memberships(user_id);
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO frantoio_app;
GRANT SELECT, INSERT, UPDATE ON companies, users, memberships, login_attempts TO frantoio_app;
GRANT SELECT, INSERT, DELETE ON sessions TO frantoio_app;
GRANT SELECT, INSERT ON security_events TO frantoio_app;
GRANT USAGE ON SEQUENCE security_events_id_seq TO frantoio_app;
ALTER TABLE producers ENABLE ROW LEVEL SECURITY;
ALTER TABLE producers FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON producers
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON producers TO frantoio_app;
ALTER TABLE facilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE facilities FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON facilities
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON facilities TO frantoio_app;
ALTER TABLE containers ENABLE ROW LEVEL SECURITY;
ALTER TABLE containers FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON containers
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON containers TO frantoio_app;
ALTER TABLE batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE batches FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON batches
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON batches TO frantoio_app;
ALTER TABLE deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE deliveries FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON deliveries
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON deliveries TO frantoio_app;
ALTER TABLE oil_lots ENABLE ROW LEVEL SECURITY;
ALTER TABLE oil_lots FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON oil_lots
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON oil_lots TO frantoio_app;
ALTER TABLE oil_stocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE oil_stocks FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON oil_stocks
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON oil_stocks TO frantoio_app;
ALTER TABLE packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE packages FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON packages
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON packages TO frantoio_app;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON sales
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT, UPDATE ON sales TO frantoio_app;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE events FORCE ROW LEVEL SECURITY;
CREATE POLICY company_isolation ON events
 USING (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid)
 WITH CHECK (tenant_id = nullif(current_setting('app.tenant_id',true),'')::uuid);
GRANT SELECT, INSERT ON events TO frantoio_app;
