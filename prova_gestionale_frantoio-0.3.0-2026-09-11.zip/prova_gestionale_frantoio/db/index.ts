import pg from 'pg';
import type { PoolClient } from 'pg';
import { config } from '../lib/config.ts';
import { InputError } from '../lib/domain.ts';
import type { Role } from '../lib/access.ts';
export type Store = { client: PoolClient; tenantId: string; actorId: string };
const globals = globalThis as typeof globalThis & { frantoioPool?: pg.Pool };
export function pool() {
  if (!globals.frantoioPool) {
    globals.frantoioPool = new pg.Pool({
      connectionString: config().databaseUrl,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
      statement_timeout: 15000,
      ssl:
        process.env.DATABASE_SSL === 'true'
          ? { rejectUnauthorized: true }
          : false,
    });
    globals.frantoioPool.on('error', () =>
      console.error('Connessione PostgreSQL interrotta.'),
    );
  }
  return globals.frantoioPool;
}
export async function transaction<T>(
  work: (client: PoolClient) => Promise<T>,
  readOnly = false,
): Promise<T> {
  const client = await pool().connect();
  try {
    const role = await client.query(
      'SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname=current_user',
    );
    if (role.rows[0]?.rolsuper || role.rows[0]?.rolbypassrls)
      throw new Error(
        'Il server web richiede un utente PostgreSQL senza privilegi amministrativi.',
      );
    await client.query(
      readOnly ? 'BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY' : 'BEGIN',
    );
    const result = await work(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}
export async function companyTransaction<T>(
  userId: string,
  tenantId: string,
  write: boolean,
  work: (store: Store, role: Role) => Promise<T>,
): Promise<T> {
  if (!/^[0-9a-f-]{36}$/i.test(tenantId))
    throw new InputError('Seleziona un’azienda autorizzata.', 403);
  return transaction(async (client) => {
    // All writers lock the company BEFORE reading inventory. Other companies remain independent.
    const company = await client.query(
      'SELECT id FROM companies WHERE id=$1 AND active=true' +
        (write ? ' FOR UPDATE' : ''),
      [tenantId],
    );
    const member = await client.query(
      'SELECT m.role FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.company_id=$1 AND m.user_id=$2 AND m.active AND u.active',
      [tenantId, userId],
    );
    if (!company.rowCount || !member.rowCount)
      throw new InputError('Azienda non accessibile.', 403);
    await client.query("SELECT set_config('app.tenant_id',$1,true)", [
      tenantId,
    ]);
    return work(
      { client, tenantId, actorId: userId },
      member.rows[0].role as Role,
    );
  }, !write);
}
