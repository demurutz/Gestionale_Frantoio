import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { registerHooks } from 'node:module';
import { existsSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { archive, write, readData } from './archive-helper.mjs';
import { pool, companyTransaction } from '../db/index.ts';
import { hashPassword, verifyPassword, login, identity } from '../lib/auth.ts';
import { actionLabels } from '../lib/domain.ts';
registerHooks({
  resolve(specifier, context, next) {
    if (specifier.startsWith('@/')) {
      const base = new URL('../' + specifier.slice(2), import.meta.url);
      return next(
        existsSync(new URL(base.href + '.ts'))
          ? base.href + '.ts'
          : base.href + '/index.ts',
        context,
      );
    }
    return next(specifier, context);
  },
});
const api = await import('../app/api/frantoio/route.ts');
const auth = await import('../app/api/auth/[action]/route.ts');
const company = await import('../app/api/company/route.ts');
const exportApi = await import('../app/api/frantoio/export/route.ts');
const origin = process.env.APP_ORIGIN,
  password = 'Password di prova 2026!';
const producer = {
  action: 'producer.create',
  requestId: 'shared-request-id',
  name: 'Cliente azienda A',
  city: 'Bitonto',
  date: '2026-09-09',
};
after(async () => {
  await pool().end();
});
void test('password: gli spazi fanno parte della password e non vengono rimossi al login', async () => {
  const a = await archive();
  try {
    const exact = '  Password con spazi 2026!  ';
    await a.client.query('UPDATE users SET password_hash=$1 WHERE id=$2', [
      await hashPassword(exact),
      a.db.actorId,
    ]);
    const email = a.db.actorId + '@test.invalid';
    assert.match(await login(email, exact), /^[0-9a-f]{64}$/);
    await assert.rejects(
      login(email, exact.trim()),
      /Email o password non valide/,
    );
  } finally {
    await a.close();
  }
});
const context = (action) => ({ params: Promise.resolve({ action }) });
function request(
  path,
  {
    method = 'GET',
    token = '',
    csrf = '',
    tenant = '',
    body,
    headers = {},
  } = {},
) {
  return new Request(origin + path, {
    method,
    headers: {
      ...(token ? { cookie: 'frantoio_session=' + token } : {}),
      ...(tenant ? { 'X-Company-Id': tenant } : {}),
      ...(method === 'POST'
        ? {
            Origin: origin,
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrf,
          }
        : {}),
      ...headers,
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
}
async function session(a) {
  const email = a.db.actorId + '@test.invalid';
  await a.client.query('UPDATE users SET password_hash=$1 WHERE id=$2', [
    await hashPassword(password),
    a.db.actorId,
  ]);
  const response = await auth.POST(
    request('/api/auth/login', { method: 'POST', body: { email, password } }),
    context('login'),
  );
  assert.equal(response.status, 200);
  const cookie = response.headers.get('set-cookie');
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Lax/);
  assert.doesNotMatch(cookie, /Domain=/);
  const token = cookie.match(/frantoio_session=([^;]+)/)[1],
    user = await identity(request('/', { token }));
  return { token, csrf: user.csrf, tenant: a.db.tenantId };
}
async function fixture(fn) {
  const a = await archive();
  try {
    await fn(a);
  } finally {
    await a.close();
  }
}
void test('password: hash salato, verifica e limiti', async () => {
  const hash = await hashPassword(password);
  assert.notEqual(hash, await hashPassword(password));
  assert.equal(await verifyPassword(password, hash), true);
  assert.equal(await verifyPassword('errata', hash), false);
  await assert.rejects(() => hashPassword('corta'));
});
void test('API: senza sessione nessuna lettura, scrittura o esportazione', async () => {
  assert.equal((await api.GET(request('/api/frantoio'))).status, 401);
  assert.equal(
    (
      await api.POST(
        request('/api/frantoio', { method: 'POST', body: producer }),
      )
    ).status,
    401,
  );
  assert.equal(
    (await exportApi.GET(request('/api/frantoio/export'))).status,
    401,
  );
  assert.equal((await company.GET(request('/api/company'))).status, 401);
});
void test('API: isolamento aziende, UUID duplicati indipendenti, export e autore', async () => {
  const a = await archive(),
    b = await archive();
  try {
    const credentials = await session(a);
    await write(a.db, producer);
    await write(b.db, { ...producer, name: 'SEGRETO AZIENDA B' });
    const response = await api.GET(request('/api/frantoio', credentials));
    assert.equal(response.status, 200);
    assert.match(response.headers.get('cache-control'), /no-store/);
    const data = await response.json();
    assert.equal(data.producers.length, 1);
    assert.equal(data.producers[0].name, producer.name);
    assert.equal(data.events[0].actor_id, a.db.actorId);
    assert.equal(
      (
        await api.GET(
          request('/api/frantoio', { ...credentials, tenant: b.db.tenantId }),
        )
      ).status,
      403,
    );
    assert.equal(
      (
        await api.POST(
          request('/api/frantoio', {
            ...credentials,
            tenant: b.db.tenantId,
            method: 'POST',
            body: producer,
          }),
        )
      ).status,
      403,
    );
    const exported = await exportApi.GET(
      request('/api/frantoio/export', credentials),
    );
    assert.equal(exported.status, 200);
    const text = await exported.text();
    assert.doesNotMatch(
      text,
      /SEGRETO AZIENDA B|password_hash|csrf_token|token_hash/,
    );
    assert.equal(JSON.parse(text).company.id, a.db.tenantId);
  } finally {
    await a.close();
    await b.close();
  }
});
void test('API: cambio ruolo immediato, viewer non può scrivere neppure con retry', () =>
  fixture(async (a) => {
    const credentials = await session(a);
    await write(a.db, producer);
    await a.client.query(
      "UPDATE memberships SET role='viewer' WHERE company_id=$1",
      [a.db.tenantId],
    );
    for (const action of Object.keys(actionLabels)) {
      const result = await api.POST(
        request('/api/frantoio', {
          ...credentials,
          method: 'POST',
          body: { ...producer, action },
        }),
      );
      assert.equal(result.status, 403, action);
    }
    assert.equal(
      (await api.GET(request('/api/frantoio', credentials))).status,
      200,
    );
    assert.equal(
      (await company.GET(request('/api/company', credentials))).status,
      403,
    );
    assert.equal((await readData(a.db)).events.length, 1);
  }));
void test('API: CSRF, origine, formato e dimensione sono verificati', () =>
  fixture(async (a) => {
    const credentials = await session(a);
    for (const headers of [
      { 'X-CSRF-Token': '' },
      { 'X-CSRF-Token': 'é'.repeat(64) },
      { Origin: 'https://attacker.invalid' },
      { Origin: '' },
    ]) {
      assert.equal(
        (
          await api.POST(
            request('/api/frantoio', {
              ...credentials,
              method: 'POST',
              body: producer,
              headers,
            }),
          )
        ).status,
        403,
      );
    }
    assert.equal(
      (
        await api.POST(
          request('/api/frantoio', {
            ...credentials,
            method: 'POST',
            body: producer,
            headers: { 'Content-Type': 'text/plain' },
          }),
        )
      ).status,
      415,
    );
    assert.equal(
      (
        await api.POST(
          request('/api/frantoio', {
            ...credentials,
            method: 'POST',
            body: { ...producer, note: 'x'.repeat(13000) },
          }),
        )
      ).status,
      413,
    );
    assert.equal(
      (
        await auth.POST(
          request('/api/auth/login', {
            method: 'POST',
            body: { email: 'a', password },
            headers: { Origin: '' },
          }),
          context('login'),
        )
      ).status,
      403,
    );
    assert.equal((await readData(a.db)).events.length, 0);
  }));
void test('PostgreSQL: RLS e pool impediscono contaminazioni, audit non modificabile', async () => {
  const a = await archive(),
    b = await archive();
  try {
    await write(a.db, producer);
    await write(b.db, { ...producer, name: 'Altro' });
    assert.equal(
      (await pool().query('SELECT * FROM producers')).rows.length,
      0,
    );
    const rows = await companyTransaction(
      a.db.actorId,
      a.db.tenantId,
      false,
      (store) => store.client.query('SELECT * FROM producers'),
    );
    assert.equal(rows.rows.length, 1);
    assert.equal(rows.rows[0].tenant_id, a.db.tenantId);
    assert.equal(
      (await pool().query('SELECT * FROM producers')).rows.length,
      0,
    );
    assert.equal((await readData(b.db)).producers[0].name, 'Altro');
    await assert.rejects(
      () =>
        companyTransaction(a.db.actorId, a.db.tenantId, true, (store) =>
          store.client.query(
            "INSERT INTO producers(tenant_id,id,name,city) VALUES($1,'cross-company','x','x')",
            [b.db.tenantId],
          ),
        ),
      /row-level security/,
    );
    await assert.rejects(
      () =>
        companyTransaction(a.db.actorId, a.db.tenantId, true, (store) =>
          store.client.query(
            "UPDATE events SET action='altered' WHERE tenant_id=$1",
            [a.db.tenantId],
          ),
        ),
      /permission denied/,
    );
  } finally {
    await a.close();
    await b.close();
  }
});
void test('PostgreSQL: FK composite impediscono riferimenti tra frantoi', async () => {
  const a = await archive(),
    b = await archive();
  try {
    await write(b.db, {
      action: 'facility.create',
      requestId: 'facility-only-in-b',
      name: 'Deposito B',
      date: '2026-09-09',
    });
    await assert.rejects(
      () =>
        companyTransaction(a.db.actorId, a.db.tenantId, true, (store) =>
          store.client.query(
            "INSERT INTO containers(tenant_id,id,facility_id,code,capacity_g) VALUES($1,'container-a','facility-only-in-b','A1',1000)",
            [a.db.tenantId],
          ),
        ),
      /foreign key/,
    );
    assert.equal((await readData(a.db)).containers.length, 0);
  } finally {
    await a.close();
    await b.close();
  }
});
void test('sessioni: logout, scadenza, cambio password e membership disabilitata', () =>
  fixture(async (a) => {
    const credentials = await session(a);
    assert.equal(
      (
        await auth.POST(
          request('/api/auth/logout', {
            ...credentials,
            method: 'POST',
            body: {},
          }),
          context('logout'),
        )
      ).status,
      200,
    );
    assert.equal(
      (await api.GET(request('/api/frantoio', credentials))).status,
      401,
    );
    const second = await session(a);
    await a.client.query(
      "UPDATE sessions SET expires_at=now()-interval '1 second' WHERE user_id=$1",
      [a.db.actorId],
    );
    assert.equal((await api.GET(request('/api/frantoio', second))).status, 401);
    const third = await session(a);
    assert.equal(
      (
        await auth.POST(
          request('/api/auth/password', {
            ...third,
            method: 'POST',
            body: {
              currentPassword: password,
              password: 'Nuova password sicura! 2026',
            },
          }),
          context('password'),
        )
      ).status,
      200,
    );
    assert.equal((await api.GET(request('/api/frantoio', third))).status, 401);
    await assert.rejects(
      () => login(a.db.actorId + '@test.invalid', password),
      /non valide/,
    );
    const fourth = await session(a);
    await a.client.query(
      'UPDATE memberships SET active=false WHERE company_id=$1',
      [a.db.tenantId],
    );
    assert.equal((await api.GET(request('/api/frantoio', fourth))).status, 403);
  }));
void test('login concorrente: password revocata non crea nuove sessioni', () =>
  fixture(async (a) => {
    await session(a);
    const currentPool = pool(),
      original = currentPool.connect.bind(currentPool);
    const arrived = Promise.withResolvers(),
      release = Promise.withResolvers();
    currentPool.connect = (...args) => {
      if (args.length) return original(...args);
      arrived.resolve();
      return release.promise.then(() => original());
    };
    try {
      const pending = login(a.db.actorId + '@test.invalid', password);
      await arrived.promise;
      await a.client.query('UPDATE users SET password_hash=$1 WHERE id=$2', [
        await hashPassword('Credenziale nuova revocata!'),
        a.db.actorId,
      ]);
      await a.client.query('DELETE FROM sessions WHERE user_id=$1', [
        a.db.actorId,
      ]);
      release.resolve();
      await assert.rejects(() => pending, /non valide/);
      assert.equal(
        (
          await a.client.query(
            'SELECT count(*)::int AS n FROM sessions WHERE user_id=$1',
            [a.db.actorId],
          )
        ).rows[0].n,
        0,
      );
    } finally {
      release.resolve();
      currentPool.connect = original;
    }
  }));
void test('amministrazione: ultimo admin, nuovo utente, permessi e audit', () =>
  fixture(async (a) => {
    const credentials = await session(a),
      post = (body) =>
        company.POST(
          request('/api/company', { ...credentials, method: 'POST', body }),
        );
    assert.equal(
      (
        await post({
          action: 'member.update',
          userId: a.db.actorId,
          role: 'viewer',
          active: true,
        })
      ).status,
      409,
    );
    assert.equal(
      (
        await post({
          action: 'member.create',
          name: 'Nuovo operatore',
          email: randomUUID() + '@test.invalid',
          password,
          role: 'operator',
        })
      ).status,
      200,
    );
    const members = (
      await (await company.GET(request('/api/company', credentials))).json()
    ).members;
    assert.equal(members.length, 2);
    const operator = members.find((m) => m.id !== a.db.actorId);
    assert.equal(
      (
        await post({
          action: 'member.update',
          userId: operator.id,
          role: 'viewer',
          active: false,
        })
      ).status,
      200,
    );
    assert.equal(
      (
        await post({
          action: 'company.update',
          name: 'Azienda aggiornata',
          fiscal_id: 'DEMO',
          address: 'Via test',
        })
      ).status,
      200,
    );
    assert.equal(
      (
        await a.client.query(
          'SELECT count(*)::int AS n FROM security_events WHERE company_id=$1',
          [a.db.tenantId],
        )
      ).rows[0].n,
      3,
    );
  }));
void test('login: limitazione tentativi senza rivelare account', async () => {
  const email = randomUUID() + '@test.invalid';
  for (let i = 0; i < 8; i++)
    await assert.rejects(
      () => login(email, password),
      (error) => error.status === 401,
    );
  await assert.rejects(
    () => login(email, password),
    (error) => error.status === 429,
  );
});
