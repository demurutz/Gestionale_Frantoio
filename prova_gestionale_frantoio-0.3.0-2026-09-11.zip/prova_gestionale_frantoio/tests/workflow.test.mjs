import test, { after } from 'node:test';
import { pool } from '../db/index.ts';
after(async () => {
  await pool().end();
});
import assert from 'node:assert/strict';
import { archive, write, readData } from './archive-helper.mjs';
import { grams, dateField, summary, phase } from '../lib/domain.ts';
import { batchesCsv } from '../lib/csv.ts';
import { buildExport } from '../lib/export.ts';

const date = '2026-09-04';
const mutate = (db, input) => write(db, { date, ...input });
const producer = {
  action: 'producer.create',
  requestId: 'test-producer-01',
  name: 'Azienda di prova',
  city: 'Bitonto',
  phone: '080000000',
  fiscal_id: '01234567890',
  address: 'Via di prova 1',
  country: 'IT',
};
const batch = {
  action: 'batch.create',
  requestId: 'test-batch-01',
  producer_id: producer.requestId,
  facility_id: 'test-facility-01',
  date,
  variety: 'Coratina',
  origin: 'Italia · Bitonto',
  gross: '1050',
  tare: '50',
  notes: '',
  olive_source: 'third_party',
  quality: 'normal',
};
const purchase = {
  action: 'oil.receive',
  requestId: 'purchase-oil-01',
  ownership: 'own',
  source: 'purchased',
  supplier_id: producer.requestId,
  label: 'ACQ-01',
  quality: 'bio',
  category: 'extra',
  origin: 'Italia',
  format: 'bulk',
  container_id: 'test-container-01',
  amount: 100,
  document: 'DDT 1',
  document_date: date,
};
const document = { document: 'RIF 1', document_date: date };
async function setup(db) {
  await mutate(db, producer);
  await mutate(db, {
    action: 'facility.create',
    requestId: 'test-facility-01',
    name: 'Frantoio',
    cuaa: '01234567890',
    sian_code: '123',
    address: 'Via di prova 1',
  });
  await mutate(db, {
    action: 'facility.create',
    requestId: 'test-facility-02',
    name: 'Deposito secondario',
    cuaa: '01234567890',
    sian_code: '124',
    address: 'Via di prova 2',
  });
  for (const [id, facility, code, capacity] of [
    ['test-container-01', 'test-facility-01', 'CT-01', 1000],
    ['test-container-02', 'test-facility-02', 'CT-02', 200],
    ['test-container-03', 'test-facility-01', 'CT-03', 1000],
  ])
    await mutate(db, {
      action: 'container.create',
      requestId: id,
      facility_id: facility,
      code,
      capacity,
    });
}
async function milling(
  db,
  { source = 'third_party', destination = 'store', quality = 'normal' } = {},
) {
  const { id } = await mutate(db, {
    ...batch,
    olive_source: source,
    quality,
    designation: quality.includes('dop') ? 'Terra di Bari' : '',
  });
  await mutate(db, {
    action: 'batch.start',
    requestId: 'start-batch-01',
    id,
    revision: 0,
  });
  const finish = {
    action: 'batch.complete',
    requestId: 'finish-batch-01',
    id,
    revision: 1,
    oil: 150,
    destination,
    container_id: 'test-container-01',
  };
  await mutate(db, finish);
  return { id, finish, stock_id: finish.requestId, lot_id: finish.requestId };
}
async function inArchive(fn) {
  const a = await archive();
  try {
    await setup(a.db);
    await fn(a);
  } finally {
    await a.close();
  }
}
const stockTotal = (data) => data.stocks.reduce((n, s) => n + s.amount_g, 0);

void test('CSV: quantità, accenti, delimitatori e protezione dalle formule', () => {
  const csv = batchesCsv([
    {
      id: 7,
      date,
      producer_name: '=HYPERLINK("esempio")',
      variety: 'Coratina; mista',
      origin: 'Contrada "Città"\nCampo 2',
      net_g: 12500500,
      status: 'done',
      oil_g: 200125,
      returned_g: 50125,
      stock_g: 140000,
      tank: 'CT-01',
      packaged_ml: 10000,
    },
  ]);
  assert.ok(csv.startsWith('\uFEFF"Partita";"Data";'));
  assert.ok(csv.includes('"\'=HYPERLINK(""esempio"")"'));
  assert.ok(csv.includes('"Coratina; mista"'));
  assert.ok(csv.includes('"Contrada ""Città""\nCampo 2"'));
  assert.ok(
    csv.includes(
      '"12.500,5";"Molitura completata";"200,125";"50,125";"140";"CT-01";"10"',
    ),
  );
});
void test('pesi e date: precisione, numeri italiani, limiti e date impossibili', () => {
  assert.equal(grams('12,345', 'Peso'), 12345);
  assert.equal(grams(0, 'Tara', true), 0);
  for (const value of [
    '-1',
    'NaN',
    'Infinity',
    '1e3',
    '0.0001',
    '1000001',
    null,
    0,
  ])
    assert.throws(() => grams(value, 'Peso'));
  assert.throws(() => dateField('2026-02-30'));
  assert.throws(() => dateField('2026-13-01'));
  assert.equal(dateField('2024-02-29'), '2024-02-29');
});
void test('carico, molitura, deposito conto terzi e ritiri parziali idempotenti', () =>
  inArchive(async ({ db }) => {
    await mutate(db, producer);
    const { id, finish, stock_id } = await milling(db);
    await mutate(db, finish);
    let data = await readData(db);
    assert.equal(data.producers.length, 1);
    assert.equal(data.lots.length, 1);
    assert.equal(data.lots[0].category, 'pending');
    assert.equal(data.lots[0].ownership, 'third_party');
    assert.equal(data.lots[0].owner_id, producer.requestId);
    assert.equal(summary(data.batches).yield, 15);
    const delivery = {
      action: 'oil.return',
      requestId: 'delivery-01',
      stock_id,
      amount: 100,
      note: 'Primo ritiro',
    };
    await mutate(db, delivery);
    await mutate(db, delivery);
    await assert.rejects(
      () =>
        mutate(db, { ...delivery, requestId: 'excess-return-01', amount: 51 }),
      /giacenza/,
    );
    await mutate(db, { ...delivery, requestId: 'delivery-02', amount: 50 });
    data = await readData(db);
    assert.equal(data.deliveries.length, 2);
    assert.equal(data.batches.find((b) => b.id === id).stock_g, 0);
    assert.equal(phase(data.batches[0]), 'returned');
    assert.equal(stockTotal(data), 0);
    assert.equal(
      data.events.filter((e) => e.action === 'batch.complete').length,
      1,
    );
  }));
void test('ritiro immediato conto terzi: nessun carico in contenitore', () =>
  inArchive(async ({ db }) => {
    await milling(db, { destination: 'return', quality: 'dop_bio' });
    const data = await readData(db);
    assert.equal(data.stocks.length, 0);
    assert.equal(data.lots[0].quality, 'dop_bio');
    assert.equal(data.lots[0].designation, 'Terra di Bari');
    assert.equal(data.deliveries[0].amount_g, 150000);
    assert.equal(phase(data.batches[0]), 'returned');
  }));
void test('produzione da olive proprie e acquistate: olio proprio, non ritiro conto terzi', async () => {
  for (const source of ['own', 'purchased'])
    await inArchive(async ({ db }) => {
      const { stock_id } = await milling(db, { source });
      const data = await readData(db);
      assert.equal(data.lots[0].source, 'produced');
      assert.equal(data.lots[0].ownership, 'own');
      assert.equal(data.lots[0].owner_id, null);
      await assert.rejects(
        () =>
          mutate(db, {
            action: 'oil.return',
            requestId: 'wrong-return-01',
            stock_id,
            amount: 1,
          }),
        /conto terzi/,
      );
    });
});
void test('validazione: pesatura, classificazione, riferimenti e revisioni', () =>
  inArchive(async ({ db }) => {
    await assert.rejects(() => mutate(db, { ...batch, tare: 1050 }), /tara/);
    await assert.rejects(
      () => mutate(db, { ...batch, producer_id: 'missing-person' }),
      /conferente/,
    );
    await assert.rejects(
      () => mutate(db, { ...batch, quality: 'dop' }),
      /D.O.P./,
    );
    const { id } = await mutate(db, batch);
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'batch.start',
          requestId: 'missing-revision',
          id,
        }),
      /Revisione/,
    );
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'batch.complete',
          requestId: 'early-complete',
          id,
          revision: 0,
        }),
      /stato/,
    );
    const edit = {
      ...batch,
      action: 'batch.update',
      requestId: 'edit-weight-01',
      id,
      revision: 0,
      gross: 550,
    };
    await mutate(db, edit);
    await mutate(db, edit);
    await assert.rejects(
      () => mutate(db, { ...edit, requestId: 'stale-edit-01' }),
      /modificata/,
    );
    await mutate(db, {
      action: 'batch.start',
      requestId: 'start-weight-01',
      id,
      revision: 1,
    });
    await assert.rejects(
      () => mutate(db, { ...edit, requestId: 'locked-edit-01', revision: 2 }),
      /lavorazione/,
    );
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'batch.complete',
          requestId: 'excess-oil-01',
          id,
          revision: 2,
          oil: 501,
        }),
      /superare/,
    );
    assert.equal((await readData(db)).batches[0].net_g, 500000);
  }));
void test('acquisto, trasferimento parziale, imbottigliamento e vendita: bilanci distinti', () =>
  inArchive(async ({ db }) => {
    await mutate(db, purchase);
    const transfer = {
      action: 'oil.transfer',
      requestId: 'transfer-oil-01',
      stock_id: purchase.requestId,
      container_id: 'test-container-02',
      amount: 40,
      ...document,
    };
    await mutate(db, transfer);
    await mutate(db, transfer);
    let data = await readData(db);
    assert.equal(stockTotal(data), 100000);
    assert.equal(
      data.stocks.find((s) => s.id === purchase.requestId).amount_g,
      60000,
    );
    assert.equal(
      data.stocks.find((s) => s.id === transfer.requestId).amount_g,
      40000,
    );
    const bottle = {
      action: 'oil.bottle',
      requestId: 'bottle-oil-01',
      stock_id: transfer.requestId,
      amount: 27.48,
      package_code: 'B-01',
      units: 40,
      unit_ml: 750,
    };
    await mutate(db, bottle);
    await mutate(db, bottle);
    data = await readData(db);
    assert.equal(stockTotal(data), 72520);
    assert.equal(data.packages[0].units, 40);
    assert.equal(data.packages[0].consumed_g, 27480);
    assert.equal(data.packages[0].facility_id, 'test-facility-02');
    const sale = {
      action: 'package.sell',
      requestId: 'sale-oil-01',
      package_id: bottle.requestId,
      customer_id: producer.requestId,
      units: 15,
      ...document,
    };
    await mutate(db, sale);
    await mutate(db, sale);
    data = await readData(db);
    assert.equal(data.packages[0].units, 25);
    assert.equal(data.packages[0].units * data.packages[0].unit_ml, 18750);
    assert.equal(data.sales.length, 1);
    assert.equal(stockTotal(data), 72520);
    await assert.rejects(
      () => mutate(db, { ...sale, requestId: 'oversell-oil-01', units: 26 }),
      /giacenza/,
    );
  }));
void test('acquisto diretto di imbottigliato e vendita', () =>
  inArchive(async ({ db }) => {
    await mutate(db, {
      ...purchase,
      format: 'packaged',
      facility_id: 'test-facility-01',
      package_code: 'ACQ-B-01',
      units: 12,
      unit_ml: 500,
    });
    let data = await readData(db);
    assert.equal(data.stocks.length, 0);
    assert.equal(data.packages[0].units, 12);
    assert.equal(data.packages[0].consumed_g, 0);
    await mutate(db, {
      action: 'package.sell',
      requestId: 'sell-direct-01',
      package_id: purchase.requestId,
      customer_id: producer.requestId,
      units: 12,
      ...document,
    });
    data = await readData(db);
    assert.equal(data.packages[0].units, 0);
    await assert.rejects(
      () =>
        mutate(db, {
          ...purchase,
          requestId: 'bad-owner-01',
          ownership: 'third_party',
          owner_id: producer.requestId,
        }),
      /proprietà del frantoio/,
    );
  }));
void test('classificazione richiesta per imbottigliare; conto terzi non vendibile', () =>
  inArchive(async ({ db }) => {
    const { lot_id, stock_id } = await milling(db);
    const bottle = {
      action: 'oil.bottle',
      requestId: 'bottle-third-01',
      stock_id,
      amount: 10,
      package_code: 'B-TERZI',
      units: 20,
      unit_ml: 500,
    };
    await assert.rejects(() => mutate(db, bottle), /classificazione/);
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'oil.classify',
          requestId: 'classify-empty',
          lot_id,
          category: 'extra',
        }),
      /documento/,
    );
    await mutate(db, {
      action: 'oil.classify',
      requestId: 'classify-third',
      lot_id,
      category: 'extra',
      ...document,
    });
    await mutate(db, bottle);
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'package.sell',
          requestId: 'sell-third-01',
          package_id: bottle.requestId,
          customer_id: producer.requestId,
          units: 1,
          ...document,
        }),
      /proprietà di un cliente/,
    );
    await mutate(db, {
      action: 'package.return',
      requestId: 'return-bottles-01',
      package_id: bottle.requestId,
      units: 20,
    });
    assert.equal((await readData(db)).packages[0].units, 0);
  }));
void test('contenitori: capacità, duplicati, separazione lotti e trasferimenti non validi', () =>
  inArchive(async ({ db }) => {
    await mutate(db, purchase);
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'container.create',
          requestId: 'duplicate-container',
          facility_id: 'test-facility-01',
          code: 'ct-01',
          capacity: 100,
        }),
      /già presente/,
    );
    await assert.rejects(
      () => mutate(db, { ...purchase, requestId: 'mixed-oil-01' }),
      /altro lotto/,
    );
    await assert.rejects(
      () =>
        mutate(db, {
          ...purchase,
          requestId: 'excess-capacity',
          container_id: 'test-container-02',
          amount: 201,
        }),
      /capacità/,
    );
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'oil.transfer',
          requestId: 'same-container-01',
          stock_id: purchase.requestId,
          container_id: 'test-container-01',
          amount: 10,
        }),
      /diverso/,
    );
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'oil.transfer',
          requestId: 'missing-target-01',
          stock_id: purchase.requestId,
          container_id: 'missing',
          amount: 10,
        }),
      /contenitore/,
    );
    assert.equal(stockTotal(await readData(db)), 100000);
  }));
void test('due scarichi concorrenti: uno solo viene applicato, nessun saldo negativo', () =>
  inArchive(async ({ db }) => {
    const { stock_id } = await milling(db);
    const result = await Promise.allSettled(
      ['return-one', 'return-two'].map((requestId) =>
        mutate(db, { action: 'oil.return', requestId, stock_id, amount: 100 }),
      ),
    );
    assert.equal(result.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(
      result.find((r) => r.status === 'rejected').reason.status,
      409,
    );
    const data = await readData(db);
    assert.equal(stockTotal(data), 50000);
    assert.equal(data.deliveries.length, 1);
  }));
void test('retry concorrenti identici e riuso UUID con dati diversi', () =>
  inArchive(async ({ db }) => {
    const result = await Promise.all([
      mutate(db, purchase),
      mutate(db, purchase),
    ]);
    assert.equal(result[0].id, result[1].id);
    const data = await readData(db);
    assert.equal(data.lots.length, 1);
    assert.equal(
      data.events.filter((e) => e.id === purchase.requestId).length,
      1,
    );
    await assert.rejects(
      () => mutate(db, { ...purchase, amount: 50 }),
      /dati diversi/,
    );
  }));
void test('errore durante transazione: rollback di scarico, carico e giornale', () =>
  inArchive(async ({ db, failStock }) => {
    await mutate(db, purchase);
    const before = await readData(db);
    await failStock();
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'oil.transfer',
          requestId: 'rollback-transfer',
          stock_id: purchase.requestId,
          container_id: 'test-container-02',
          amount: 40,
          ...document,
        }),
      /simulated failure/,
    );
    assert.deepEqual(await readData(db), before);
  }));
void test('esportazione versionata: storico, riferimenti fotografati e avvisi SIAN', () =>
  inArchive(async ({ db }) => {
    await mutate(db, purchase);
    await mutate(db, {
      ...producer,
      action: 'producer.update',
      requestId: 'rename-producer',
      id: producer.requestId,
      name: 'Nome nuovo',
    });
    const data = await readData(db);
    const file = JSON.parse(
      JSON.stringify(buildExport(data, '2026-09-04T12:00:00.000Z')),
    );
    assert.equal(file.format, 'frantoio-interchange');
    assert.equal(file.schema_version, '2.0.0');
    assert.equal(file.sian.status, 'intermediate_not_for_upload');
    assert.equal(file.sian.transmitted, false);
    assert.equal(file.last_sequence, data.events.length);
    assert.equal(file.snapshot.producers[0].name, 'Nome nuovo');
    const purchaseEvent = file.events.find((e) => e.action === 'oil.receive');
    assert.equal(purchaseEvent.payload.supplier.name, producer.name);
    assert.equal(purchaseEvent.payload.oil_g, 100000);
    assert.equal(purchaseEvent.payload.document, purchase.document);
    assert.equal(
      purchaseEvent.payload.changes.find((c) => c.table === 'oil_stocks').after
        .amount_g,
      100000,
    );
    assert.equal(file.sian.warnings.length, 1);
  }));
void test('cronologia del lotto: vietato scarico prima del carico o di un movimento successivo', () =>
  inArchive(async ({ db }) => {
    await mutate(db, purchase);
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'oil.transfer',
          requestId: 'backdated-transfer',
          date: '2026-09-03',
          stock_id: purchase.requestId,
          container_id: 'test-container-02',
          amount: 1,
          ...document,
        }),
      /data/,
    );
    await mutate(db, {
      action: 'oil.transfer',
      requestId: 'future-transfer',
      date: '2026-09-05',
      stock_id: purchase.requestId,
      container_id: 'test-container-02',
      amount: 1,
      ...document,
    });
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'oil.transfer',
          requestId: 'late-history',
          stock_id: purchase.requestId,
          container_id: 'test-container-03',
          amount: 1,
        }),
      /data/,
    );
  }));
void test('migrazione conserva vecchie partite e restituzioni senza inventare proprietà', async () => {
  const a = await archive({ legacy: true });
  try {
    a.sqlite.exec(
      "INSERT INTO producers VALUES ('legacy-person','Cliente storico','Bari',''); INSERT INTO batches (request_id,producer_id,date,variety,origin,gross_g,tare_g,net_g,status,oil_g,tank) VALUES ('legacy-batch','legacy-person','2025-10-01','Mista','Italia',1000000,0,1000000,'done',150000,'CT-VECCHIO'); INSERT INTO deliveries VALUES ('legacy-delivery',1,50000,'2025-10-01','Ritiro','2025-10-01T12:00:00Z')",
    );
    await a.migrateRemaining();
    let data = await readData(a.db);
    assert.equal(data.batches[0].stock_g, 100000);
    assert.equal(data.batches[0].olive_source, 'unknown');
    assert.equal(data.events.length, 0);
    await setup(a.db);
    await mutate(a.db, {
      action: 'oil.adopt',
      requestId: 'adopt-legacy',
      id: 1,
      ownership: 'third_party',
      owner_id: 'legacy-person',
      quality: 'normal',
      category: 'pending',
      container_id: 'test-container-01',
    });
    data = await readData(a.db);
    assert.equal(data.batches[0].oil_g, 150000);
    assert.equal(data.deliveries[0].amount_g, 50000);
    assert.equal(stockTotal(data), 100000);
    assert.equal(data.lots[0].source, 'legacy');
    assert.equal(data.batches[0].stock_g, 100000);
    await assert.rejects(
      () =>
        mutate(a.db, {
          action: 'oil.adopt',
          requestId: 'adopt-again',
          id: 1,
          ownership: 'own',
          quality: 'normal',
          category: 'pending',
          container_id: 'test-container-03',
        }),
      /già integrata/,
    );
  } finally {
    await a.close();
  }
});
void test('vendite concorrenti: una sola scarica le bottiglie disponibili', () =>
  inArchive(async ({ db }) => {
    await mutate(db, {
      ...purchase,
      format: 'packaged',
      facility_id: 'test-facility-01',
      package_code: 'CONCURRENT-B',
      units: 12,
      unit_ml: 750,
    });
    const result = await Promise.allSettled(
      ['sale-concurrent-01', 'sale-concurrent-02'].map((requestId) =>
        mutate(db, {
          action: 'package.sell',
          requestId,
          package_id: purchase.requestId,
          customer_id: producer.requestId,
          units: 10,
          ...document,
        }),
      ),
    );
    assert.equal(result.filter((r) => r.status === 'fulfilled').length, 1);
    assert.equal(
      result.find((r) => r.status === 'rejected').reason.status,
      409,
    );
    const data = await readData(db);
    assert.equal(data.packages[0].units, 2);
    assert.equal(data.sales.length, 1);
  }));

void test('conto terzi: trasferimento esterno vietato, movimentazione interna consentita', () =>
  inArchive(async ({ db }) => {
    const { stock_id } = await milling(db);
    await assert.rejects(
      () =>
        mutate(db, {
          action: 'oil.transfer',
          requestId: 'third-party-away',
          stock_id,
          container_id: 'test-container-02',
          amount: 50,
          ...document,
        }),
      /olio proprio/,
    );
    await mutate(db, {
      action: 'oil.transfer',
      requestId: 'third-party-inside',
      stock_id,
      container_id: 'test-container-03',
      amount: 50,
    });
    assert.equal(stockTotal(await readData(db)), 150000);
  }));

void test('integrazione di una vecchia molitura in corso senza cambiare pesi o stato', async () => {
  const a = await archive({ legacy: true });
  try {
    a.sqlite.exec(
      "INSERT INTO producers VALUES ('legacy-person','Cliente storico','Bari',''); INSERT INTO batches (request_id,producer_id,date,variety,origin,gross_g,tare_g,net_g,status) VALUES ('legacy-working','legacy-person','2026-09-01','Mista','Italia',1000000,0,1000000,'working')",
    );
    await a.migrateRemaining();
    await setup(a.db);
    await mutate(a.db, {
      action: 'batch.integrate',
      requestId: 'integrate-working',
      id: 1,
      revision: 0,
      facility_id: 'test-facility-01',
      olive_source: 'own',
      quality: 'normal',
    });
    const b = (await readData(a.db)).batches[0];
    assert.equal(b.status, 'working');
    assert.equal(b.net_g, 1000000);
    await mutate(a.db, {
      action: 'batch.complete',
      requestId: 'complete-legacy-working',
      date: '2026-09-02',
      id: 1,
      revision: 1,
      oil: 150,
      destination: 'store',
      container_id: 'test-container-01',
    });
    assert.equal(stockTotal(await readData(a.db)), 150000);
  } finally {
    await a.close();
  }
});

void test('resa ponderata, non media semplice delle percentuali', () => {
  assert.equal(
    summary([
      { net_g: 1000000, oil_g: 150000, returned_g: 10000, status: 'done' },
      { net_g: 2000000, oil_g: 400000, returned_g: 0, status: 'done' },
      { net_g: 5000000, oil_g: 0, returned_g: 0, status: 'waiting' },
    ]).yield,
    (550000 / 3000000) * 100,
  );
});
