import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readdir, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { archive, readData, write } from './archive-helper.mjs';
import { pool } from '../db/index.ts';
import { verifyPassword } from '../lib/auth.ts';
import { seed } from '../scripts/seed.mjs';
import { createCompany } from '../scripts/company-create.mjs';
import { importSqlite } from '../scripts/import-sqlite.mjs';

after(async () => {
  await pool().end();
});
async function privateDirectory() {
  return pathToFileURL(
    (await mkdtemp(join(tmpdir(), 'frantoio-credentials-test-'))) + '/',
  );
}

void test('setup recuperabile: rollback se il file non è scrivibile, credenziali conservate dopo errore e retry idempotente', async () => {
  const a = await archive();
  const credentialsDirectory = await privateDirectory();
  const blocked = new URL('not-a-directory', credentialsDirectory);
  await writeFile(blocked, 'fixture');
  const demoId = '11111111-1111-4111-8111-111111111111';
  try {
    await assert.rejects(
      seed({
        credentialsDirectory: new URL('not-a-directory/', credentialsDirectory),
      }),
    );
    assert.equal(
      (
        await a.client.query(
          "SELECT count(*)::int AS n FROM users WHERE email LIKE '%@frantoio.test'",
        )
      ).rows[0].n,
      0,
    );
    await a.client.query(
      "ALTER TABLE containers ADD CONSTRAINT test_seed_failure CHECK(tenant_id <> '" +
        demoId +
        "')",
    );
    try {
      await assert.rejects(seed({ credentialsDirectory }), /test_seed_failure/);
    } finally {
      await a.client.query(
        'ALTER TABLE containers DROP CONSTRAINT test_seed_failure',
      );
    }
    const files = (await readdir(credentialsDirectory)).filter((f) =>
      f.endsWith('.json'),
    );
    assert.equal(files.length, 1);
    const credentials = JSON.parse(
      await readFile(new URL(files[0], credentialsDirectory), 'utf8'),
    );
    assert.equal(credentials.length, 4);
    for (const credential of credentials) {
      const user = (
        await a.client.query('SELECT password_hash FROM users WHERE email=$1', [
          credential.email,
        ])
      ).rows[0];
      assert.equal(
        await verifyPassword(credential.password, user.password_hash),
        true,
      );
    }
    assert.equal((await seed({ credentialsDirectory })).createdCount, 0);
    const first = (
      await a.client.query(
        'SELECT count(*)::int AS n FROM events WHERE tenant_id=$1',
        [demoId],
      )
    ).rows[0].n;
    assert.equal(first, 3);
    assert.equal((await seed({ credentialsDirectory })).createdCount, 0);
    assert.equal(
      (
        await a.client.query(
          'SELECT count(*)::int AS n FROM events WHERE tenant_id=$1',
          [demoId],
        )
      ).rows[0].n,
      first,
    );
    assert.equal(
      (await readdir(credentialsDirectory)).filter((f) => f.endsWith('.json'))
        .length,
      1,
    );
  } finally {
    await a.close();
  }
});

void test('creazione azienda vuota: file privato, consenso per account condiviso e rollback su errore filesystem', async () => {
  const a = await archive();
  const credentialsDirectory = await privateDirectory();
  const email = a.db.actorId + '-new@test.invalid';
  try {
    const created = await createCompany('Nuovo frantoio', email, {
      credentialsDirectory,
    });
    const access = JSON.parse(await readFile(created.credentialsFile, 'utf8'));
    assert.equal(access.companyId, created.companyId);
    const user = (
      await a.client.query(
        'SELECT id,password_hash FROM users WHERE email=$1',
        [email],
      )
    ).rows[0];
    assert.equal(
      await verifyPassword(access.password, user.password_hash),
      true,
    );
    assert.equal(
      (
        await a.client.query(
          'SELECT count(*)::int AS n FROM events WHERE tenant_id=$1',
          [created.companyId],
        )
      ).rows[0].n,
      0,
    );
    await assert.rejects(
      createCompany('Associazione non autorizzata', email, {
        credentialsDirectory,
      }),
      /--existing-user/,
    );
    const shared = await createCompany('Secondo frantoio', email, {
      credentialsDirectory,
      existingUser: true,
    });
    assert.equal(
      (
        await a.client.query(
          'SELECT count(*)::int AS n FROM memberships WHERE user_id=$1',
          [user.id],
        )
      ).rows[0].n,
      2,
    );
    assert.equal(
      JSON.parse(await readFile(shared.credentialsFile, 'utf8')).password,
      undefined,
    );
    const blocked = new URL('blocked', credentialsDirectory);
    await writeFile(blocked, 'fixture');
    await assert.rejects(
      createCompany('Da annullare', 'rollback-' + email, {
        credentialsDirectory: new URL('blocked/', credentialsDirectory),
      }),
    );
    assert.equal(
      (
        await a.client.query('SELECT 1 FROM users WHERE email=$1', [
          'rollback-' + email,
        ])
      ).rowCount,
      0,
    );
  } finally {
    await a.close();
  }
});

void test('import storico: rifiuta SQLite estranei e aziende non vuote senza alterarle', async () => {
  const a = await archive({ legacy: true });
  const alien = new DatabaseSync(':memory:');
  try {
    await assert.rejects(
      importSqlite(alien, a.client, a.db.tenantId),
      /non riconosciuto/,
    );
    alien.exec('BEGIN; ROLLBACK');
    await a.migrateRemaining();
    await write(a.db, {
      action: 'producer.create',
      requestId: 'non-empty',
      name: 'Conservare',
      city: 'Bari',
      date: '2026-09-09',
    });
    await assert.rejects(
      importSqlite(a.sqlite, a.client, a.db.tenantId),
      /azienda vuota/,
    );
    assert.equal((await readData(a.db)).producers[0].name, 'Conservare');
    a.sqlite.exec('BEGIN; ROLLBACK');
  } finally {
    alien.close();
    await a.close();
  }
});

void test('importazione diretta dello schema iniziale senza eventi né aggiornamenti della sorgente', async () => {
  const a = await archive({ legacy: true });
  try {
    a.sqlite.exec(
      "INSERT INTO producers VALUES('oldest','Cliente iniziale','Bari','')",
    );
    a.sqlite.exec(
      "INSERT INTO batches(request_id,producer_id,date,variety,origin,gross_g,tare_g,net_g) VALUES('oldest-batch','oldest','2025-10-01','Mista','Italia',1000000,0,1000000)",
    );
    const counts = await importSqlite(a.sqlite, a.client, a.db.tenantId);
    assert.equal(counts.batches, 1);
    assert.equal(counts.events, 0);
    const data = await readData(a.db);
    assert.equal(data.batches[0].olive_source, 'unknown');
    assert.equal(data.batches[0].net_g, 1000000);
    assert.equal(
      a.sqlite.prepare("SELECT 1 FROM sqlite_master WHERE name='events'").get(),
      undefined,
    );
  } finally {
    await a.close();
  }
});

void test('importazione snapshot: una scrittura SQLite concorrente non mescola due stati', async () => {
  const a = await archive();
  const directory = await privateDirectory();
  const file = fileURLToPath(new URL('source.sqlite', directory));
  const reader = new DatabaseSync(file);
  let writer;
  try {
    reader.exec('PRAGMA journal_mode=WAL');
    reader.exec(
      await readFile(
        new URL('../drizzle/0000_skinny_umar.sql', import.meta.url),
        'utf8',
      ),
    );
    reader.exec(
      "INSERT INTO producers VALUES('snapshot','Prima','Bari',''); INSERT INTO batches(request_id,producer_id,date,variety,origin,gross_g,tare_g,net_g) VALUES('snapshot-batch','snapshot','2025-10-01','Mista','Italia',1000000,0,1000000)",
    );
    writer = new DatabaseSync(file);
    let changed = false;
    const source = {
      exec(sql) {
        return reader.exec(sql);
      },
      prepare(sql) {
        if (sql === 'SELECT * FROM batches' && !changed) {
          writer.exec(
            "BEGIN; UPDATE producers SET name='Dopo'; UPDATE batches SET gross_g=2000000,net_g=2000000; COMMIT",
          );
          changed = true;
        }
        return reader.prepare(sql);
      },
    };
    await importSqlite(source, a.client, a.db.tenantId);
    const data = await readData(a.db);
    assert.equal(changed, true);
    assert.equal(data.producers[0].name, 'Prima');
    assert.equal(data.batches[0].net_g, 1000000);
    assert.equal(
      writer.prepare('SELECT net_g FROM batches').get().net_g,
      2000000,
    );
  } finally {
    writer?.close();
    reader.close();
    await a.close();
  }
});

void test('import storico atomico: un record incompatibile annulla anche i record precedenti', async () => {
  const a = await archive({ legacy: true });
  try {
    await a.migrateRemaining();
    a.sqlite.exec(
      "INSERT INTO producers(id,name,city,phone,fiscal_id,address,country) VALUES('valid','Valido','Bari','','','','IT')",
    );
    a.sqlite.exec(
      "PRAGMA foreign_keys=OFF; INSERT INTO containers(id,facility_id,code,capacity_g) VALUES('invalid','missing','BAD',1000)",
    );
    await assert.rejects(importSqlite(a.sqlite, a.client, a.db.tenantId));
    assert.equal((await readData(a.db)).producers.length, 0);
    a.sqlite.exec('BEGIN; ROLLBACK');
  } finally {
    await a.close();
  }
});
