import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import pg from 'pg';
import { companyTransaction } from '../db/index.ts';
import { mutate, readData as readStore } from '../lib/repository.ts';
import { authorize } from '../lib/access.ts';
import { importSqlite } from '../scripts/import-sqlite.mjs';

export const write = (db, input) =>
  companyTransaction(db.actorId, db.tenantId, true, (store, role) => {
    authorize(role, String(input.action));
    return mutate(store, input);
  });
export const readData = (db) =>
  companyTransaction(db.actorId, db.tenantId, false, readStore);
export async function archive({ legacy = false } = {}) {
  if (process.env.FRANTOIO_TEST_DATABASE !== 'isolated')
    throw new Error(
      'Esegui pnpm test:postgres: i test non usano il database applicativo.',
    );
  const client = new pg.Client({
    connectionString: process.env.DATABASE_ADMIN_URL,
  });
  await client.connect();
  const tenantId = randomUUID(),
    actorId = randomUUID();
  await client.query('INSERT INTO companies(id,name) VALUES($1,$2)', [
    tenantId,
    'Azienda test ' + tenantId,
  ]);
  await client.query(
    'INSERT INTO users(id,email,name,password_hash) VALUES($1,$2,$3,$4)',
    [actorId, actorId + '@test.invalid', 'Utente test', 'not-a-login'],
  );
  await client.query(
    "INSERT INTO memberships(company_id,user_id,role) VALUES($1,$2,'admin')",
    [tenantId, actorId],
  );
  let sqlite;
  const migrations = readdirSync(new URL('../drizzle/', import.meta.url))
    .filter((n) => n.endsWith('.sql'))
    .sort();
  if (legacy) {
    sqlite = new DatabaseSync(':memory:');
    sqlite.exec('PRAGMA foreign_keys=ON');
    sqlite.exec(
      readFileSync(
        new URL('../drizzle/' + migrations[0], import.meta.url),
        'utf8',
      ),
    );
  }
  const constraint = 'simulated failure ' + tenantId;
  let constraintCreated = false;
  return {
    db: { tenantId, actorId },
    client,
    sqlite,
    async migrateRemaining() {
      for (const file of migrations.slice(1))
        sqlite.exec(
          readFileSync(new URL('../drizzle/' + file, import.meta.url), 'utf8'),
        );
      await importSqlite(sqlite, client, tenantId);
    },
    async failStock() {
      await client.query(
        'ALTER TABLE oil_stocks ADD CONSTRAINT "' +
          constraint +
          '" CHECK(NOT(tenant_id=\'' +
          tenantId +
          "' AND container_id='test-container-02'))",
      );
      constraintCreated = true;
    },
    async close() {
      if (constraintCreated)
        await client.query(
          'ALTER TABLE oil_stocks DROP CONSTRAINT "' + constraint + '"',
        );
      sqlite?.close();
      await client.end();
    },
  };
}
