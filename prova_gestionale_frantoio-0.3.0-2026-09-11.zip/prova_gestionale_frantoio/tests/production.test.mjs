import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { pool } from '../db/index.ts';
import { archive, write, readData } from './archive-helper.mjs';
import { applyOperation } from '../lib/repository.ts';
import { commit } from '../lib/archive.ts';
import { companyTransaction } from '../db/index.ts';
import { inputMl, toMl, toGrams } from '../lib/quantity.ts';
import { campaignYear, campaignStats } from '../lib/campaigns.ts';
import { fillLevel, effectiveEvents } from '../lib/production.ts';
after(async () => {
  await pool().end();
});

void test('ritiro in kg: esaurisce il saldo mostrato senza residui di arrotondamento', () =>
  fixture(async (f) => {
    const { id } = await receive(f, {
      ownership: 'third_party',
      owner_id: f.person,
      source: 'produced',
      amount: 0.006,
    });
    await run(f.db, {
      action: 'oil.return',
      stock_id: id,
      amount: 0.005,
      volume_unit: 'kg',
    });
    assert.equal((await readData(f.db)).stocks[0].amount_ml, 0);
  }));

const date = '2026-09-05';
const doc = { document: 'DDT prova', document_date: date };
let seq = 0;
const run = (db, command) =>
  write(db, { date, requestId: 'new-test-' + ++seq, ...command });
async function fixture(fn) {
  const a = await archive();
  try {
    const facility = (
      await run(a.db, { action: 'facility.create', name: 'Frantoio test' })
    ).id;
    const person = (
      await run(a.db, {
        action: 'producer.create',
        name: 'Conferente',
        city: 'Bari',
      })
    ).id;
    const silo = (
      await run(a.db, {
        action: 'container.create',
        facility_id: facility,
        code: 'S1',
        volume_unit: 'L',
        capacity_l: 1000,
      })
    ).id;
    const small = (
      await run(a.db, {
        action: 'format.create',
        name: 'Vetro 0,75 L',
        capacity_l: 0.75,
        active: true,
      })
    ).id;
    const large = (
      await run(a.db, {
        action: 'format.create',
        name: 'Latta 5 L',
        capacity_l: 5,
        active: true,
      })
    ).id;
    await fn({ ...a, facility, person, silo, small, large });
  } finally {
    await a.close();
  }
}
const receive = (f, extra = {}) =>
  run(f.db, {
    action: 'oil.receive',
    ownership: 'own',
    source: 'purchased',
    supplier_id: f.person,
    label: 'Acquisto test',
    quality: 'normal',
    category: 'extra',
    origin: 'Italia',
    format: 'bulk',
    container_id: f.silo,
    amount: 100,
    volume_unit: 'L',
    ...doc,
    ...extra,
  });
async function production(f, extra = {}) {
  const { id } = await run(f.db, {
    action: 'batch.create',
    producer_id: f.person,
    facility_id: f.facility,
    variety: 'Coratina',
    origin: 'Italia',
    gross: 1000,
    tare: 0,
    olive_source: 'own',
    quality: 'normal',
    ...extra.batch,
  });
  await run(f.db, { action: 'batch.start', id, revision: 0 });
  const finish = {
    action: 'batch.complete',
    id: String(id),
    revision: 1,
    oil: 150,
    volume_unit: 'L',
    destination: 'store',
    container_id: f.silo,
    pomace: 500,
    wastewater: 250,
    ...extra.finish,
  };
  const result = await run(f.db, finish);
  return {
    id,
    eventId: (await readData(f.db)).events.at(-1).id,
    finish,
    result,
  };
}
async function correct(f, eventId, fields) {
  const data = await readData(f.db);
  const event = effectiveEvents(data.events).find((e) => e.id === eventId);
  const original = JSON.parse(JSON.parse(event.payload_json).request);
  return run(f.db, {
    action: 'operation.correct',
    event_id: eventId,
    expected_sequence: data.events.at(-1).seq,
    reason: 'Correzione dato di prova',
    replacement: { ...original, ...fields },
  });
}

void test('unità: 91,6 kg e 100 L sono la stessa quantità canonica', () => {
  assert.equal(inputMl('91,6', 'kg', 'Olio'), 100000);
  assert.equal(inputMl(100, 'L', 'Olio'), 100000);
  assert.equal(toGrams(100000), 91600);
  assert.equal(toMl(91600), 100000);
  assert.throws(() => inputMl(1, 'galloni', 'Olio'));
});
void test('silos: soglie esatte grigio/rosso/giallo/verde', () => {
  for (const [amount, state] of [
    [0, 'empty'],
    [1, 'low'],
    [99, 'low'],
    [100, 'medium'],
    [500, 'medium'],
    [501, 'high'],
    [1000, 'high'],
  ])
    assert.equal(fillLevel(amount, 1000).state, state);
});
void test('produzione: tipologie, tre prodotti, silos e resa unica', () =>
  fixture(async (f) => {
    const p = await production(f, {
      batch: { quality: 'dop_bio', designation: 'Terra di Bari' },
      finish: {
        olive_quality: 'dop_bio',
        olive_designation: 'Terra di Bari',
        oil_quality: 'bio',
        oil: 137.4,
        volume_unit: 'kg',
      },
    });
    const d = await readData(f.db),
      b = d.batches.find((b) => b.id === p.id);
    assert.equal(b.oil_ml, 150000);
    assert.equal(b.stock_ml, 150000);
    assert.equal(b.stock_g, 137400);
    assert.equal(b.pomace_g, 500000);
    assert.equal(b.wastewater_ml, 250000);
    assert.equal(d.lots[0].quality, 'bio');
    assert.equal(d.lots[0].category, 'pending');
    const stats = campaignStats(d, 2026);
    assert.equal(stats.count, 1);
    assert.equal(stats.oil_ml, 150000);
    assert.equal(stats.mass_yield, 13.74);
    assert.equal(stats.volume_yield, 15);
  }));
void test('produzione: conto terzi ritirato subito e certificazione non inventata', () =>
  fixture(async (f) => {
    await production(f, {
      batch: { olive_source: 'third_party' },
      finish: { destination: 'return' },
    });
    const d = await readData(f.db);
    assert.equal(d.deliveries[0].amount_ml, 150000);
    assert.equal(d.stocks.length, 0);
    assert.equal(d.batches[0].stock_ml, 0);
    await assert.rejects(
      production(f, { finish: { oil_quality: 'bio' } }),
      /tipologia|certifica|biolog/i,
    );
  }));
void test('imbottigliamento misto: scarico automatico, vendita e formato fotografato', () =>
  fixture(async (f) => {
    const { id } = await receive(f, { amount: 91.6, volume_unit: 'kg' });
    const command = {
      action: 'oil.bottle',
      requestId: 'mixed-bottle-001',
      stock_id: id,
      package_code: 'MIX',
      items: [
        { format_id: f.small, units: 10 },
        { format_id: f.large, units: 2 },
      ],
    };
    await run(f.db, command);
    await run(f.db, command);
    let d = await readData(f.db);
    assert.equal(d.stocks[0].amount_ml, 82500);
    assert.equal(
      d.packages.reduce((n, p) => n + p.consumed_ml, 0),
      17500,
    );
    assert.equal(
      d.packages.reduce((n, p) => n + p.consumed_g, 0),
      16030,
    );
    await run(f.db, {
      action: 'package.sell',
      package_id: 'mixed-bottle-001-1',
      customer_id: f.person,
      units: 3,
      ...doc,
    });
    await run(f.db, {
      action: 'format.update',
      id: f.small,
      name: 'Vetro nuovo',
      capacity_l: 1,
      active: false,
    });
    d = await readData(f.db);
    const pack = d.packages.find((p) => p.id === 'mixed-bottle-001-1');
    assert.equal(pack.units, 7);
    assert.equal(pack.unit_ml, 750);
    assert.equal(pack.format_name, 'Vetro 0,75 L');
    assert.equal(campaignStats(d, 2026).sold_ml, 2250);
    assert.equal(campaignStats(d, 2026).oil_ml, 0);
  }));
void test('imbottigliamento: quantità insufficienti, formati estranei e righe duplicate non cambiano stock', () =>
  fixture(async (f) => {
    const { id } = await receive(f, { amount: 10 });
    for (const items of [
      [{ format_id: f.large, units: 3 }],
      [{ format_id: 'format-other-company', units: 1 }],
      [
        { format_id: f.small, units: 1 },
        { format_id: f.small, units: 1 },
      ],
    ])
      await assert.rejects(
        run(f.db, {
          action: 'oil.bottle',
          stock_id: id,
          package_code: 'ERR',
          items,
        }),
      );
    assert.equal((await readData(f.db)).stocks[0].amount_ml, 10000);
  }));
void test('rettifiche: produzione già imbottigliata e venduta, due correzioni e audit intatto', () =>
  fixture(async (f) => {
    const p = await production(f);
    await run(f.db, {
      action: 'oil.classify',
      lot_id: p.eventId,
      category: 'extra',
      ...doc,
    });
    const bottle = await run(f.db, {
      action: 'oil.bottle',
      stock_id: p.eventId,
      package_code: 'RET',
      items: [{ format_id: f.large, units: 10 }],
    });
    await run(f.db, {
      action: 'package.sell',
      package_id: bottle.id + '-1',
      customer_id: f.person,
      units: 2,
      ...doc,
    });
    const old = (await readData(f.db)).events.find(
      (e) => e.id === p.eventId,
    ).payload_json;
    await correct(f, p.eventId, { oil: 160 });
    await correct(f, p.eventId, { oil: 170 });
    let d = await readData(f.db);
    assert.equal(d.stocks[0].amount_ml, 120000);
    assert.equal(d.packages[0].units, 8);
    assert.equal(d.events.find((e) => e.id === p.eventId).payload_json, old);
    assert.equal(
      d.events.filter((e) => e.action === 'operation.correct').length,
      2,
    );
    await assert.rejects(correct(f, p.eventId, { oil: 40 }), /giacenza/i);
    d = await readData(f.db);
    assert.equal(d.stocks[0].amount_ml, 120000);
    assert.equal(campaignStats(d, 2026).oil_ml, 170000);
  }));
void test('campagne: 31 luglio e 1 agosto, produzioni kg/L sommate insieme', () => {
  assert.equal(campaignYear('2026-07-31'), 2025);
  assert.equal(campaignYear('2026-08-01'), 2026);
  const data = {
    events: [],
    batches: [
      {
        date: '2026-07-31',
        production_date: '2026-07-31',
        status: 'done',
        net_g: 1000000,
        oil_g: 91600,
        oil_ml: null,
      },
      {
        date: '2026-08-01',
        production_date: '2026-08-01',
        status: 'done',
        net_g: 1000000,
        oil_g: 91600,
        oil_ml: null,
      },
      {
        date: '2026-08-01',
        production_date: '2026-08-01',
        status: 'done',
        net_g: 1000000,
        oil_g: 0,
        oil_ml: 100000,
      },
    ],
  };
  assert.equal(campaignStats(data, 2025).oil_ml, 100000);
  assert.equal(campaignStats(data, 2026).oil_ml, 200000);
  assert.equal(campaignStats(data, 2026).count, 2);
  assert.equal(campaignStats(data, 2026).mass_yield, 9.16);
});
void test('legacy: replay kg con consumo storico e due rettifiche senza reinterpretazione', () =>
  fixture(async (f) => {
    // Imported kilogram records and their original events are reproduced before migration.
    const legacyWrite = (input) =>
      companyTransaction(f.db.actorId, f.db.tenantId, true, async (store) => {
        const before = await readData(f.db);
        const result = applyOperation(
          before,
          { date, ...input },
          '2026-09-05T10:00:00.000Z',
          true,
        );
        return commit(
          store,
          before,
          result.data,
          { date, ...input },
          result.date,
          result.result,
          result.context,
        );
      });
    // Only the new legacy silo has native kg quantities.
    await legacyWrite({
      action: 'container.create',
      requestId: 'legacy-silo-01',
      code: 'OLD',
      facility_id: f.facility,
      capacity: 1000,
    });
    await legacyWrite({
      action: 'oil.receive',
      requestId: 'legacy-oil-01',
      ownership: 'own',
      source: 'purchased',
      supplier_id: f.person,
      label: 'OLD',
      quality: 'normal',
      category: 'extra',
      origin: 'Italia',
      format: 'bulk',
      container_id: 'legacy-silo-01',
      amount: 100,
      ...doc,
    });
    await legacyWrite({
      action: 'oil.bottle',
      requestId: 'legacy-bottle-01',
      stock_id: 'legacy-oil-01',
      amount: 5,
      units: 10,
      unit_ml: 750,
      package_code: 'OLD-B',
    });
    await f.client.query(
      'UPDATE containers SET capacity_ml=round(capacity_g::numeric*1000/916) WHERE tenant_id=$1 AND capacity_ml IS NULL',
      [f.db.tenantId],
    );
    await f.client.query(
      'UPDATE oil_stocks SET amount_ml=round(amount_g::numeric*1000/916) WHERE tenant_id=$1 AND amount_ml IS NULL',
      [f.db.tenantId],
    );
    await f.client.query(
      'UPDATE packages SET consumed_ml=round(consumed_g::numeric*1000/916),density_g_l=916 WHERE tenant_id=$1',
      [f.db.tenantId],
    );
    await correct(f, 'legacy-oil-01', { label: 'OLD corrected' });
    await correct(f, 'legacy-oil-01', { label: 'OLD corrected twice' });
    const d = await readData(f.db);
    assert.equal(
      d.stocks.find((s) => s.id === 'legacy-oil-01').amount_ml,
      toMl(95000),
    );
    assert.equal(d.packages[0].consumed_ml, toMl(5000));
    assert.equal(d.packages[0].initial_units, 10);
  }));
