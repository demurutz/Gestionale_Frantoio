# Prova guidata SaaS

Usa esclusivamente dati inventati. Avvia AVVIA_WINDOWS.cmd e apri http://127.0.0.1:3000/login. Le password sono nei file .local/credenziali-demo-*.json.

## Aziende e ruoli

1. Accedi con admin@frantoio.test e seleziona Coratina.
2. In Conferenti aggiungi una nuova anagrafica con nome riconoscibile.
3. Passa a Leccino: quell'anagrafica non deve comparire.
4. In un browser separato o finestra privata accedi come operatore.coratina@frantoio.test: deve essere disponibile solo Coratina.
5. Il profilo lettore.coratina@frantoio.test può consultare/esportare, ma non registrare operazioni.
6. In Azienda e utenti crea un utente; cambiane il ruolo o disabilitalo. Al successivo accesso all'API il nuovo permesso deve essere effettivo.
7. Prova a rimuovere l'ultimo amministratore: l'applicazione deve rifiutare.
8. Cambia password in Account: tutte le sessioni dell'utente devono essere revocate.

## Flusso conto proprio

1. Nell'azienda Coratina censisci due stabilimenti e due silos da almeno 500 L. In Confezioni crea “Vetro 0,75 L” e “Latta 5 L”.
2. Carica una partita di olive proprie: lordo 1050 kg, tara 50 kg, netto 1000 kg, tipologia biologica. Digita i pesi senza separatori delle migliaia.
3. Avvia la molitura e completala con 150 L di olio biologico, 500 kg di sansa e 250 L di acqua di vegetazione; scegli il primo silos. Verifica i tre prodotti nella relativa scheda.
4. Classifica il lotto come extravergine, inserendo riferimento e data dell'analisi.
5. Trasferisci 40 L nel secondo stabilimento, indicando documento e data: totale sfuso sempre 150 L.
6. Dal secondo silos imbottiglia 20 bottiglie da 0,75 L e 2 latte da 5 L: scarico automatico 25 L, totale sfuso residuo 125 L.
7. Vendi 5 bottiglie: restano 15 bottiglie e 2 latte, cioè 21,25 L confezionati.
8. In alto passa da litri a kg: 125 L sfusi diventano circa 114,5 kg. Torna ai litri: il saldo e il numero di operazioni non devono cambiare. La densità usata è sempre 0,916 kg/L.

## Flusso conto terzi

1. Censisci un contenitore vuoto.
2. Carica olive del cliente, avvia e completa la molitura scegliendo il deposito: l'olio resta del cliente e in attesa di classificazione.
3. Registra un ritiro parziale: controlla quantità residua e storico.
4. Su una seconda partita scegli il ritiro immediato: non deve crearsi una giacenza sfusa.
5. Non deve essere possibile vendere come proprio l'olio conto terzi né trasferirlo a un altro stabilimento.

## Silos, rettifiche e campagne

- Nella scheda Silos verifica le percentuali: vuoto grigio; meno del 10% rosso; dal 10% al 50% giallo; oltre il 50% verde. Il cambio kg/litri non cambia le percentuali.
- Come amministratore, dal Registro scegli Modifica sulla produzione: correggi 150 in 160 L e inserisci il motivo. Le confezioni e vendite rimangono; lo sfuso aumenta di 10 L. Prova una quantità inferiore a quella già scaricata: deve essere rifiutata.
- Modifica nome/capacità di un formato nel catalogo: le confezioni già prodotte devono conservare nome e capacità precedenti.
- In Campagne confronta due anni: le operazioni fino al 31 luglio appartengono alla campagna precedente, dal 1 agosto alla nuova. Gli acquisti non entrano nella produzione. Olive, olio, resa, sansa, acqua, imbottigliato e venduto devono riferirsi al periodo selezionato.

## Acquisti, controlli e registro

- Carica olio proprio acquistato da un cliente/fornitore, sia sfuso sia già imbottigliato.
- Prova a superare la capacità di un contenitore, a mischiare lotti e a vendere più bottiglie delle disponibili: operazioni rifiutate.
- Da due finestre prova scarichi concorrenti: il totale non deve mai diventare negativo.
- Esporta il registro JSON: deve contenere solo l'azienda selezionata, con autore delle nuove operazioni.
- Il JSON non è un file pronto da inviare al SIAN.
- Arresta con Ctrl+C, riavvia e verifica che le registrazioni siano ancora presenti.

## Verifiche automatiche

Esegui `pnpm test:postgres`. Crea un nuovo cluster PostgreSQL temporaneo con credenziali casuali: non usa il database delle prove manuali. Copre flussi, importazione storico, concorrenza, rollback, RLS, ruoli, CSRF e revoca delle sessioni.
