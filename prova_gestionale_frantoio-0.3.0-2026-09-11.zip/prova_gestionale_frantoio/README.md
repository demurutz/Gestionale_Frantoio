# Gestionale Frantoio — versione SaaS locale

Next.js/React, backend TypeScript e PostgreSQL. Il browser non salva l'archivio: i dati risiedono nel database, separati per azienda. Questa fase è dedicata allo sviluppo locale; nessun servizio cloud è stato pubblicato.

## Avvio rapido su Windows

1. Installa **Node.js 24**.
2. Scarica tutta la cartella, inclusi i file nascosti.
3. Apri **AVVIA_WINDOWS.cmd** e attendi. La prima installazione richiede Internet.
4. Apri **http://127.0.0.1:3000/login**. Usa questo indirizzo esatto, coerente con APP_ORIGIN.
5. Le password demo sono generate casualmente al primo setup, nei file **.local/credenziali-demo-*.json**. Apri il file sul tuo PC: non pubblicarlo.

Il comando avvia un vero PostgreSQL 18 locale, senza Docker, servizi Windows o account cloud. Lascia aperto il terminale. Ctrl+C arresta applicazione e database; i dati rimangono in `.local/postgres`.

Account di prova:

| Email | Aziende | Ruolo |
| --- | --- | --- |
| admin@frantoio.test | Coratina e Leccino | Amministratore |
| operatore.coratina@frantoio.test | Coratina | Operatore |
| lettore.coratina@frantoio.test | Coratina | Sola lettura |
| operatore.leccino@frantoio.test | Leccino | Operatore |

L'amministratore cambia azienda dalla barra in alto e gestisce utenti e dati aziendali in **Azienda e utenti**. Ogni utente cambia la propria password in **Account**.

## Avvio da terminale

```powershell
npx --yes pnpm@11.19.0 install --frozen-lockfile
npx --yes pnpm@11.19.0 local
```

Comandi utili:

| Comando | Scopo |
| --- | --- |
| pnpm run setup | Prepara database e aziende demo, poi arresta PostgreSQL |
| pnpm local | Avvia PostgreSQL e applicazione insieme |
| pnpm db:start | Avvia solo PostgreSQL, per i comandi amministrativi |
| pnpm db:migrate | Applica le migrazioni SQL versionate al database configurato |
| pnpm db:seed | Aggiunge i dati demo senza azzerare quelli esistenti, solo in locale |
| pnpm typecheck / pnpm lint | Controlli statici |
| pnpm test:postgres | Test su un nuovo PostgreSQL temporaneo, senza toccare gli archivi locali |
| pnpm build | Compilazione Next.js per produzione |
| pnpm start | Avvia la compilazione, con PostgreSQL già disponibile |

`pnpm test` è il runner interno e rifiuta il database applicativo: per una prova completa usare `pnpm test:postgres`.

## Funzioni disponibili

- Anagrafiche di conferenti, clienti e fornitori; stabilimenti e contenitori.
- Carico olive con lordo/tara/netto, normali/D.O.P./bio/D.O.P. bio, olive proprie/acquistate/conto terzi.
- Avvio e chiusura molitura, tipologie olive/olio, resa e proprietà; tre prodotti distinti: olio, sansa (kg), acqua di vegetazione (L).
- Olio prodotto o acquistato; deposito conto terzi in attesa di classificazione oppure ritiro immediato.
- Classificazione, ritiri parziali e trasferimento dell'olio proprio tra stabilimenti.
- Unica giacenza olio in litri, visualizzabile in kg con densità fissa 0,916 kg/L; inserimento olio e capacità silos in entrambe le unità.
- Sfuso e confezionato distinti; catalogo confezioni, imbottigliamento con più formati e scarico automatico, vendita dell'olio proprio e ritiro conto terzi.
- Scheda Silos con riempimento grigio (vuoto), rosso (sotto 10%), giallo (10–50%), verde (oltre 50%).
- Confronto campagne dal 1 agosto al 31 luglio, produzione e resa ponderata, sottoprodotti, imbottigliato e venduto.
- Modifica operazioni dal Registro per gli amministratori, con motivo, storico immutabile e controllo delle operazioni successive.
- Registro atomico con autore, documenti, quantità e storico; esportazioni CSV e JSON per azienda.
- Login, scadenza/revoca sessioni, cambio password, aziende e permessi server.

**L'export SIAN è ancora un formato JSON intermedio**, non un file certificato o direttamente trasmissibile. Non sono implementate emissione fiscale, trasmissione SIAN o email automatiche. Vedi `docs/sian-export.md`.

## Quantità e modifiche

L’olio è memorizzato in millilitri interi (precisione 0,001 L). Il selettore **Mostra olio in** cambia soltanto la visualizzazione: kg = L × 0,916. Le quantità derivate in kg sono indicate come approssimate. Olive e sansa rimangono in kg; acqua e capacità delle confezioni in litri. Lo scarico di imbottigliamento è la somma delle capacità dei formati per i pezzi riempiti.

Gli importi storici originali restano nel registro; i saldi precedenti in kg vengono convertiti automaticamente. Non ripetere carichi per effettuare il cambio unità. Le colonne kg dell’olio sono di compatibilità, non una seconda giacenza.

Le rettifiche non cancellano gli eventi: ricalcolano i movimenti successivi e vengono rifiutate se producono giacenze negative, superano capacità o cambiano la struttura dei movimenti (ad esempio numero di righe di confezionamento). Storici incompleti o ambigui richiedono verifica e non vengono reinterpretati automaticamente. Per i formati già usati, nome e capacità delle confezioni prodotte restano quelli originali.

## Dati e configurazione

`.env` contiene configurazione e credenziali locali; viene generato senza sovrascrivere un file esistente. `.env.example` è il modello pubblicabile. Il web server usa solo **DATABASE_URL**, con un ruolo limitato; **DATABASE_ADMIN_URL** è riservato agli script amministrativi.

Per PostgreSQL già installato, configura entrambi gli URL, **LOCAL_POSTGRES=false**, APP_ORIGIN e DATABASE_SSL. Applica le migrazioni e avvia Next.js. Le credenziali amministrative non sono necessarie al processo web. Per un futuro container, il comando di avvio potrà usare `next start --hostname 0.0.0.0`; dominio, TLS e backup saranno collaudati nella fase cloud.

Non caricare su GitHub `.env`, `.local`, `.wrangler`, `node_modules`, `backups` o esportazioni aziendali. La copia GitHub precedente non viene sincronizzata automaticamente.

Se sposti nuovamente la cartella, i collegamenti pnpm potrebbero richiedere una reinstallazione. Conserva `.env` e `.local`; non cancellarli per risolvere problemi di dipendenze.

## Archivio precedente e altre aziende

Il vecchio SQLite in `.wrangler/state` non viene modificato. L'importatore controllato trasferisce lo storico solo in un'azienda vuota, senza inventare proprietà o autori mancanti; istruzioni in `docs/saas-migration.md`.

Per creare un'azienda vuota con il suo amministratore, con PostgreSQL avviato:

```powershell
node --env-file=.env scripts/company-create.mjs "Frantoio di prova" "responsabile@example.test"
```

Le credenziali iniziali e l'ID azienda vengono salvati in un file privato sotto `.local`. Per associare intenzionalmente un account già esistente, aggiungi `--existing-user`: è un comando riservato all'amministratore della piattaforma.

Vedi **PROVA_GUIDATA.md** per il collaudo manuale e **docs/saas-architecture.md** per struttura e limiti.

## Verifiche eseguite

Collaudo delle nuove funzioni: 48 test su PostgreSQL reale, comprendenti conversione kg/litri, imbottigliamento misto, rettifiche successive e campagne. Le prove usano un database temporaneo, separato da quello applicativo. Compilazione Next.js riuscita; login, dashboard, API dati ed export JSON 2.0.0 verificati via HTTP nelle due aziende demo. Nessun movimento registrato dal controllo HTTP. L’interfaccia richiede ancora una prova manuale seguendo la guida; nessun collaudo cloud eseguito.

I test includono operazioni concorrenti, isolamento fra aziende, revoca delle sessioni, recupero di un setup interrotto e importazione coerente dello storico SQLite. Non sostituiscono la prova manuale dell'interfaccia né il futuro collaudo cloud.
