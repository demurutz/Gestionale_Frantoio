import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import { tables } from '../lib/archive-tables.ts';

export async function importSqlite(sqlite, client, tenantId) {
  await client.query('BEGIN');
  let snapshot = false;
  try {
    sqlite.exec('BEGIN');
    snapshot = true;
    const company = await client.query(
      'SELECT id FROM companies WHERE id=$1 FOR UPDATE',
      [tenantId],
    );
    if (!company.rowCount)
      throw new Error('Azienda di destinazione non trovata.');
    await client.query("SELECT set_config('app.tenant_id',$1,true)", [
      tenantId,
    ]);
    for (const [table] of Object.values(tables))
      if (
        (
          await client.query(
            'SELECT 1 FROM ' + table + ' WHERE tenant_id=$1 LIMIT 1',
            [tenantId],
          )
        ).rowCount
      )
        throw new Error('Importazione consentita solo in un’azienda vuota.');
    if (
      (
        await client.query('SELECT 1 FROM events WHERE tenant_id=$1 LIMIT 1', [
          tenantId,
        ])
      ).rowCount
    )
      throw new Error('Registro destinazione non vuoto.');
    const sourceTables = new Set(
      sqlite
        .prepare("SELECT name FROM sqlite_master WHERE type='table'")
        .all()
        .map((r) => r.name),
    );
    for (const table of ['producers', 'batches', 'deliveries']) {
      if (!sourceTables.has(table))
        throw new Error(
          'Archivio SQLite non riconosciuto: manca la tabella ' + table + '.',
        );
    }
    const counts = {};
    const defaults = {
      production_date: '',
      format_name: '',
      phone: '',
      fiscal_id: '',
      address: '',
      country: 'IT',
      facility_id: null,
      olive_source: 'unknown',
      quality: 'unknown',
      designation: '',
      document: '',
      document_date: '',
      revision: 0,
      last_request: '',
      started_at: null,
      completed_at: null,
      consumed_g: 0,
    };
    for (const [table, list] of Object.values(tables)) {
      const columns = list.split(' '),
        rows = sourceTables.has(table)
          ? sqlite.prepare('SELECT * FROM ' + table).all()
          : [];
      for (const row of rows) {
        const values = columns.map((c) =>
          row[c] === undefined
            ? Object.hasOwn(defaults, c)
              ? defaults[c]
              : null
            : row[c],
        );
        const names = ['tenant_id', ...columns];
        await client.query(
          'INSERT INTO ' +
            table +
            '(' +
            names.join(',') +
            ') VALUES(' +
            names.map((_, i) => '$' + (i + 1)).join(',') +
            ')',
          [tenantId, ...values],
        );
      }
      counts[table] = rows.length;
    }
    const events = sourceTables.has('events')
      ? sqlite.prepare('SELECT * FROM events ORDER BY seq').all()
      : [];
    for (const e of events)
      await client.query(
        'INSERT INTO events(tenant_id,seq,id,action,date,created_at,payload_json,actor_id) VALUES($1,$2,$3,$4,$5,$6,$7,NULL)',
        [tenantId, e.seq, e.id, e.action, e.date, e.created_at, e.payload_json],
      );
    await client.query(
      "UPDATE batches b SET production_date=e.date FROM events e WHERE b.tenant_id=$1 AND e.tenant_id=b.tenant_id AND e.action='batch.complete' AND e.payload_json::jsonb->>'batch_id'=b.id::text",
      [tenantId],
    );
    // Normalize only this imported company, preserving original masses and audit.
    for (const [table, mass, volume, condition] of [
      ['containers', 'capacity_g', 'capacity_ml', ''],
      ['oil_stocks', 'amount_g', 'amount_ml', ''],
      ['batches', 'oil_g', 'oil_ml', " AND status='done'"],
      ['deliveries', 'amount_g', 'amount_ml', ''],
      ['packages', 'consumed_g', 'consumed_ml', ''],
    ])
      await client.query(
        'UPDATE ' +
          table +
          ' SET ' +
          volume +
          '=round(' +
          mass +
          '::numeric*1000/916)::integer WHERE tenant_id=$1 AND ' +
          volume +
          ' IS NULL' +
          condition,
        [tenantId],
      );
    await client.query(
      'UPDATE packages SET density_g_l=916 WHERE tenant_id=$1 AND consumed_ml>0 AND density_g_l IS NULL',
      [tenantId],
    );
    await client.query(
      'INSERT INTO security_events(company_id,action,details) VALUES($1,$2,$3)',
      [
        tenantId,
        'legacy.import',
        JSON.stringify({ counts, events: events.length, source: 'SQLite' }),
      ],
    );
    await client.query('COMMIT');
    return { ...counts, events: events.length };
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    if (snapshot) sqlite.exec('ROLLBACK');
  }
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const [file, tenantId] = process.argv.slice(2);
  if (!file || !/^[0-9a-f-]{36}$/i.test(tenantId ?? ''))
    throw new Error(
      'Uso: node --env-file=.env scripts/import-sqlite.mjs PERCORSO_SQLITE UUID_AZIENDA_VUOTA',
    );
  const sqlite = new DatabaseSync(file, { readOnly: true });
  const client = new pg.Client({
    connectionString: process.env.DATABASE_ADMIN_URL,
  });
  await client.connect();
  try {
    console.log(await importSqlite(sqlite, client, tenantId));
  } finally {
    sqlite.close();
    await client.end();
  }
}
