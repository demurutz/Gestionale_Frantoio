import EmbeddedPostgres from 'embedded-postgres';
import { mkdtemp, readdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
import { createServer } from 'node:net';
import { spawn } from 'node:child_process';
import { migrate } from './migrate.mjs';

const reserve = createServer();
await new Promise((resolve) => reserve.listen(0, '127.0.0.1', resolve));
const port = reserve.address().port;
await new Promise((resolve) => reserve.close(resolve));
const directory = await mkdtemp(join(tmpdir(), 'frantoio-postgres-test-'));
const admin = randomBytes(24).toString('hex'),
  app = randomBytes(24).toString('hex');
const cluster = new EmbeddedPostgres({
  databaseDir: join(directory, 'data'),
  port,
  user: 'postgres',
  password: admin,
  persistent: true,
  authMethod: 'scram-sha-256',
  createPostgresUser: false,
  initdbFlags: ['--encoding=UTF8'],
  postgresFlags: ['-h', '127.0.0.1'],
  onLog: () => {},
  onError: () => {},
});
let child;
let testExitCode = 1;
try {
  await cluster.initialise();
  await cluster.start();
  await cluster.createDatabase('frantoio_test');
  const env = {
    ...process.env,
    DATABASE_ADMIN_URL:
      'postgresql://postgres:' +
      admin +
      '@127.0.0.1:' +
      port +
      '/frantoio_test',
    DATABASE_URL:
      'postgresql://frantoio_app:' +
      app +
      '@127.0.0.1:' +
      port +
      '/frantoio_test',
    DATABASE_SSL: 'false',
    APP_ORIGIN: 'http://127.0.0.1:3000',
    FRANTOIO_TEST_DATABASE: 'isolated',
  };
  await migrate(env.DATABASE_ADMIN_URL, env.DATABASE_URL);
  const files = (await readdir(new URL('../tests/', import.meta.url)))
    .filter((n) => n.endsWith('.test.mjs'))
    .map((n) => resolve('tests', n));
  child = spawn(process.execPath, ['--test', ...files], {
    stdio: 'inherit',
    env,
    windowsHide: true,
  });
  const code = await new Promise((resolve, reject) => {
    child.on('error', reject);
    child.on('exit', resolve);
  });
  testExitCode = code ?? 1;
  console.log(
    'Test eseguiti su PostgreSQL reale, archivio applicativo non toccato.',
  );
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  testExitCode = 1;
} finally {
  if (child && child.exitCode == null && !child.killed) child.kill();
  try {
    await cluster.stop();
  } catch (error) {
    console.error('Chiusura PostgreSQL di test non riuscita:', error);
    testExitCode = 1;
  }
}
// embedded-postgres installs a beforeExit hook that would replace exitCode with 0.
process.exit(testExitCode);
