import pg from 'pg';
import { readFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

export async function migrate(
  adminUrl = process.env.DATABASE_ADMIN_URL,
  appUrl = process.env.DATABASE_URL,
) {
  if (!adminUrl || !appUrl)
    throw new Error('Configurare DATABASE_ADMIN_URL e DATABASE_URL.');
  const app = new URL(appUrl);
  if (decodeURIComponent(app.username) !== 'frantoio_app')
    throw new Error('La migrazione iniziale richiede il ruolo frantoio_app.');
  const password = decodeURIComponent(app.password);
  if (password.length < 20 || password === 'CHANGE_ME')
    throw new Error('Password database applicativo troppo corta.');
  const client = new pg.Client({
    connectionString: adminUrl,
    ssl:
      process.env.DATABASE_SSL === 'true'
        ? { rejectUnauthorized: true }
        : false,
  });
  await client.connect();
  try {
    await client.query('SELECT pg_advisory_lock(741529001)');
    if (
      !(
        await client.query(
          "SELECT 1 FROM pg_roles WHERE rolname='frantoio_app'",
        )
      ).rowCount
    ) {
      // SQL identifiers are fixed; PostgreSQL role DDL cannot bind a password parameter.
      await client.query(
        "CREATE ROLE frantoio_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS PASSWORD '" +
          password.replaceAll("'", "''") +
          "'",
      );
    }
    await client.query(
      'CREATE TABLE IF NOT EXISTS schema_migrations(name text PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())',
    );
    const directory = new URL('../db/migrations/', import.meta.url);
    for (const name of (await readdir(directory))
      .filter((n) => n.endsWith('.sql'))
      .sort()) {
      const sql = await readFile(new URL(name, directory), 'utf8');
      const checksum = createHash('sha256').update(sql).digest('hex');
      const previous = await client.query(
        'SELECT checksum FROM schema_migrations WHERE name=$1',
        [name],
      );
      if (previous.rowCount) {
        if (previous.rows[0].checksum !== checksum)
          throw new Error('Migrazione già applicata modificata: ' + name);
        continue;
      }
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query(
          'INSERT INTO schema_migrations(name,checksum) VALUES($1,$2)',
          [name, checksum],
        );
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      }
      console.log('Migrazione applicata: ' + name);
    }
  } finally {
    await client.end();
  }
}
if (process.argv[1] === fileURLToPath(import.meta.url)) await migrate();
