import { existsSync } from 'node:fs';
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import EmbeddedPostgres from 'embedded-postgres';
import { migrate } from './migrate.mjs';
import { seed } from './seed.mjs';
import { pool } from '../db/index.ts';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
process.chdir(root);
if (Number(process.versions.node.split('.')[0]) !== 24)
  throw new Error('Installa Node.js 24.');
const action = process.argv[2] ?? 'start';
if (!['setup', 'start', 'database'].includes(action))
  throw new Error('Usa setup, start oppure database.');
await mkdir('.local', { recursive: true });
let generated = false;
if (!existsSync('.env')) {
  const admin = randomBytes(24).toString('hex'),
    app = randomBytes(24).toString('hex');
  await writeFile(
    '.env',
    [
      'APP_ORIGIN=http://127.0.0.1:3000',
      'DATABASE_URL=postgresql://frantoio_app:' +
        app +
        '@127.0.0.1:54329/frantoio',
      'DATABASE_ADMIN_URL=postgresql://postgres:' +
        admin +
        '@127.0.0.1:54329/frantoio',
      'LOCAL_POSTGRES=true',
      'DATABASE_SSL=false',
      'SESSION_HOURS=12',
      'NEXT_TELEMETRY_DISABLED=1',
    ].join('\n') + '\n',
    { flag: 'wx', mode: 0o600 },
  );
  generated = true;
}
process.loadEnvFile('.env');
let cluster,
  child,
  stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  if (child && !child.killed) child.kill('SIGTERM');
  await pool()
    .end()
    .catch(() => {});
  if (cluster) await cluster.stop();
}
try {
  if (process.env.LOCAL_POSTGRES === 'true') {
    const url = new URL(process.env.DATABASE_ADMIN_URL);
    if (url.hostname !== '127.0.0.1')
      throw new Error('PostgreSQL locale deve ascoltare solo su 127.0.0.1.');
    cluster = new EmbeddedPostgres({
      databaseDir: resolve('.local/postgres'),
      port: Number(url.port),
      user: decodeURIComponent(url.username),
      password: decodeURIComponent(url.password),
      persistent: true,
      authMethod: 'scram-sha-256',
      createPostgresUser: false,
      initdbFlags: ['--encoding=UTF8'],
      postgresFlags: ['-h', '127.0.0.1', '-c', 'max_connections=40'],
      onLog: () => {},
      onError: () => {},
    });
    if (!existsSync('.local/postgres/PG_VERSION')) await cluster.initialise();
    await cluster.start();
    const client = cluster.getPgClient('postgres');
    await client.connect();
    const name = url.pathname.slice(1);
    if (name !== 'frantoio')
      throw new Error('Il cluster locale automatico usa il database frantoio.');
    if (
      !(
        await client.query('SELECT 1 FROM pg_database WHERE datname=$1', [name])
      ).rowCount
    )
      await client.query('CREATE DATABASE frantoio');
    await client.end();
  }
  await migrate();
  if (
    generated ||
    action === 'setup' ||
    (process.env.LOCAL_POSTGRES === 'true' &&
      !existsSync('.local/setup-complete'))
  ) {
    await seed();
    if (process.env.LOCAL_POSTGRES === 'true')
      await writeFile('.local/setup-complete', '1\n', { mode: 0o600 });
  }
  if (action === 'setup') {
    await stop();
    console.log('Preparazione completata. Avvio: pnpm local');
  } else {
    process.on('SIGINT', () => void stop().finally(() => process.exit(0)));
    process.on('SIGTERM', () => void stop().finally(() => process.exit(0)));
    if (action === 'database') {
      console.log('PostgreSQL locale disponibile. Ctrl+C per arrestarlo.');
      await new Promise(() => {});
    }
    const origin = new URL(process.env.APP_ORIGIN);
    if (!['127.0.0.1', 'localhost'].includes(origin.hostname))
      throw new Error('pnpm local è riservato allo sviluppo su localhost.');
    console.log('Gestionale locale: ' + origin.origin);
    child = spawn(
      process.execPath,
      [
        resolve('node_modules/next/dist/bin/next'),
        'dev',
        '--hostname',
        origin.hostname,
        '--port',
        origin.port || '3000',
      ],
      { stdio: 'inherit', windowsHide: true, env: process.env },
    );
    const code = await new Promise((resolve, reject) => {
      child.on('error', reject);
      child.on('exit', resolve);
    });
    await stop();
    process.exitCode = Number(code) || 0;
  }
} catch (error) {
  await stop().catch(() => {});
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
}
