import pg from 'pg';
import { randomUUID, randomBytes } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { hashPassword } from '../lib/auth.ts';
import { companyTransaction, pool } from '../db/index.ts';
import { mutate } from '../lib/repository.ts';

export async function seed({
  credentialsDirectory = new URL('../.local/', import.meta.url),
} = {}) {
  if (process.env.NODE_ENV === 'production')
    throw new Error('Seed demo vietato in produzione.');
  const database = new URL(process.env.DATABASE_ADMIN_URL);
  if (!['127.0.0.1', 'localhost', '[::1]'].includes(database.hostname))
    throw new Error('Seed demo consentito solo su PostgreSQL locale.');
  const client = new pg.Client({
    connectionString: process.env.DATABASE_ADMIN_URL,
  });
  await client.connect();
  const created = [];
  const companies = [
    {
      id: '11111111-1111-4111-8111-111111111111',
      name: 'Frantoio Demo Coratina',
    },
    {
      id: '22222222-2222-4222-8222-222222222222',
      name: 'Frantoio Demo Leccino',
    },
  ];
  let adminId;
  let credentialsFile;
  try {
    await client.query('BEGIN');
    await client.query(
      "SELECT pg_advisory_xact_lock(hashtext('frantoio-demo-seed'))",
    );
    for (const c of companies)
      await client.query(
        'INSERT INTO companies(id,name) VALUES($1,$2) ON CONFLICT(id) DO NOTHING',
        [c.id, c.name],
      );
    for (const [email, name, roles] of [
      ['admin@frantoio.test', 'Amministratore demo', ['admin', 'admin']],
      [
        'operatore.coratina@frantoio.test',
        'Operatore Coratina',
        ['operator', null],
      ],
      ['lettore.coratina@frantoio.test', 'Lettore Coratina', ['viewer', null]],
      [
        'operatore.leccino@frantoio.test',
        'Operatore Leccino',
        [null, 'operator'],
      ],
    ]) {
      let user = (
        await client.query('SELECT id FROM users WHERE email=$1', [email])
      ).rows[0];
      if (!user) {
        const password = randomBytes(18).toString('base64url');
        user = { id: randomUUID() };
        await client.query(
          'INSERT INTO users(id,email,name,password_hash) VALUES($1,$2,$3,$4)',
          [user.id, email, name, await hashPassword(password)],
        );
        created.push({ email, password });
      }
      if (email === 'admin@frantoio.test') adminId = user.id;
      for (let i = 0; i < roles.length; i++)
        if (roles[i])
          await client.query(
            'INSERT INTO memberships(company_id,user_id,role) VALUES($1,$2,$3) ON CONFLICT DO NOTHING',
            [companies[i].id, user.id, roles[i]],
          );
    }
    if (created.length) {
      await mkdir(credentialsDirectory, { recursive: true });
      credentialsFile = new URL(
        'credenziali-demo-' + randomUUID() + '.json',
        credentialsDirectory,
      );
      await writeFile(credentialsFile, JSON.stringify(created, null, 2), {
        flag: 'wx',
        mode: 0o600,
      });
    }
    await client.query('COMMIT');
    if (credentialsFile)
      console.log(
        'Credenziali demo salvate in ' +
          fileURLToPath(credentialsFile) +
          ' (non pubblicare).',
      );
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    await client.end();
  }
  for (const company of companies) {
    await companyTransaction(adminId, company.id, true, async (store) => {
      for (const input of [
        {
          action: 'facility.create',
          requestId: 'demo-facility-01',
          name: 'Stabilimento principale',
          address: 'Via di prova 1',
          cuaa: 'DEMO',
          sian_code: 'DEMO',
        },
        {
          action: 'container.create',
          requestId: 'demo-container-01',
          facility_id: 'demo-facility-01',
          code: 'S-01',
          capacity: 1000,
        },
        {
          action: 'producer.create',
          requestId: 'demo-producer-01',
          name: 'Conferente dimostrativo',
          city: 'Bitonto',
          country: 'IT',
        },
      ])
        await mutate(store, { date: '2026-09-09', ...input });
    });
  }
  console.log(
    'Due aziende demo e quattro profili disponibili. I dati esistenti non sono stati azzerati.',
  );
  return { createdCount: created.length, credentialsFile };
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  try {
    await seed();
  } finally {
    await pool().end();
  }
}
