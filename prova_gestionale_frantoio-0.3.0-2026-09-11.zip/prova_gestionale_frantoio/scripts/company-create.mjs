import pg from 'pg';
import { randomUUID, randomBytes } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { hashPassword } from '../lib/auth.ts';

export async function createCompany(
  nameValue,
  emailValue,
  {
    existingUser = false,
    credentialsDirectory = new URL('../.local/', import.meta.url),
  } = {},
) {
  const name = String(nameValue ?? '').trim();
  const email = String(emailValue ?? '')
    .trim()
    .toLowerCase();
  if (
    !name ||
    name.length > 200 ||
    email.length > 254 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  )
    throw new Error(
      'Indica ragione sociale (massimo 200 caratteri) ed email valida.',
    );
  if (!process.env.DATABASE_ADMIN_URL)
    throw new Error(
      'DATABASE_ADMIN_URL richiesto: comando riservato alla piattaforma.',
    );
  const client = new pg.Client({
    connectionString: process.env.DATABASE_ADMIN_URL,
    ssl:
      process.env.DATABASE_SSL === 'true'
        ? { rejectUnauthorized: true }
        : undefined,
  });
  await client.connect();
  try {
    await client.query('BEGIN');
    let user = (
      await client.query(
        'SELECT id,active FROM users WHERE email=$1 FOR UPDATE',
        [email],
      )
    ).rows[0];
    if (user && !existingUser)
      throw new Error(
        'Account già esistente: usa --existing-user solo per associarlo intenzionalmente.',
      );
    if (existingUser && !user)
      throw new Error('Account esistente non trovato.');
    if (user && !user.active)
      throw new Error('Account disattivato: associazione non consentita.');
    const companyId = randomUUID();
    let password;
    if (!user) {
      password = randomBytes(18).toString('base64url');
      user = { id: randomUUID() };
      await client.query(
        'INSERT INTO users(id,email,name,password_hash) VALUES($1,$2,$3,$4)',
        [user.id, email, email.split('@')[0], await hashPassword(password)],
      );
    }
    await client.query('INSERT INTO companies(id,name) VALUES($1,$2)', [
      companyId,
      name,
    ]);
    await client.query(
      "INSERT INTO memberships(company_id,user_id,role) VALUES($1,$2,'admin')",
      [companyId, user.id],
    );
    await client.query(
      'INSERT INTO security_events(company_id,action,details) VALUES($1,$2,$3)',
      [
        companyId,
        'platform.company.create',
        JSON.stringify({ user_id: user.id, existing_user: existingUser }),
      ],
    );
    await mkdir(credentialsDirectory, { recursive: true });
    const credentialsFile = new URL(
      'azienda-' + companyId + '.json',
      credentialsDirectory,
    );
    await writeFile(
      credentialsFile,
      JSON.stringify(
        {
          companyId,
          companyName: name,
          email,
          ...(password
            ? { password }
            : {
                note: 'Usa la password già esistente. Non è stata modificata.',
              }),
        },
        null,
        2,
      ),
      { flag: 'wx', mode: 0o600 },
    );
    await client.query('COMMIT');
    return { companyId, credentialsFile };
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    await client.end();
  }
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const [name, email, flag, ...extra] = process.argv.slice(2);
  if (!name || !email || (flag && flag !== '--existing-user') || extra.length)
    throw new Error(
      'Uso: node --env-file=.env scripts/company-create.mjs "Ragione sociale" "email" [--existing-user]',
    );
  const result = await createCompany(name, email, {
    existingUser: flag === '--existing-user',
  });
  console.log('Azienda vuota creata: ' + result.companyId);
  console.log(
    'Dati di accesso privati: ' +
      fileURLToPath(result.credentialsFile) +
      ' (non pubblicare).',
  );
}
