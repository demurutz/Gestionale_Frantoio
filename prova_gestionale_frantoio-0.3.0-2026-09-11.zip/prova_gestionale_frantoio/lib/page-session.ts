import { headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { identity, cookieValue, companyCookie } from './auth';
import { config } from './config';
import { InputError } from './domain';
export async function pageSession() {
  const request = new Request(config().origin, { headers: await headers() });
  try {
    const user = await identity(request);
    const selected = cookieValue(request, companyCookie);
    const company =
      user.companies.find((c) => c.id === selected) ?? user.companies[0];
    return { user, company };
  } catch (error) {
    if (error instanceof InputError && error.status === 401) redirect('/login');
    throw error;
  }
}
