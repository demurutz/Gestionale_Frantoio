import { randomBytes, createHash, scrypt, timingSafeEqual } from 'node:crypto';
import { pool, transaction } from '../db/index.ts';
import { config } from './config.ts';
import { InputError, textField } from './domain.ts';
import type { Identity, Company } from './access.ts';

export const sessionCookie = 'frantoio_session';
export const companyCookie = 'frantoio_company';
export function digest(value: string) {
  return createHash('sha256').update(value).digest('hex');
}
const derive = (password: string, salt: string) =>
  new Promise<Buffer>((resolve, reject) => {
    scrypt(
      password,
      salt,
      64,
      { N: 32768, r: 8, p: 3, maxmem: 64 * 1024 * 1024 },
      (error, key) => (error ? reject(error) : resolve(key)),
    );
  });
export function passwordField(value: unknown, label = 'Password') {
  if (typeof value !== 'string' || !value.length || value.length > 128)
    throw new InputError(label + ': da 1 a 128 caratteri.');
  return value;
}
export async function hashPassword(password: string) {
  if (password.length < 12 || password.length > 128)
    throw new InputError('Password: da 12 a 128 caratteri.');
  const salt = randomBytes(16).toString('hex');
  return (
    'scrypt$' + salt + '$' + (await derive(password, salt)).toString('hex')
  );
}
export async function verifyPassword(password: string, hash: string) {
  if (typeof password !== 'string' || password.length > 128) return false;
  const [algorithm, salt, key] = hash.split('$');
  if (
    algorithm !== 'scrypt' ||
    !/^[0-9a-f]{32}$/.test(salt ?? '') ||
    !/^[0-9a-f]{128}$/.test(key ?? '')
  )
    return false;
  return timingSafeEqual(await derive(password, salt), Buffer.from(key, 'hex'));
}
export function cookieValue(request: Request, name: string) {
  const item = request.headers
    .get('cookie')
    ?.split(';')
    .map((s) => s.trim())
    .find((s) => s.startsWith(name + '='));
  return item?.slice(name.length + 1) ?? '';
}
export function cookie(name: string, value: string, maxAge: number) {
  return (
    name +
    '=' +
    value +
    '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' +
    maxAge +
    (config().secure ? '; Secure' : '')
  );
}
export async function identity(request: Request): Promise<Identity> {
  const token = cookieValue(request, sessionCookie);
  if (!/^[0-9a-f]{64}$/.test(token))
    throw new InputError('Accedi per continuare.', 401);
  return transaction(async (client) => {
    const result = await client.query(
      'SELECT u.id,u.name,u.email,s.csrf_token FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now() AND u.active',
      [digest(token)],
    );
    const user = result.rows[0];
    if (!user)
      throw new InputError('Sessione scaduta. Accedi nuovamente.', 401);
    const companies = await client.query(
      'SELECT c.id,c.name,c.fiscal_id,c.address,m.role FROM memberships m JOIN companies c ON c.id=m.company_id WHERE m.user_id=$1 AND m.active AND c.active ORDER BY c.name',
      [user.id],
    );
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      csrf: user.csrf_token,
      companies: companies.rows as Company[],
    };
  }, true);
}
export function companyId(request: Request, user: Identity) {
  const id =
    request.headers.get('x-company-id') ??
    new URL(request.url).searchParams.get('company') ??
    cookieValue(request, companyCookie);
  if (!id || !user.companies.some((c) => c.id === id))
    throw new InputError('Seleziona un’azienda autorizzata.', 403);
  return id;
}
let dummyHash: Promise<string> | undefined;
let passwordChecks = 0;
export async function login(emailValue: unknown, passwordValue: unknown) {
  const email = textField(emailValue, 'Email', 254).toLowerCase();
  const password = passwordField(passwordValue);
  const key = digest(email);
  const throttle = await pool().query(
    `INSERT INTO login_attempts(key,attempts,expires_at) VALUES($1,1,now()+interval '15 minutes')
    ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN login_attempts.expires_at<now() THEN 1 ELSE login_attempts.attempts+1 END,
    expires_at=CASE WHEN login_attempts.expires_at<now() THEN now()+interval '15 minutes' ELSE login_attempts.expires_at END RETURNING attempts`,
    [key],
  );
  if (throttle.rows[0].attempts > 8 || passwordChecks >= 4)
    throw new InputError('Troppi tentativi. Riprova tra 15 minuti.', 429);
  passwordChecks++;
  try {
    const result = await pool().query(
      'SELECT id,password_hash,active FROM users WHERE email=$1',
      [email],
    );
    const user = result.rows[0];
    dummyHash ??= hashPassword(randomBytes(24).toString('hex'));
    const valid = await verifyPassword(
      password,
      user?.password_hash ?? (await dummyHash),
    );
    if (!valid || !user?.active)
      throw new InputError('Email o password non valide.', 401);
    const token = randomBytes(32).toString('hex'),
      csrf = randomBytes(32).toString('hex');
    await transaction(async (client) => {
      const fresh = await client.query(
        'SELECT active,password_hash FROM users WHERE id=$1 FOR UPDATE',
        [user.id],
      );
      if (
        !fresh.rows[0]?.active ||
        fresh.rows[0].password_hash !== user.password_hash
      )
        throw new InputError('Email o password non valide.', 401);
      await client.query('DELETE FROM sessions WHERE expires_at<now()');
      await client.query(
        "INSERT INTO sessions(token_hash,user_id,csrf_token,expires_at) VALUES($1,$2,$3,now()+$4::int*interval '1 hour')",
        [digest(token), user.id, csrf, config().sessionHours],
      );
      await client.query('UPDATE login_attempts SET attempts=0 WHERE key=$1', [
        key,
      ]);
    });
    return token;
  } finally {
    passwordChecks--;
  }
}
