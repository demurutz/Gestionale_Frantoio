import {
  InputError,
  textField,
  grams,
  dateField,
  positiveId,
  option,
  units,
  today,
  code,
  stockAmount,
} from './domain.ts';
import {
  millilitres,
  packagingPlan,
  effectiveEvents,
  densityValue,
  convertedAmount,
} from './production.ts';
import type { Data, Batch, OilLot, OilStock } from './domain.ts';
import { readData, commit, previousResult } from './archive.ts';
import type { Store } from '../db/index.ts';
import {
  canonicalData,
  inputMl,
  toGrams,
  OIL_DENSITY_G_L,
} from './quantity.ts';
export { readData } from './archive.ts';

function find<T extends { id: string | number }>(
  rows: T[],
  id: unknown,
  label: string,
): T {
  const row = rows.find((r) => r.id === id);
  if (!row) throw new InputError('Seleziona ' + label + ' esistente.', 404);
  return row;
}
function quality(input: Record<string, unknown>) {
  const quality = option(
    input.quality,
    ['normal', 'dop', 'bio', 'dop_bio'] as const,
    'Tipologia',
  );
  const designation = textField(
    input.designation ?? '',
    'Denominazione D.O.P.',
    160,
    !quality.includes('dop'),
  );
  return { quality, designation: quality.includes('dop') ? designation : '' };
}
function documentFields(input: Record<string, unknown>, required = false) {
  const document = textField(
    input.document ?? '',
    'Riferimento documento',
    160,
    !required,
  );
  return {
    document,
    document_date: document ? dateField(input.document_date) : '',
  };
}
function addStock(
  data: Data,
  lot: OilLot,
  containerId: unknown,
  amount: number,
  requestId: string,
  litres = false,
) {
  const container = find(data.containers, containerId, 'un contenitore');
  if (litres !== (container.capacity_ml != null))
    throw new InputError(
      'Completa prima la capacità e la rilevazione in litri del silos.',
    );
  const occupied = data.stocks.filter(
    (s) => s.container_id === container.id && stockAmount(s) > 0,
  );
  if (occupied.some((s) => s.lot_id !== lot.id))
    throw new InputError(
      'Il contenitore contiene un altro lotto. Scegli un contenitore vuoto: la miscelazione non è prevista.',
    );
  if (
    occupied.some((s) => litres !== (s.amount_ml != null)) ||
    occupied.reduce((n, s) => n + stockAmount(s), 0) + amount >
      (litres ? container.capacity_ml! : container.capacity_g)
  )
    throw new InputError('Quantità superiore alla capacità del contenitore.');
  const stock = data.stocks.find(
    (s) => s.lot_id === lot.id && s.container_id === container.id,
  );
  if (stock) {
    if (litres) stock.amount_ml = (stock.amount_ml ?? 0) + amount;
    else stock.amount_g += amount;
  } else
    data.stocks.push({
      id: requestId,
      lot_id: lot.id,
      container_id: container.id,
      amount_g: litres ? 0 : amount,
      amount_ml: litres ? amount : null,
    });
  return container;
}
function debit(stock: OilStock, amount: number, litres = false) {
  if (litres !== (stock.amount_ml != null))
    throw new InputError(
      'Rileva prima i litri della giacenza storica. Kg e litri non sono intercambiabili.',
    );
  if (amount > stockAmount(stock))
    throw new InputError('Quantità superiore alla giacenza disponibile.', 409);
  if (litres) stock.amount_ml = stock.amount_ml! - amount;
  else stock.amount_g -= amount;
}
function assertEdible(lot: OilLot) {
  if (!['extra', 'virgin'].includes(lot.category))
    throw new InputError(
      'Prima del confezionamento o della vendita serve una classificazione commestibile (extravergine o vergine).',
    );
}
function assertDate(data: Data, date: string, lot?: OilLot, batch?: Batch) {
  let minimum = lot?.date ?? batch?.date ?? '';
  for (const event of effectiveEvents(data.events)) {
    if (event.action === 'batch.integrate') continue;
    const payload = JSON.parse(event.payload_json);
    if (
      (lot &&
        (payload.lot_id === lot.id || payload.lot_ids?.includes(lot.id))) ||
      (batch && payload.batch_id === batch.id)
    )
      minimum = minimum > event.date ? minimum : event.date;
  }
  if (date < minimum)
    throw new InputError(
      'La data non può precedere l’ultima operazione del lotto/partita (' +
        minimum +
        ').',
    );
}

export async function mutate(db: Store, input: Record<string, unknown>) {
  const before = await readData(db);
  const previous = before.events.find((e) => e.id === input.requestId);
  if (previous) return previousResult(previous, input);
  if (input.action === 'operation.correct') {
    const { correctOperation } = await import('./corrections.ts');
    const correction = correctOperation(before, input);
    return commit(
      db,
      before,
      correction.data,
      input,
      correction.date,
      correction.result,
      correction.context,
    );
  }
  const result = applyOperation(before, input);
  return commit(
    db,
    before,
    result.data,
    input,
    result.date,
    result.result,
    result.context,
  );
}
export function applyOperation(
  before: Data,
  input: Record<string, unknown>,
  now = new Date().toISOString(),
  historical = false,
) {
  if (historical) return applyCore(before, input, now);
  const command = { ...input };
  const unit = input.volume_unit ?? 'kg';
  if (unit !== 'kg' && unit !== 'L') throw new InputError('Unità non valida.');
  if (input.action === 'container.convert' && !historical)
    throw new InputError(
      'Usa il selettore kg/litri: il cambio di visualizzazione non modifica il deposito.',
    );
  if (input.action === 'container.create')
    command.capacity_l =
      inputMl(
        unit === 'L' ? input.capacity_l : input.capacity,
        unit,
        'Capacità silos',
      ) / 1000;
  if (input.action === 'batch.complete') {
    const existing = find(before.batches, positiveId(input.id), 'una partita');
    if (existing.status !== 'working' || existing.revision !== input.revision)
      throw new InputError(
        'Lo stato della partita è cambiato. Ricarica i dati.',
        409,
      );
    if (toGrams(inputMl(input.oil, unit, 'Olio prodotto')) > existing.net_g)
      throw new InputError(
        'L’olio prodotto non può superare il peso netto delle olive.',
      );
    command.oil = inputMl(input.oil, unit, 'Olio prodotto') / 1000;
  }
  if (
    [
      'oil.receive',
      'oil.adopt',
      'oil.transfer',
      'oil.return',
      'oil.bottle',
    ].includes(String(input.action))
  ) {
    if (input.action === 'oil.adopt') {
      const b = find(before.batches, positiveId(input.id), 'una partita');
      command.amount =
        ((b.oil_ml ?? inputMl(b.oil_g / 1000, 'kg', 'Olio storico')) -
          (b.returned_ml ??
            inputMl(b.returned_g / 1000, 'kg', 'Ritiri', true))) /
        1000;
    } else if (input.amount != null)
      command.amount = inputMl(input.amount, unit, 'Quantità olio') / 1000;
  }
  if (
    unit === 'kg' &&
    input.amount != null &&
    (input.action === 'oil.transfer' || input.action === 'oil.return')
  ) {
    const stock = find(before.stocks, input.stock_id, 'una giacenza sfusa');
    const available =
      stock.amount_ml ?? inputMl(stock.amount_g / 1000, 'kg', 'Giacenza', true);
    // Selecting the displayed full mass must not leave (or overdraw) a rounding millilitre.
    if (
      grams(input.amount, 'Quantità olio') === toGrams(available) &&
      Math.abs(Number(command.amount) * 1000 - available) <= 1
    )
      command.amount = available / 1000;
  }
  if (input.action === 'oil.bottle' && input.items == null && !historical) {
    const ml = units(input.units) * units(input.unit_ml, 'Formato ml');
    if (ml > 1_000_000_000)
      throw new InputError('Volume di confezionamento troppo elevato.');
    command.amount = ml / 1000;
  }
  command.volume_unit = 'L';
  const result = applyCore(canonicalData(before), command, now);
  result.data = canonicalData(result.data, true);
  result.context.canonical_version = 1;
  result.context.density_g_l = OIL_DENSITY_G_L;
  if (typeof result.context.oil_ml === 'number')
    result.context.oil_g = toGrams(result.context.oil_ml);
  return result;
}
function applyCore(before: Data, input: Record<string, unknown>, now: string) {
  const requestId = textField(input.requestId, 'Identificativo operazione', 80);
  if (!/^[a-zA-Z0-9-]{8,80}$/.test(requestId))
    throw new InputError('Identificativo operazione non valido.');
  const action = textField(input.action, 'Operazione', 40);
  const data = structuredClone(before);
  const litres = input.volume_unit === 'L';
  if (
    input.volume_unit != null &&
    input.volume_unit !== 'kg' &&
    input.volume_unit !== 'L'
  )
    throw new InputError('Unità volume non valida.');
  const date = dateField(input.date ?? today());
  let id: string | number = requestId;
  let lot: OilLot | undefined;
  let batch: Batch | undefined;
  const context: Record<string, unknown> = {
    document: '',
    document_date: '',
    note: textField(input.note ?? '', 'Note movimento', 1200, true),
    applied_at: now,
  };
  const makePackage = (
    current: OilLot,
    facilityId: unknown,
    consumed: number,
  ) => {
    assertEdible(current);
    const facility = find(data.facilities, facilityId, 'uno stabilimento');
    if (input.items != null) {
      const plan = packagingPlan(data.packagingFormats, input.items);
      const density = consumed ? OIL_DENSITY_G_L : null;
      let cumulative = 0,
        allocated = 0;
      const prefix = textField(input.package_code, 'Lotto confezionamento', 90);
      plan.rows.forEach((line, i) => {
        cumulative += line.volume_ml;
        const cumulativeMass = density
          ? convertedAmount(cumulative, 'L', 'kg', density)
          : 0;
        const consumedMass = cumulativeMass - allocated;
        allocated = cumulativeMass;
        const label = prefix + (plan.rows.length > 1 ? '-' + (i + 1) : '');
        if (
          data.packages.some(
            (p) => p.code === label && p.facility_id === facility.id,
          )
        )
          throw new InputError(
            'Lotto confezionamento già presente nello stabilimento.',
          );
        data.packages.push({
          id: requestId + '-' + (i + 1),
          lot_id: current.id,
          facility_id: facility.id,
          code: label,
          date,
          unit_ml: line.format.capacity_ml,
          initial_units: line.units,
          units: line.units,
          consumed_g: consumedMass,
          consumed_ml: consumed ? line.volume_ml : 0,
          format_id: line.format.id,
          format_name: line.format.name,
          density_g_l: density,
        });
      });
      Object.assign(context, {
        packaged_ml: plan.volume_ml,
        units: plan.units,
        destination_facility: facility,
        packaging: plan.rows,
        density_g_l: density,
      });
      return;
    }
    const count = units(input.units);
    const volume = units(input.unit_ml, 'Formato in millilitri');
    if (volume > 5000)
      throw new InputError('Formato bottiglia: massimo 5.000 ml.');
    const label = textField(input.package_code, 'Lotto imbottigliamento', 100);
    if (
      data.packages.some(
        (p) => p.code === label && p.facility_id === facility.id,
      )
    )
      throw new InputError(
        'Il lotto di imbottigliamento esiste già in questo stabilimento.',
      );
    data.packages.push({
      id: requestId,
      lot_id: current.id,
      facility_id: facility.id,
      code: label,
      date,
      unit_ml: volume,
      initial_units: count,
      units: count,
      consumed_g: litres ? toGrams(consumed) : consumed,
      consumed_ml: litres ? consumed : null,
      format_id: null,
      format_name: '',
      density_g_l: litres && consumed ? OIL_DENSITY_G_L : null,
    });
    context.packaged_ml = count * volume;
    context.units = count;
    context.destination_facility = facility;
  };

  if (action === 'producer.create' || action === 'producer.update') {
    const record = {
      id:
        action === 'producer.create'
          ? requestId
          : find(data.producers, input.id, 'un conferente/cliente').id,
      name: textField(input.name, 'Nome'),
      city: textField(input.city, 'Comune'),
      phone: textField(input.phone ?? '', 'Telefono', 40, true),
      fiscal_id: textField(
        input.fiscal_id ?? '',
        'Codice fiscale / P. IVA',
        30,
        true,
      ).toUpperCase(),
      address: textField(input.address ?? '', 'Indirizzo', 200, true),
      country: textField(
        input.country ?? 'IT',
        'Codice paese',
        2,
      ).toUpperCase(),
    };
    if (!/^[A-Z]{2}$/.test(record.country))
      throw new InputError(
        'Paese: usa il codice di due lettere, per esempio IT.',
      );
    if (action === 'producer.create') data.producers.push(record);
    else
      Object.assign(
        find(data.producers, record.id, 'un conferente/cliente'),
        record,
      );
    id = record.id;
  } else if (action === 'facility.create' || action === 'facility.update') {
    const record = {
      id:
        action === 'facility.create'
          ? requestId
          : find(data.facilities, input.id, 'uno stabilimento').id,
      name: textField(input.name, 'Nome stabilimento'),
      sian_code: textField(
        input.sian_code ?? '',
        'Identificativo SIAN',
        40,
        true,
      ),
      cuaa: textField(input.cuaa ?? '', 'CUAA impresa', 16, true).toUpperCase(),
      address: textField(input.address ?? '', 'Indirizzo', 200, true),
    };
    if (action === 'facility.create') data.facilities.push(record);
    else
      Object.assign(
        find(data.facilities, record.id, 'uno stabilimento'),
        record,
      );
    id = record.id;
  } else if (action === 'format.create' || action === 'format.update') {
    const name = textField(input.name, 'Nome confezione', 100);
    const capacity = millilitres(input.capacity_l, 'Capacità confezione (L)');
    if (capacity > 1_000_000)
      throw new InputError('Capacità confezione: massimo 1000 L.');
    const format =
      action === 'format.update'
        ? find(data.packagingFormats, input.id, 'un formato')
        : undefined;
    if (
      data.packagingFormats.some(
        (f) =>
          f.name.toLowerCase() === name.toLowerCase() && f.id !== format?.id,
      )
    )
      throw new InputError('Nome confezione già presente.');
    const active = input.active ?? true;
    if (typeof active !== 'boolean')
      throw new InputError('Stato confezione non valido.');
    const values = { name, capacity_ml: capacity, active };
    if (format) {
      Object.assign(format, values);
      id = format.id;
    } else data.packagingFormats.push({ id: requestId, ...values });
  } else if (action === 'container.convert') {
    if (input.expected_sequence !== (before.events.at(-1)?.seq ?? 0))
      throw new InputError('Registro cambiato. Riapri il cambio unità.', 409);
    const container = find(data.containers, input.id, 'un silos');
    const from = container.capacity_ml == null ? 'kg' : 'L';
    const to = option(input.unit, ['kg', 'L'] as const, 'Nuova unità');
    if (from === to) throw new InputError('Scegli l’altra unità di misura.');
    const density = densityValue(input.density);
    const current = data.stocks.filter((s) => s.container_id === container.id);
    const active = current.filter((s) => stockAmount(s) > 0);
    if (active.some((s) => (s.amount_ml == null ? 'kg' : 'L') !== from))
      throw new InputError('Giacenze non coerenti con l’unità del silos.');
    for (const s of active)
      assertDate(data, date, find(data.lots, s.lot_id, 'un lotto'));
    const capacity = convertedAmount(
      container.capacity_ml ?? container.capacity_g,
      from,
      to,
      density,
    );
    let total = 0;
    for (const s of current) {
      const amount = convertedAmount(stockAmount(s), from, to, density);
      if (to === 'L') s.amount_ml = amount;
      else {
        s.amount_g = amount;
        s.amount_ml = null;
      }
      total += amount;
    }
    if (total > capacity)
      throw new InputError('La conversione supera la capacità del silos.');
    container.capacity_ml = to === 'L' ? capacity : null;
    if (to === 'kg') container.capacity_g = capacity;
    id = container.id;
    Object.assign(context, {
      from_unit: from,
      to_unit: to,
      density_g_l: density,
      destination_container: container,
      converted_stocks: current.map((s) => s.id),
      lot_ids: active.map((s) => s.lot_id),
      reason: textField(input.reason, 'Motivo cambio unità', 1200),
    });
  } else if (action === 'container.volume') {
    const container = find(data.containers, input.id, 'un silos');
    const capacity = millilitres(input.capacity_l, 'Capacità silos (L)');
    const current = data.stocks.filter(
      (s) => s.container_id === container.id && stockAmount(s) > 0,
    );
    if (current.length > 1)
      throw new InputError(
        'Silos con più lotti: verifica lo storico prima della rilevazione.',
      );
    if (container.capacity_ml == null && current.length) {
      const stock = current[0];
      if (input.stock_id !== stock.id)
        throw new InputError('La giacenza è cambiata. Riapri il modulo.', 409);
      const measured = millilitres(
        input.amount,
        'Litri effettivamente presenti',
        true,
      );
      if (measured > capacity)
        throw new InputError('Volume superiore alla capacità.');
      const measuredLot = find(data.lots, stock.lot_id, 'un lotto');
      assertDate(data, date, measuredLot);
      stock.amount_ml = measured;
      context.lot_id = stock.lot_id;
      context.measured_ml = measured;
      context.stock_id = stock.id;
      context.legacy_g = stock.amount_g;
    } else if (
      container.capacity_ml != null &&
      current.reduce((n, s) => n + (s.amount_ml ?? 0), 0) > capacity
    )
      throw new InputError(
        'La capacità non può essere inferiore al contenuto.',
      );
    container.capacity_ml = capacity;
    for (const stock of data.stocks.filter(
      (s) => s.container_id === container.id && stockAmount(s) === 0,
    ))
      stock.amount_ml = 0;
    id = container.id;
    context.destination_container = container;
  } else if (action === 'container.create') {
    const facility = find(
      data.facilities,
      input.facility_id,
      'uno stabilimento',
    );
    const label = textField(input.code, 'Codice contenitore', 10).toUpperCase();
    if (
      data.containers.some(
        (c) => c.facility_id === facility.id && c.code === label,
      )
    )
      throw new InputError(
        'Codice contenitore già presente nello stabilimento.',
      );
    data.containers.push({
      id: requestId,
      facility_id: facility.id,
      code: label,
      capacity_g: litres ? 0 : grams(input.capacity, 'Capacità'),
      capacity_ml: litres
        ? millilitres(input.capacity_l, 'Capacità silos (L)')
        : null,
    });
  } else if (action === 'batch.create' || action === 'batch.update') {
    if (action === 'batch.update') {
      batch = find(data.batches, positiveId(input.id), 'una partita');
      if (batch.status !== 'waiting')
        throw new InputError(
          'Partita già in lavorazione: pesatura non modificabile.',
          409,
        );
      if (
        !Number.isSafeInteger(input.revision) ||
        input.revision !== batch.revision
      )
        throw new InputError('Partita modificata. Ricarica i dati.', 409);
    }
    const producer = find(data.producers, input.producer_id, 'un conferente');
    const facility = find(
      data.facilities,
      input.facility_id,
      'uno stabilimento',
    );
    const gross = grams(input.gross, 'Peso lordo');
    const tare = grams(input.tare, 'Tara', true);
    if (tare >= gross)
      throw new InputError('La tara deve essere inferiore al peso lordo.');
    const values = {
      producer_id: producer.id,
      facility_id: facility.id,
      date,
      variety: textField(input.variety, 'Cultivar'),
      origin: textField(input.origin, 'Provenienza'),
      gross_g: gross,
      tare_g: tare,
      net_g: gross - tare,
      notes: textField(input.notes ?? '', 'Note', 1200, true),
      olive_source: option(
        input.olive_source,
        ['own', 'purchased', 'third_party'] as const,
        'Proprietà olive / lavorazione',
      ),
      ...quality(input),
      ...documentFields(input),
    };
    if (batch)
      Object.assign(batch, values, {
        revision: batch.revision + 1,
        last_request: requestId,
      });
    else {
      batch = {
        ...values,
        id: Math.max(0, ...data.batches.map((b) => b.id)) + 1,
        request_id: requestId,
        producer_name: producer.name,
        status: 'waiting',
        oil_g: 0,
        oil_ml: null,
        pomace_g: null,
        wastewater_ml: null,
        production_date: '',
        returned_g: 0,
        stock_g: 0,
        packaged_ml: 0,
        tank: '',
        revision: 0,
        last_request: '',
        started_at: null,
        completed_at: null,
      };
      data.batches.push(batch);
    }
    id = batch.id;
    Object.assign(context, documentFields(input), { olive_g: batch.net_g });
  } else if (action === 'batch.integrate') {
    batch = find(data.batches, positiveId(input.id), 'una partita');
    if (
      batch.olive_source !== 'unknown' &&
      batch.quality !== 'unknown' &&
      batch.facility_id
    )
      throw new InputError('Integrazione non necessaria per questa partita.');
    if (batch.revision !== input.revision)
      throw new InputError('Partita modificata. Ricarica i dati.', 409);
    const facilityId = find(
      data.facilities,
      input.facility_id,
      'uno stabilimento',
    ).id;
    const oliveSource = option(
      input.olive_source,
      ['own', 'purchased', 'third_party'] as const,
      'Olive e lavorazione',
    );
    const details = quality(input);
    if (
      (batch.facility_id && batch.facility_id !== facilityId) ||
      (batch.olive_source !== 'unknown' &&
        batch.olive_source !== oliveSource) ||
      (batch.quality !== 'unknown' &&
        (batch.quality !== details.quality ||
          batch.designation !== details.designation))
    )
      throw new InputError(
        'L’integrazione può completare solo le informazioni mancanti, non modificare quelle già registrate.',
      );
    const existingLot = data.lots.find((l) => l.batch_id === batch?.id);
    if (
      existingLot &&
      existingLot.ownership !==
        (oliveSource === 'third_party' ? 'third_party' : 'own')
    )
      throw new InputError(
        'La proprietà delle olive non corrisponde al lotto olio già registrato.',
      );
    Object.assign(batch, details, {
      facility_id: facilityId,
      olive_source: oliveSource,
    });
    batch.revision++;
    batch.last_request = requestId;
    id = batch.id;
  } else if (action === 'batch.start' || action === 'batch.complete') {
    batch = find(data.batches, positiveId(input.id), 'una partita');
    if (!Number.isSafeInteger(input.revision) || Number(input.revision) < 0)
      throw new InputError('Revisione partita non valida.');
    if (
      batch.revision !== input.revision ||
      batch.status !== (action === 'batch.start' ? 'waiting' : 'working')
    )
      throw new InputError(
        'Lo stato della partita è cambiato. Ricarica i dati.',
        409,
      );
    if (
      batch.olive_source === 'unknown' ||
      batch.quality === 'unknown' ||
      !batch.facility_id
    )
      throw new InputError(
        'Integra prima proprietà, tipologia e stabilimento della partita.',
      );
    assertDate(data, date, undefined, batch);
    if (action === 'batch.start') {
      batch.status = 'working';
      batch.started_at = now;
    } else {
      const amount = grams(input.oil, 'Olio prodotto');
      if (!litres && amount > batch.net_g)
        throw new InputError(
          'L’olio prodotto non può superare il peso netto delle olive.',
        );
      const destination = option(
        input.destination,
        ['store', 'return'] as const,
        'Destinazione olio',
      );
      const ownership =
        batch.olive_source === 'third_party' ? 'third_party' : 'own';
      if (input.olive_quality != null)
        Object.assign(
          batch,
          quality({
            quality: input.olive_quality,
            designation: input.olive_designation,
          }),
        );
      const oilType = quality({
        quality: input.oil_quality ?? batch.quality,
        designation: input.oil_designation ?? batch.designation,
      });
      if (
        (oilType.quality.includes('dop') && !batch.quality.includes('dop')) ||
        (oilType.quality.includes('bio') && !batch.quality.includes('bio'))
      )
        throw new InputError(
          'La tipologia olio non può aggiungere certificazioni non indicate sulle olive.',
        );
      if (
        oilType.quality.includes('dop') &&
        oilType.designation !== batch.designation
      )
        throw new InputError(
          'La denominazione D.O.P. dell’olio deve corrispondere alle olive.',
        );
      if (destination === 'return' && ownership !== 'third_party')
        throw new InputError('Il ritiro immediato è riservato al conto terzi.');
      lot = {
        id: requestId,
        label: code(batch),
        batch_id: batch.id,
        date,
        ownership,
        owner_id: ownership === 'third_party' ? batch.producer_id : null,
        supplier_id: null,
        source: 'produced',
        ...oilType,
        origin: batch.origin,
        category: 'pending',
      };
      data.lots.push(lot);
      if (destination === 'store') {
        const container = addStock(
          data,
          lot,
          input.container_id,
          amount,
          requestId,
          litres,
        );
        if (container.facility_id !== batch.facility_id)
          throw new InputError(
            'Carica la produzione nello stabilimento di molitura; poi registra il trasferimento.',
          );
        batch.tank = container.code;
        context.destination_container = container;
      } else {
        data.deliveries.push({
          id: requestId,
          batch_id: batch.id,
          amount_g: litres ? 0 : amount,
          amount_ml: litres ? amount : null,
          date,
          note: 'Ritiro immediato dopo la molitura',
          created_at: now,
        });
        batch.tank = 'Ritirato dal cliente';
      }
      Object.assign(context, documentFields(input), {
        [litres ? 'oil_ml' : 'oil_g']: amount,
        disposition: destination,
      });
      batch.status = 'done';
      batch.oil_g = litres ? 0 : amount;
      batch.oil_ml = litres ? amount : null;
      batch.pomace_g =
        input.pomace == null || input.pomace === ''
          ? null
          : grams(input.pomace, 'Sansa (kg)', true);
      batch.wastewater_ml =
        input.wastewater == null || input.wastewater === ''
          ? null
          : millilitres(input.wastewater, 'Acqua di vegetazione (L)', true);
      batch.production_date = date;
      context.pomace_g = batch.pomace_g;
      context.wastewater_ml = batch.wastewater_ml;
      batch.completed_at = now;
    }
    batch.revision++;
    batch.last_request = requestId;
    id = batch.id;
  } else if (action === 'oil.receive' || action === 'oil.adopt') {
    const ownership = option(
      input.ownership,
      ['own', 'third_party'] as const,
      'Proprietà olio',
    );
    const source =
      action === 'oil.adopt'
        ? 'legacy'
        : option(
            input.source,
            ['produced', 'purchased'] as const,
            'Provenienza olio',
          );
    if (source === 'purchased' && ownership !== 'own')
      throw new InputError(
        'L’olio acquistato diventa di proprietà del frantoio.',
      );
    const owner =
      ownership === 'third_party'
        ? find(data.producers, input.owner_id, 'un proprietario')
        : null;
    const supplier =
      source === 'purchased'
        ? find(data.producers, input.supplier_id, 'un fornitore/cliente')
        : null;
    if (action === 'oil.adopt') {
      batch = find(data.batches, positiveId(input.id), 'una partita');
      if (
        batch.status !== 'done' ||
        data.lots.some((l) => l.batch_id === batch?.id) ||
        (batch.oil_ml == null
          ? batch.oil_g - batch.returned_g
          : batch.oil_ml - (batch.returned_ml ?? 0)) <= 0
      )
        throw new InputError('Partita già integrata oppure non completata.');
      if (owner && owner.id !== batch.producer_id)
        throw new InputError(
          'Il proprietario deve coincidere con il conferente della partita.',
        );
      assertDate(data, date, undefined, batch);
    }
    lot = {
      id: requestId,
      label: batch ? code(batch) : textField(input.label, 'Lotto olio', 100),
      batch_id: batch?.id ?? null,
      date,
      ownership,
      owner_id: owner?.id ?? null,
      supplier_id: supplier?.id ?? null,
      source,
      ...quality(input),
      origin: batch?.origin ?? textField(input.origin, 'Origine olio'),
      category: option(
        input.category,
        ['pending', 'extra', 'virgin', 'lampante'] as const,
        'Categoria olio',
      ),
    };
    data.lots.push(lot);
    const format = batch
      ? 'bulk'
      : option(input.format, ['bulk', 'packaged'] as const, 'Formato');
    if (format === 'bulk') {
      const amount =
        batch && !litres
          ? batch.oil_g - batch.returned_g
          : grams(input.amount, 'Olio caricato');
      if (amount <= 0) throw new InputError('Nessuna giacenza da integrare.');
      context.destination_container = addStock(
        data,
        lot,
        input.container_id,
        amount,
        requestId,
        litres,
      );
      context[litres ? 'oil_ml' : 'oil_g'] = amount;
    } else makePackage(lot, input.facility_id, 0);
    Object.assign(context, documentFields(input, source === 'purchased'), {
      format,
    });
    if (batch) {
      batch.olive_source =
        ownership === 'third_party' ? 'third_party' : 'unknown';
      batch.quality = lot.quality;
      batch.designation = lot.designation;
    }
  } else if (
    ['oil.classify', 'oil.transfer', 'oil.return', 'oil.bottle'].includes(
      action,
    )
  ) {
    const stock =
      action === 'oil.classify'
        ? undefined
        : find(data.stocks, input.stock_id, 'una giacenza sfusa');
    lot = find(data.lots, stock?.lot_id ?? input.lot_id, 'un lotto');
    assertDate(data, date, lot);
    Object.assign(context, documentFields(input, action === 'oil.classify'));
    if (action === 'oil.classify') {
      if (lot.category !== 'pending')
        throw new InputError('Questo lotto è già classificato.');
      lot.category = option(
        input.category,
        ['extra', 'virgin', 'lampante'] as const,
        'Classificazione',
      );
    } else if (stock) {
      const amount =
        action === 'oil.bottle' && input.items != null
          ? litres
            ? packagingPlan(data.packagingFormats, input.items).volume_ml
            : convertedAmount(
                packagingPlan(data.packagingFormats, input.items).volume_ml,
                'L',
                'kg',
                densityValue(input.density),
              )
          : grams(input.amount, 'Olio movimentato');
      const sourceContainer = find(
        data.containers,
        stock.container_id,
        'un contenitore',
      );
      context.source_container = sourceContainer;
      context[litres ? 'oil_ml' : 'oil_g'] = amount;
      if (action === 'oil.transfer') {
        const destination = find(
          data.containers,
          input.container_id,
          'un contenitore di destinazione',
        );
        if (destination.id === stock.container_id)
          throw new InputError(
            'Scegli un contenitore diverso da quello di partenza.',
          );
        if (
          lot.ownership !== 'own' &&
          destination.facility_id !== sourceContainer.facility_id
        )
          throw new InputError(
            'Il trasferimento tra stabilimenti è previsto per l’olio proprio.',
          );
        if (destination.facility_id !== sourceContainer.facility_id)
          Object.assign(context, documentFields(input, true));
        debit(stock, amount, litres);
        context.destination_container = addStock(
          data,
          lot,
          destination.id,
          amount,
          requestId,
          litres,
        );
      } else if (action === 'oil.return') {
        if (lot.ownership !== 'third_party')
          throw new InputError(
            'Il ritiro è riservato all’olio del cliente in conto terzi.',
          );
        debit(stock, amount, litres);
        if (lot.batch_id)
          data.deliveries.push({
            id: requestId,
            batch_id: lot.batch_id,
            amount_g: litres ? 0 : amount,
            amount_ml: litres ? amount : null,
            date,
            note: String(context.note),
            created_at: now,
          });
      } else {
        assertEdible(lot);
        debit(stock, amount, litres);
        makePackage(lot, sourceContainer.facility_id, amount);
      }
    }
  } else if (action === 'package.sell' || action === 'package.return') {
    const pack = find(
      data.packages,
      input.package_id,
      'un lotto imbottigliato',
    );
    lot = find(data.lots, pack.lot_id, 'un lotto');
    assertDate(data, date, lot);
    const count = units(input.units);
    if (count > pack.units)
      throw new InputError(
        'Numero bottiglie superiore alla giacenza disponibile.',
        409,
      );
    if (action === 'package.sell') {
      if (lot.ownership !== 'own')
        throw new InputError(
          'Non puoi vendere olio di proprietà di un cliente. Usa il ritiro conto terzi.',
        );
      assertEdible(lot);
      const customer = find(data.producers, input.customer_id, 'un cliente');
      const document = documentFields(input, true);
      data.sales.push({
        id: requestId,
        package_id: pack.id,
        customer_id: customer.id,
        date,
        units: count,
        ...document,
      });
      Object.assign(context, document, { customer });
    } else {
      if (lot.ownership !== 'third_party')
        throw new InputError('Il ritiro è riservato al conto terzi.');
      Object.assign(context, documentFields(input));
    }
    pack.units -= count;
    context.units = count;
    context.packaged_ml = count * pack.unit_ml;
    context.package_id = pack.id;
    context.source_facility = find(
      data.facilities,
      pack.facility_id,
      'uno stabilimento',
    );
  } else throw new InputError('Operazione non riconosciuta.');

  if (batch) {
    context.batch_id = batch.id;
    context.batch = batch;
    context.conferente = find(
      data.producers,
      batch.producer_id,
      'un conferente',
    );
  }
  if (lot) {
    context.lot_id = lot.id;
    context.lot = lot;
    if (lot.owner_id)
      context.owner = find(data.producers, lot.owner_id, 'un proprietario');
    if (lot.supplier_id)
      context.supplier = find(data.producers, lot.supplier_id, 'un fornitore');
  }
  const containerRefs = [
    context.source_container,
    context.destination_container,
  ] as ({ facility_id: string } | undefined)[];
  context.facilities = data.facilities.filter(
    (f) =>
      f.id === batch?.facility_id ||
      containerRefs.some((c) => c?.facility_id === f.id),
  );
  return { data, date, result: { id }, context };
}
