import { InputError, units, grams } from './domain.ts';
import type { PackagingFormat, ArchiveEvent } from './domain.ts';
export const millilitres = (value: unknown, label = 'Litri', zero = false) =>
  grams(value, label, zero);
export function densityValue(value: unknown) {
  const density = grams(value, 'Densità (kg/L)');
  if (density > 10000)
    throw new InputError('Densità fuori intervallo: massimo 10 kg/L.');
  return density;
}
export function convertedAmount(
  amount: number,
  from: 'kg' | 'L',
  to: 'kg' | 'L',
  density: number,
) {
  const result =
    from === to
      ? amount
      : Math.round(
          from === 'kg' ? (amount * 1000) / density : (amount * density) / 1000,
        );
  if (
    !Number.isSafeInteger(result) ||
    result < 0 ||
    result > 1_000_000_000 ||
    (amount > 0 && result === 0)
  )
    throw new InputError(
      'La conversione supera i limiti o la precisione consentita (0,001).',
    );
  return result;
}
export function packagingPlan(formats: PackagingFormat[], value: unknown) {
  if (!Array.isArray(value) || value.length < 1 || value.length > 20)
    throw new InputError('Scegli da 1 a 20 formati di confezionamento.');
  const used = new Set<string>();
  const rows = value.map((item: unknown) => {
    if (!item || typeof item !== 'object')
      throw new InputError('Riga confezione non valida.');
    const line = item as Record<string, unknown>;
    const format = formats.find((f) => f.id === line.format_id && f.active);
    if (!format)
      throw new InputError('Scegli un formato attivo di questa azienda.');
    if (used.has(format.id))
      throw new InputError('Inserisci una sola riga per ciascun formato.');
    used.add(format.id);
    const count = units(line.units, 'Numero confezioni');
    return { format, units: count, volume_ml: count * format.capacity_ml };
  });
  const volume_ml = rows.reduce((n, r) => n + r.volume_ml, 0);
  if (!Number.isSafeInteger(volume_ml) || volume_ml > 1_000_000_000)
    throw new InputError('Volume di confezionamento troppo elevato.');
  return { rows, volume_ml, units: rows.reduce((n, r) => n + r.units, 0) };
}
export function effectiveEvents(events: ArchiveEvent[]) {
  const replacements = new Map<string, ArchiveEvent>();
  for (const event of events) {
    if (event.action !== 'operation.correct') continue;
    const payload = JSON.parse(event.payload_json);
    for (const replacement of payload.effective_events ?? [])
      replacements.set(replacement.id, replacement);
  }
  return events
    .filter((e) => e.action !== 'operation.correct')
    .map((e) => replacements.get(e.id) ?? e);
}
export function fillLevel(amount: number, capacity: number) {
  const percent = capacity > 0 ? (amount / capacity) * 100 : 0;
  return {
    percent,
    state:
      amount === 0
        ? 'empty'
        : percent < 10
          ? 'low'
          : percent <= 50
            ? 'medium'
            : 'high',
  };
}
