export type Producer = {
  id: string;
  name: string;
  city: string;
  phone: string;
  fiscal_id: string;
  address: string;
  country: string;
};
export type Batch = {
  id: number;
  request_id: string;
  producer_id: string;
  producer_name: string;
  date: string;
  variety: string;
  origin: string;
  gross_g: number;
  tare_g: number;
  net_g: number;
  status: 'waiting' | 'working' | 'done';
  oil_g: number;
  oil_ml?: number | null;
  pomace_g?: number | null;
  wastewater_ml?: number | null;
  production_date?: string;
  stock_ml?: number | null;
  returned_ml?: number | null;
  returned_g: number;
  tank: string;
  notes: string;
  revision: number;
  last_request: string;
  started_at: string | null;
  completed_at: string | null;
  facility_id: string | null;
  olive_source: 'own' | 'purchased' | 'third_party' | 'unknown';
  quality: Quality | 'unknown';
  designation: string;
  document: string;
  document_date: string;
  stock_g: number;
  packaged_ml: number;
};
export type Delivery = {
  amount_ml?: number | null;
  id: string;
  batch_id: number;
  amount_g: number;
  date: string;
  note: string;
  created_at: string;
};
export type Data = {
  packagingFormats: PackagingFormat[];
  producers: Producer[];
  batches: Batch[];
  deliveries: Delivery[];
  facilities: Facility[];
  containers: Container[];
  lots: OilLot[];
  stocks: OilStock[];
  packages: OilPackage[];
  sales: Sale[];
  events: ArchiveEvent[];
};
export type Quality = 'normal' | 'dop' | 'bio' | 'dop_bio';
export type Category = 'pending' | 'extra' | 'virgin' | 'lampante';
export type Facility = {
  id: string;
  name: string;
  sian_code: string;
  cuaa: string;
  address: string;
};
export type Container = {
  capacity_ml?: number | null;
  id: string;
  facility_id: string;
  code: string;
  capacity_g: number;
};
export type OilLot = {
  id: string;
  label: string;
  batch_id: number | null;
  date: string;
  ownership: 'own' | 'third_party';
  owner_id: string | null;
  supplier_id: string | null;
  source: 'produced' | 'purchased' | 'legacy';
  quality: Quality;
  designation: string;
  origin: string;
  category: Category;
};
export type OilStock = {
  amount_ml?: number | null;
  id: string;
  lot_id: string;
  container_id: string;
  amount_g: number;
};
export type OilPackage = {
  density_g_l?: number | null;
  format_id?: string | null;
  format_name?: string;
  consumed_ml?: number | null;
  id: string;
  lot_id: string;
  facility_id: string;
  code: string;
  date: string;
  unit_ml: number;
  initial_units: number;
  units: number;
  consumed_g: number;
};
export type Sale = {
  id: string;
  package_id: string;
  customer_id: string;
  date: string;
  units: number;
  document: string;
  document_date: string;
};
export type ArchiveEvent = {
  actor_id?: string | null;
  seq: number;
  id: string;
  action: string;
  date: string;
  created_at: string;
  payload_json: string;
};
export type PackagingFormat = {
  id: string;
  name: string;
  capacity_ml: number;
  active: boolean;
};
export const stockAmount = (s: OilStock) => s.amount_ml ?? s.amount_g;
export const stockLabel = (s: OilStock) =>
  kg(stockAmount(s)) + (s.amount_ml == null ? ' kg' : ' L');
export const capacityLabel = (s: Container) =>
  kg(s.capacity_ml ?? s.capacity_g) + (s.capacity_ml == null ? ' kg' : ' L');
export const stockLitres = (s: OilStock) =>
  s.amount_ml ?? (s.amount_g === 0 ? 0 : null);
export const volumeLabel = (ml: number | null | undefined) =>
  ml == null ? 'Litri da rilevare' : kg(ml) + ' L';
export const qualityLabels = {
  normal: 'Normali',
  dop: 'D.O.P.',
  bio: 'Biologiche',
  dop_bio: 'D.O.P. biologiche',
  unknown: 'Da integrare',
};
export const categoryLabels = {
  pending: 'In attesa di classificazione',
  extra: 'Extravergine',
  virgin: 'Vergine',
  lampante: 'Lampante',
};
export const sourceLabels = {
  own: 'Olive proprie · conto proprio',
  purchased: 'Olive acquistate dal cliente · conto proprio',
  third_party: 'Olive del cliente · conto terzi',
  unknown: 'Da integrare',
};
export const actionLabels: Record<string, string> = {
  'producer.create': 'Nuova anagrafica',
  'producer.update': 'Modifica anagrafica',
  'facility.create': 'Nuovo stabilimento',
  'facility.update': 'Modifica stabilimento',
  'container.create': 'Nuovo contenitore',
  'container.volume': 'Capacità e rilevazione litri silos',
  'container.convert': 'Cambio unità silos kg / litri',
  'format.create': 'Nuovo formato confezione',
  'format.update': 'Modifica formato confezione',
  'operation.correct': 'Rettifica operazione',
  'batch.create': 'Carico olive',
  'batch.update': 'Modifica carico olive',
  'batch.start': 'Avvio molitura',
  'batch.complete': 'Produzione olio',
  'batch.integrate': 'Integrazione dati partita',
  'oil.receive': 'Carico olio',
  'oil.adopt': 'Integrazione giacenza preesistente',
  'oil.classify': 'Classificazione olio',
  'oil.transfer': 'Trasferimento olio',
  'oil.return': 'Ritiro olio sfuso',
  'oil.bottle': 'Imbottigliamento',
  'package.sell': 'Vendita imbottigliato',
  'package.return': 'Ritiro imbottigliato',
};
export const emptyData: Data = {
  packagingFormats: [],
  producers: [],
  batches: [],
  deliveries: [],
  facilities: [],
  containers: [],
  lots: [],
  stocks: [],
  packages: [],
  sales: [],
  events: [],
};
export function today() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Rome',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}
export function option<T extends string>(
  value: unknown,
  allowed: readonly T[],
  label: string,
): T {
  if (!allowed.includes(value as T))
    throw new InputError(`${label}: seleziona un valore valido.`);
  return value as T;
}
export function units(value: unknown, label = 'Numero bottiglie'): number {
  if (!/^[1-9]\d{0,6}$/.test(String(value)))
    throw new InputError(
      `${label}: inserisci un numero intero positivo (massimo 9.999.999).`,
    );
  return Number(value);
}
export class InputError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}
export function textField(
  value: unknown,
  label: string,
  max = 160,
  optional = false,
): string {
  if (typeof value !== 'string')
    throw new InputError(`${label}: inserisci un testo valido.`);
  const result = value.trim();
  if ((!optional && !result) || result.length > max)
    throw new InputError(
      `${label}: ${optional ? 'massimo' : 'da 1 a'} ${max} caratteri.`,
    );
  return result;
}
export function grams(
  value: unknown,
  label: string,
  allowZero = false,
): number {
  if (typeof value !== 'string' && typeof value !== 'number')
    throw new InputError(`${label}: inserisci i kg.`);
  const normalized = String(value).trim().replace(',', '.');
  if (!/^\d{1,7}(\.\d{1,3})?$/.test(normalized))
    throw new InputError(
      `${label}: usa un numero positivo con al massimo 3 decimali.`,
    );
  const result = Math.round(Number(normalized) * 1000);
  if (result > 1_000_000_000 || result < (allowZero ? 0 : 1))
    throw new InputError(`${label}: quantità non valida.`);
  return result;
}
export function dateField(value: unknown): string {
  if (
    typeof value !== 'string' ||
    !/^\d{4}-\d{2}-\d{2}$/.test(value) ||
    !Number.isFinite(Date.parse(value)) ||
    new Date(value).toISOString().slice(0, 10) !== value
  )
    throw new InputError('Inserisci una data valida.');
  return value;
}
export function positiveId(value: unknown): number {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id < 1)
    throw new InputError('Partita non valida.');
  return id;
}
export function kg(value: number) {
  return new Intl.NumberFormat('it-IT', { maximumFractionDigits: 3 }).format(
    value / 1000,
  );
}
export function code(batch: Pick<Batch, 'id' | 'date'>) {
  return `P-${batch.date.slice(0, 4)}-${String(batch.id).padStart(4, '0')}`;
}
export function phase(batch: Batch) {
  if (batch.status === 'waiting') return 'waiting';
  if (batch.status === 'working') return 'working';
  if (batch.oil_ml != null || batch.stock_ml != null) {
    return batch.olive_source === 'third_party' &&
      batch.stock_ml === 0 &&
      batch.packaged_ml === 0
      ? 'returned'
      : 'done';
  }
  if (
    batch.olive_source === 'third_party' &&
    batch.stock_g === 0 &&
    batch.packaged_ml === 0
  )
    return 'returned';
  return batch.returned_g >= batch.oil_g ? 'returned' : 'done';
}
export const phaseLabels = {
  waiting: 'In attesa',
  working: 'In molitura',
  done: 'Molitura completata',
  returned: 'Restituita',
};
export function summary(batches: Batch[]) {
  const olive = batches.reduce((sum, b) => sum + b.net_g, 0);
  const milled = batches
    .filter((b) => b.status === 'done')
    .reduce((sum, b) => sum + b.net_g, 0);
  const oil = batches.reduce(
    (sum, b) =>
      sum + (b.oil_ml == null ? b.oil_g : Math.round(b.oil_ml * 0.916)),
    0,
  );
  return {
    olive,
    oil,
    yield: milled ? (oil / milled) * 100 : 0,
    stock: batches.reduce(
      (sum, b) => sum + (b.stock_g ?? b.oil_g - b.returned_g),
      0,
    ),
    pending: batches.filter((b) => b.status !== 'done').length,
  };
}
