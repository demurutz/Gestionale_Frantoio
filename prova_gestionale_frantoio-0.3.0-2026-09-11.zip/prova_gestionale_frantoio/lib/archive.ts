import { InputError, stockLitres } from './domain.ts';
import type { Data, ArchiveEvent } from './domain.ts';
import type { Store } from '../db/index.ts';

import { tables } from './archive-tables.ts';
import { toGrams } from './quantity.ts';
type TableKey = keyof typeof tables;

export async function readData(db: Store): Promise<Data> {
  const keys = Object.keys(tables) as TableKey[];
  const entries = [];
  for (const key of keys) {
    const [table, columns] = tables[key];
    const result = await db.client.query(
      `SELECT ${columns.split(' ').join(',')} FROM ${table} WHERE tenant_id=$1 ORDER BY id`,
      [db.tenantId],
    );
    entries.push([key, result.rows]);
  }
  const events = await db.client.query(
    'SELECT seq,id,action,date,created_at,payload_json,actor_id FROM events WHERE tenant_id=$1 ORDER BY seq',
    [db.tenantId],
  );
  const archive = {
    ...Object.fromEntries(entries),
    events: events.rows,
  } as Data;
  return hydrate(archive);
}
export function hydrate(archive: Data): Data {
  archive.producers.sort((a, b) => a.name.localeCompare(b.name, 'it'));
  for (const batch of archive.batches) {
    batch.producer_name =
      archive.producers.find((p) => p.id === batch.producer_id)?.name ?? '';
    batch.returned_g = archive.deliveries
      .filter((d) => d.batch_id === batch.id)
      .reduce((n, d) => n + d.amount_g, 0);
    const lot = archive.lots.find((l) => l.batch_id === batch.id);
    const stocks = archive.stocks.filter((s) => s.lot_id === lot?.id);
    const returns = archive.deliveries.filter((d) => d.batch_id === batch.id);
    batch.returned_ml = returns.some(
      (d) => d.amount_ml == null && d.amount_g > 0,
    )
      ? null
      : returns.reduce((n, d) => n + (d.amount_ml ?? 0), 0);
    batch.stock_ml = lot
      ? stocks.some((s) => stockLitres(s) == null)
        ? null
        : stocks.reduce((n, s) => n + (stockLitres(s) ?? 0), 0)
      : batch.oil_ml != null && batch.returned_ml != null
        ? batch.oil_ml - batch.returned_ml
        : null;
    batch.stock_g = lot
      ? archive.stocks
          .filter((s) => s.lot_id === lot.id)
          .reduce(
            (n, s) =>
              n + (s.amount_ml == null ? s.amount_g : toGrams(s.amount_ml)),
            0,
          )
      : batch.oil_g - batch.returned_g;
    batch.packaged_ml = lot
      ? archive.packages
          .filter((p) => p.lot_id === lot.id)
          .reduce((n, p) => n + p.units * p.unit_ml, 0)
      : 0;
  }
  archive.batches.sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
  return archive;
}

export function fingerprint(input: Record<string, unknown>) {
  return JSON.stringify(
    Object.fromEntries(
      Object.entries(input).sort(([a], [b]) => a.localeCompare(b)),
    ),
  );
}
export function previousResult(
  event: ArchiveEvent,
  input: Record<string, unknown>,
): { id: string | number } {
  const payload = JSON.parse(event.payload_json);
  if (payload.request !== fingerprint(input))
    throw new InputError(
      'Identificativo già usato con dati diversi. Chiudi e riapri il modulo.',
      409,
    );
  return payload.result;
}

export async function commit(
  db: Store,
  before: Data,
  after: Data,
  input: Record<string, unknown>,
  date: string,
  result: { id: string | number },
  context: Record<string, unknown>,
) {
  const changes: { table: string; before: unknown; after: unknown }[] = [];
  for (const key of Object.keys(tables) as TableKey[]) {
    const [table, columnList] = tables[key];
    const columns = columnList.split(' ');
    const pick = (row: object) =>
      Object.fromEntries(
        columns.map((c) => [c, (row as Record<string, unknown>)[c]]),
      );
    for (const row of after[key]) {
      const old = before[key].find((r) => r.id === row.id);
      const next = pick(row);
      if (old && JSON.stringify(pick(old)) === JSON.stringify(next)) continue;
      changes.push({ table, before: old ? pick(old) : null, after: next });
      const names = ['tenant_id', ...columns];
      await db.client.query(
        `INSERT INTO ${table} (${names.join(',')}) VALUES (${names.map((_, i) => '$' + (i + 1)).join(',')}) ON CONFLICT(tenant_id,id) DO UPDATE SET ${columns
          .filter((c) => c !== 'id')
          .map((c) => c + '=excluded.' + c)
          .join(',')}`,
        [db.tenantId, ...Object.values(next)],
      );
    }
  }
  const seq = (before.events.at(-1)?.seq ?? 0) + 1;
  await db.client.query(
    'INSERT INTO events(tenant_id,seq,id,action,date,created_at,payload_json,actor_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',
    [
      db.tenantId,
      seq,
      input.requestId,
      input.action,
      date,
      new Date().toISOString(),
      JSON.stringify({
        request: fingerprint(input),
        result,
        ...context,
        changes,
      }),
      db.actorId,
    ],
  );
  return result;
}
