import { effectiveEvents } from './production.ts';
import { dateField, today } from './domain.ts';
import type { Data } from './domain.ts';
import { toMl, toGrams } from './quantity.ts';
export function campaignYear(date: string) {
  dateField(date);
  return Number(date.slice(0, 4)) - (date.slice(5, 10) < '08-01' ? 1 : 0);
}
export const campaignLabel = (year: number) => year + '/' + (year + 1);
export function campaignYears(data: Data) {
  const current = campaignYear(today());
  return [
    ...new Set([
      current,
      current - 1,
      ...data.batches.map((b) => campaignYear(b.date)),
      ...effectiveEvents(data.events).map((e) => campaignYear(e.date)),
    ]),
  ].sort((a, b) => b - a);
}
export function campaignStats(data: Data, year: number) {
  const within = (date: string) =>
    date >= year + '-08-01' && date < year + 1 + '-08-01';
  const events = effectiveEvents(data.events);
  const dates = new Map(
    events
      .filter((e) => e.action === 'batch.complete')
      .map((e) => [JSON.parse(e.payload_json).batch_id, e.date]),
  );
  const completed = data.batches.filter(
    (b) =>
      b.status === 'done' && within(b.production_date || dates.get(b.id) || ''),
  );
  const volume = completed.reduce((n, b) => n + (b.oil_ml ?? toMl(b.oil_g)), 0),
    mass = toGrams(volume);
  const massBasis = completed.reduce((n, b) => n + b.net_g, 0),
    volumeBasis = massBasis;
  const sum = (action: string) =>
    events
      .filter((e) => e.action === action && within(e.date))
      .reduce((n, e) => n + (JSON.parse(e.payload_json).packaged_ml ?? 0), 0);
  return {
    label: campaignLabel(year),
    olive_g: data.batches
      .filter((b) => within(b.date))
      .reduce((n, b) => n + b.net_g, 0),
    milled_g: completed.reduce((n, b) => n + b.net_g, 0),
    oil_g: mass,
    oil_ml: volume,
    mass_yield: massBasis ? (mass / massBasis) * 100 : null,
    volume_yield: volumeBasis ? (volume / volumeBasis) * 100 : null,
    pomace_g: completed.reduce((n, b) => n + (b.pomace_g ?? 0), 0),
    water_ml: completed.reduce((n, b) => n + (b.wastewater_ml ?? 0), 0),
    missing: completed.filter(
      (b) => b.pomace_g == null || b.wastewater_ml == null,
    ).length,
    bottled_ml: sum('oil.bottle'),
    sold_ml: sum('package.sell'),
    count: completed.length,
  };
}
