import type { Data } from './domain.ts';

export const sianSources = [
  {
    title: 'SIAN · Specifiche tecniche upload v1.6 del 10/06/2011',
    url: 'https://www.sian.it/downloadpub/zfadlx010?id=56026',
  },
  {
    title: 'MASAF · Guida alla predisposizione dei file di upload v1.1',
    url: 'https://www.masaf.gov.it/flex/files/6/a/3/D.cd7127c8f4a6d663d9a8/GUIDA_UPLOAD_REGISTRO_OLIO_v.1.1.pdf',
  },
];
export function exportWarnings(data: Data) {
  const warnings = [
    'File intermedio JSON: NON caricabile direttamente sul SIAN. Tracciati, codici operazione e regole vigenti devono essere verificati prima della conversione e dell’invio.',
  ];
  for (const f of data.facilities) {
    if (!f.cuaa || !f.sian_code || !f.address)
      warnings.push(
        'Stabilimento ' +
          f.name +
          ': completare CUAA, identificativo SIAN e indirizzo.',
      );
  }
  for (const p of data.producers) {
    if (!p.fiscal_id || !p.address)
      warnings.push(
        'Anagrafica ' +
          p.name +
          ': codice fiscale/P. IVA o indirizzo mancante.',
      );
  }
  for (const b of data.batches) {
    if (
      b.olive_source === 'unknown' ||
      b.quality === 'unknown' ||
      !b.facility_id
    )
      warnings.push('Partita ' + b.id + ': dati preesistenti da integrare.');
    if (
      b.status === 'done' &&
      b.oil_g > b.returned_g &&
      !data.lots.some((l) => l.batch_id === b.id)
    )
      warnings.push(
        'Partita ' +
          b.id +
          ': giacenza non ancora assegnata a un contenitore censito.',
      );
  }
  return warnings;
}
export function buildExport(
  data: Data,
  generatedAt = new Date().toISOString(),
) {
  const { events, ...snapshot } = data;
  return {
    format: 'frantoio-interchange',
    schema_version: '2.0.0',
    generated_at: generatedAt,
    timezone: 'Europe/Rome',
    last_sequence: events.at(-1)?.seq ?? 0,
    sian: {
      status: 'intermediate_not_for_upload',
      transmitted: false,
      sources: sianSources,
      warnings: exportWarnings(data),
    },
    units: {
      canonical_oil:
        'Unico saldo operativo: millilitri. I campi kg restano per compatibilità e storico, non costituiscono un secondo saldo.',
      density_g_l:
        '916 g/L: densità convenzionale, non misura del singolo lotto.',
      '*_g': 'grammi interi; dividere per 1000 per ottenere kg',
      '*_ml': 'millilitri interi; dividere per 1000 per ottenere litri',
      units: 'numero intero di confezioni',
      dates: 'YYYY-MM-DD',
      timestamps: 'ISO 8601 UTC',
    },
    notes: [
      'Olio memorizzato in litri: kg = L × 0,916. Precisione grammo/millilitro. Le quantità originariamente inserite restano nel giornale.',
      'Rettifiche append-only: gli eventi originali restano conservati e gli effective_events descrivono la proiezione corretta. Lo snapshot è lo stato attuale.',
      'Sansa in grammi e acqua vegetazione in millilitri: null significa non rilevato, non zero.',
      'Lo storico contiene le operazioni registrate dall’introduzione del giornale. I dati precedenti sono conservati nello snapshot, senza ricostruire eventi mancanti.',
      'Il salvataggio e l’esportazione non equivalgono a trasmissione, validazione SIAN o emissione fiscale.',
    ],
    snapshot,
    events: events.map(({ payload_json, ...event }) => {
      const { request, ...payload } = JSON.parse(payload_json);
      return {
        ...event,
        payload: { ...payload, submitted_fields: JSON.parse(request) },
      };
    }),
  };
}
