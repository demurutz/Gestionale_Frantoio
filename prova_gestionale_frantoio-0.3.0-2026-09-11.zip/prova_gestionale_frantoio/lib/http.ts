import { timingSafeEqual } from 'node:crypto';
import { config } from './config.ts';
import { InputError } from './domain.ts';
import type { Identity } from './access.ts';

export const noStore = {
  'Cache-Control': 'no-store, private',
  Vary: 'Cookie, X-Company-Id',
};
export function failure(error: unknown) {
  if (error instanceof InputError)
    return Response.json(
      { error: error.message },
      { status: error.status, headers: noStore },
    );
  console.error(
    'Errore gestionale',
    error instanceof Error ? error.name : 'unknown',
  );
  return Response.json(
    {
      error:
        'Operazione non disponibile. Nessuna modifica parziale è stata salvata.',
    },
    { status: 503, headers: noStore },
  );
}
export function checkOrigin(request: Request) {
  if (request.headers.get('origin') !== config().origin)
    throw new InputError('Origine della richiesta non autorizzata.', 403);
}
export function checkCsrf(request: Request, user: Identity) {
  checkOrigin(request);
  const value = request.headers.get('x-csrf-token') ?? '';
  if (
    Buffer.byteLength(value) !== Buffer.byteLength(user.csrf) ||
    !timingSafeEqual(Buffer.from(value), Buffer.from(user.csrf))
  )
    throw new InputError(
      'Richiesta scaduta o non autorizzata. Ricarica la pagina.',
      403,
    );
}
export async function jsonBody(
  request: Request,
): Promise<Record<string, unknown>> {
  if (
    request.headers.get('content-type')?.split(';')[0].trim() !==
    'application/json'
  )
    throw new InputError('Formato richiesta non valido.', 415);
  const reader = request.body?.getReader();
  if (!reader) throw new InputError('Richiesta vuota.');
  const chunks: Uint8Array[] = [];
  let length = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > 12000) {
      await reader.cancel();
      throw new InputError('Richiesta troppo grande.', 413);
    }
    chunks.push(value);
  }
  let input;
  try {
    input = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new InputError('Richiesta non valida.');
  }
  if (!input || typeof input !== 'object' || Array.isArray(input))
    throw new InputError('Richiesta non valida.');
  return input;
}
