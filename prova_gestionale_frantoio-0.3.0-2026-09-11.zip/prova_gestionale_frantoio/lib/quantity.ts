import { grams, InputError } from './domain.ts';
import type { Data } from './domain.ts';
export const OIL_DENSITY_G_L = 916;
export type OilUnit = 'kg' | 'L';
export const toMl = (g: number) => Math.round((g * 1000) / OIL_DENSITY_G_L);
export const toGrams = (ml: number) =>
  Math.round((ml * OIL_DENSITY_G_L) / 1000);
export function inputMl(
  value: unknown,
  unit: unknown,
  label: string,
  zero = false,
) {
  if (unit != null && unit !== 'kg' && unit !== 'L')
    throw new InputError('Unità non valida.');
  const n = grams(value, label, zero),
    result = unit === 'L' ? n : toMl(n);
  if (result > 1_000_000_000) throw new InputError('Quantità troppo elevata.');
  return result;
}
export function canonicalData(source: Data, updateMass = false): Data {
  const data = structuredClone(source);
  for (const c of data.containers) {
    c.capacity_ml ??= toMl(c.capacity_g);
    if (updateMass) c.capacity_g = toGrams(c.capacity_ml);
  }
  for (const s of data.stocks) {
    s.amount_ml ??= toMl(s.amount_g);
    if (updateMass) s.amount_g = toGrams(s.amount_ml);
  }
  for (const b of data.batches)
    if (b.status === 'done') {
      b.oil_ml ??= toMl(b.oil_g);
      if (updateMass) b.oil_g = toGrams(b.oil_ml);
    }
  for (const d of data.deliveries) {
    d.amount_ml ??= toMl(d.amount_g);
    if (updateMass) d.amount_g = toGrams(d.amount_ml);
  }
  for (const p of data.packages) {
    p.consumed_ml ??= toMl(p.consumed_g);
    p.density_g_l ??= p.consumed_ml ? OIL_DENSITY_G_L : null;
  }
  return data;
}
