export function config() {
  const origin = process.env.APP_ORIGIN;
  const databaseUrl = process.env.DATABASE_URL;
  if (!origin || !databaseUrl)
    throw new Error('Configura APP_ORIGIN e DATABASE_URL nel file .env.');
  const url = new URL(origin);
  if (url.origin !== origin || !['http:', 'https:'].includes(url.protocol))
    throw new Error('APP_ORIGIN deve contenere solo protocollo e host.');
  if (
    url.protocol !== 'https:' &&
    !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)
  )
    throw new Error('HTTPS obbligatorio fuori da localhost.');
  const hours = Number(process.env.SESSION_HOURS ?? 12);
  if (!Number.isInteger(hours) || hours < 1 || hours > 168)
    throw new Error('SESSION_HOURS: da 1 a 168.');
  return {
    origin,
    databaseUrl,
    secure: url.protocol === 'https:',
    sessionHours: hours,
  };
}
