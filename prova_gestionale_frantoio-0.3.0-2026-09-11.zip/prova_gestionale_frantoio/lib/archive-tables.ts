// Explicit columns exclude computed UI fields from durable records.
export const tables = {
  packagingFormats: ['packaging_formats', 'id name capacity_ml active'],
  producers: ['producers', 'id name city phone fiscal_id address country'],
  facilities: ['facilities', 'id name sian_code cuaa address'],
  containers: ['containers', 'id facility_id code capacity_g capacity_ml'],
  batches: [
    'batches',
    'id request_id producer_id date variety origin gross_g tare_g net_g status oil_g tank notes revision last_request started_at completed_at facility_id olive_source quality designation document document_date oil_ml pomace_g wastewater_ml production_date',
  ],
  deliveries: [
    'deliveries',
    'id batch_id amount_g date note created_at amount_ml',
  ],
  lots: [
    'oil_lots',
    'id label batch_id date ownership owner_id supplier_id source quality designation origin category',
  ],
  stocks: ['oil_stocks', 'id lot_id container_id amount_g amount_ml'],
  packages: [
    'packages',
    'id lot_id facility_id code date unit_ml initial_units units consumed_g format_id format_name consumed_ml density_g_l',
  ],
  sales: [
    'sales',
    'id package_id customer_id date units document document_date',
  ],
} as const;
