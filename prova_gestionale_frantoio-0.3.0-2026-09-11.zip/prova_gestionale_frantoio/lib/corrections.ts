import {
  InputError,
  textField,
  dateField,
  today,
  actionLabels,
} from './domain.ts';
import type { Data, ArchiveEvent } from './domain.ts';
import { tables } from './archive-tables.ts';
import { hydrate, fingerprint } from './archive.ts';
import { applyOperation } from './repository.ts';
import { effectiveEvents } from './production.ts';
import { canonicalData } from './quantity.ts';

type Row = Record<string, unknown> & { id: string | number };
type Key = keyof typeof tables;
const keys = Object.keys(tables) as Key[];
const rows = (data: Data, key: Key) => data[key] as unknown as Row[];
const defaults: Record<string, unknown> = {
  production_date: '',
  format_name: '',
};
export function durableState(data: Data) {
  data = canonicalData(data, true);
  return Object.fromEntries(
    keys.map((key) => [
      key,
      rows(data, key)
        .map((row) =>
          Object.fromEntries(
            tables[key][1]
              .split(' ')
              .map((c) => [c, row[c] ?? defaults[c] ?? null]),
          ),
        )
        .sort((a, b) =>
          JSON.stringify(a.id).localeCompare(JSON.stringify(b.id)),
        ),
    ]),
  );
}
function baseline(data: Data) {
  const base = structuredClone(data);
  for (const event of [...data.events].reverse()) {
    const payload = JSON.parse(event.payload_json);
    if (!Array.isArray(payload.changes))
      throw new InputError(
        'Storico privo di dettagli sufficienti per la rettifica.',
        409,
      );
    for (const change of [...payload.changes].reverse()) {
      const key = keys.find((k) => tables[k][0] === change.table);
      if (!key || !change.after)
        throw new InputError('Formato storico non rettificabile.', 409);
      const collection = rows(base, key),
        index = collection.findIndex((r) => r.id === change.after.id);
      if (change.before == null) {
        if (index >= 0) collection.splice(index, 1);
      } else {
        const previous = Object.fromEntries(
          tables[key][1]
            .split(' ')
            .map((c) => [c, change.before[c] ?? defaults[c] ?? null]),
        ) as Row;
        if (index >= 0) collection[index] = previous;
        else collection.push(previous);
      }
    }
  }
  base.events = [];
  return hydrate(base);
}
function replay(
  base: Data,
  events: ArchiveEvent[],
  originals: ArchiveEvent[],
  target?: string,
  replacement?: Record<string, unknown>,
) {
  let data = structuredClone(base);
  let canonical = false;
  const versions = new Map(
    originals.map((e) => [
      e.id,
      JSON.parse(e.payload_json).canonical_version ?? 0,
    ]),
  );
  for (const event of events) {
    const version = versions.get(event.id) ?? 0;
    if (version === 1 && !canonical) {
      data = canonicalData(data);
      canonical = true;
    }
    const command =
      event.id === target
        ? replacement!
        : JSON.parse(JSON.parse(event.payload_json).request);
    try {
      const oldPayload = JSON.parse(event.payload_json);
      const stamp =
        oldPayload.applied_at ??
        (event.action === 'batch.start'
          ? oldPayload.batch?.started_at
          : event.action === 'batch.complete'
            ? oldPayload.batch?.completed_at
            : undefined) ??
        oldPayload.changes?.find(
          (c: { table: string }) => c.table === 'deliveries',
        )?.after?.created_at ??
        event.created_at;
      const applied = applyOperation(
        hydrate(data),
        {
          ...command,
          date: command.date ?? event.date,
          ...(command.action === 'container.convert'
            ? { expected_sequence: data.events.at(-1)?.seq ?? 0 }
            : {}),
        },
        stamp,
        version !== 1,
      );
      const original = oldPayload.result;
      if (String(applied.result.id) !== String(original.id))
        throw new InputError(
          'La rettifica cambierebbe gli identificativi dello storico.',
        );
      const effective: ArchiveEvent = {
        ...event,
        date: applied.date,
        payload_json: JSON.stringify({
          request: fingerprint(command),
          result: applied.result,
          applied_at: stamp,
          ...applied.context,
          canonical_version: version,
        }),
      };
      applied.data.events.push(effective);
      data = hydrate(applied.data);
    } catch (error) {
      throw new InputError(
        'Rettifica non applicabile: operazione #' +
          event.seq +
          ' (' +
          (actionLabels[event.action] ?? event.action) +
          '). ' +
          (error instanceof Error ? error.message : 'Verifica le dipendenze.'),
        409,
      );
    }
  }
  return hydrate(canonicalData(data));
}
export function correctOperation(before: Data, input: Record<string, unknown>) {
  const requestId = textField(input.requestId, 'Identificativo operazione', 80);
  if (!/^[a-zA-Z0-9-]{8,80}$/.test(requestId))
    throw new InputError('Identificativo operazione non valido.');
  if (input.expected_sequence !== (before.events.at(-1)?.seq ?? 0))
    throw new InputError(
      'Il registro è cambiato. Ricarica e riapri la modifica.',
      409,
    );
  const reason = textField(input.reason, 'Motivo della rettifica', 1200);
  const events = effectiveEvents(before.events);
  const target = events.find((e) => e.id === input.event_id);
  if (!target)
    throw new InputError('Operazione non disponibile per la modifica.', 404);
  if (
    !input.replacement ||
    typeof input.replacement !== 'object' ||
    Array.isArray(input.replacement)
  )
    throw new InputError('Nuovi dati operazione non validi.');
  const original = JSON.parse(JSON.parse(target.payload_json).request);
  const replacement: Record<string, unknown> = {
    ...(input.replacement as Record<string, unknown>),
    action: original.action,
    requestId: original.requestId,
  };
  if (replacement.action === 'operation.correct')
    throw new InputError('Seleziona l’operazione originale.');
  // Units are a historical fact. A kg record is never silently reinterpreted as litres.
  if (replacement.volume_unit !== original.volume_unit)
    throw new InputError(
      'Mantieni l’unità originale del movimento. Il selettore kg/litri modifica solo la visualizzazione.',
    );
  const base = baseline(before);
  const current = replay(base, events, before.events);
  if (
    JSON.stringify(durableState(current)) !==
    JSON.stringify(durableState(before))
  )
    throw new InputError(
      'Lo storico richiede una verifica prima di poter applicare rettifiche. Nessun dato è stato cambiato.',
      409,
    );
  const corrected = replay(base, events, before.events, target.id, replacement);
  for (const key of keys) {
    const ids = (data: Data) =>
      rows(data, key)
        .map((r) => String(r.id))
        .sort()
        .join('|');
    if (ids(before) !== ids(corrected))
      throw new InputError(
        'Questa modifica cambierebbe la struttura dei movimenti (lotti, destinazione o numero di righe). Modifica quantità e dati mantenendo gli stessi movimenti.',
        409,
      );
  }
  return {
    data: corrected,
    date: dateField(input.date ?? today()),
    result: { id: target.id },
    context: {
      corrected_event_id: target.id,
      reason,
      replacement,
      previous_fields: original,
      effective_events: corrected.events,
    },
  };
}
