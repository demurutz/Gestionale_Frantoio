import { InputError, actionLabels } from './domain.ts';
export type Role = 'admin' | 'operator' | 'viewer';
export type Company = {
  id: string;
  name: string;
  fiscal_id: string;
  address: string;
  role: Role;
};
export type Identity = {
  id: string;
  name: string;
  email: string;
  csrf: string;
  companies: Company[];
};
export function canWrite(role: Role, action: string) {
  if (!(action in actionLabels) || role === 'viewer') return false;
  if (
    action.startsWith('facility.') ||
    action.startsWith('container.') ||
    action.startsWith('format.') ||
    action === 'operation.correct'
  )
    return role === 'admin';
  return role === 'admin' || role === 'operator';
}
export function authorize(role: Role, action: string) {
  if (!canWrite(role, action))
    throw new InputError('Non hai i permessi per questa operazione.', 403);
}
export const roleLabels: Record<Role, string> = {
  admin: 'Amministratore',
  operator: 'Operatore',
  viewer: 'Sola lettura',
};
