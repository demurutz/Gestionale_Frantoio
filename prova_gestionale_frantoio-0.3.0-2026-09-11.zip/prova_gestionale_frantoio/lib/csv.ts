import { code, kg, phase, phaseLabels } from './domain.ts';
import type { Batch } from './domain.ts';

export function batchesCsv(batches: Batch[]) {
  const header = [
    'Partita',
    'Data',
    'Conferente',
    'Cultivar',
    'Provenienza',
    'Netto olive kg',
    'Stato',
    'Olio prodotto kg',
    'Restituito kg',
    'Giacenza sfusa kg',
    'Prima destinazione',
    'Imbottigliato disponibile L',
    'Proprietà olive / lavorazione',
    'Tipologia',
    'Denominazione DOP',
    'Data produzione',
    'Olio prodotto L',
    'Restituito L',
    'Giacenza sfusa L',
    'Sansa prodotta kg',
    'Acqua vegetazione prodotta L',
    'Densità olio kg/L',
  ];
  const rows = batches.map((batch) => [
    code(batch),
    batch.date,
    batch.producer_name,
    batch.variety,
    batch.origin,
    kg(batch.net_g),
    phaseLabels[phase(batch)],
    kg(batch.oil_g),
    kg(batch.returned_g),
    kg(batch.stock_g ?? batch.oil_g - batch.returned_g),
    batch.tank,
    kg(batch.packaged_ml ?? 0),
    batch.olive_source ?? 'unknown',
    batch.quality ?? 'unknown',
    batch.designation ?? '',
    batch.production_date ?? '',
    batch.oil_ml == null ? '' : kg(batch.oil_ml),
    batch.returned_ml == null ? '' : kg(batch.returned_ml),
    batch.stock_ml == null ? '' : kg(batch.stock_ml),
    batch.pomace_g == null ? '' : kg(batch.pomace_g),
    batch.wastewater_ml == null ? '' : kg(batch.wastewater_ml),
    '0,916',
  ]);
  return (
    '\uFEFF' +
    [header, ...rows].map((row) => row.map(quoteCell).join(';')).join('\r\n')
  );
}

function quoteCell(value: string) {
  // Spreadsheet applications must treat user-entered values as text, not formulas.
  const text = /^[=+@\-\t\r\n]/.test(value) ? "'" + value : value;
  return '"' + text.replaceAll('"', '""') + '"';
}

export function downloadBatches(batches: Batch[], stock: boolean) {
  const url = URL.createObjectURL(
    new Blob([batchesCsv(batches)], { type: 'text/csv;charset=utf-8;' }),
  );
  const link = document.createElement('a');
  link.href = url;
  link.download = `frantoio-${stock ? 'giacenze' : 'partite'}.csv`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
