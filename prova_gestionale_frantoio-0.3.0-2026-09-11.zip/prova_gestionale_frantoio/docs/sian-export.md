# Esportazione e futuro adattatore SIAN

Il pulsante **Esporta registro JSON** scarica un file UTF-8 completo dall’archivio persistente. È un formato intermedio, non un file SIAN pronto per l’upload. Nessuna trasmissione viene effettuata. Le vendite sono registrazioni di magazzino, non fatture.

## Documentazione ufficiale consultata

- [SIAN: specifiche tecniche upload, versione 1.6 del 10 giugno 2011](https://www.sian.it/downloadpub/zfadlx010?id=56026): file di testo con tracciati a posizioni/lunghezze stabilite e separatori; anagrafiche, movimenti e recipienti hanno tracciati e nomi distinti. Prevede identificativo CUAA, stabilimento, progressivi, data, codice operazione, documenti, soggetti, categorie, origini e quantità. Sfuso e capacità recipienti in kg, confezionato in litri.
- [MASAF: guida alla predisposizione dei file di upload, v1.1](https://www.masaf.gov.it/flex/files/6/a/3/D.cd7127c8f4a6d663d9a8/GUIDA_UPLOAD_REGISTRO_OLIO_v.1.1.pdf).

Consultazione: 6 settembre 2026. La recente indicizzazione delle pagine non prova che questi tracciati siano ancora quelli vigenti. La documentazione pubblica del portale non ha consentito di verificare una revisione corrente. Per questo non viene generato un TXT apparentemente valido usando specifiche storiche.

## Contratto del file `frantoio-interchange` 2.0.0

- `schema_version`: versione del contratto, non del tracciato ministeriale.
- `generated_at`, `timezone`, `last_sequence`: istante e progressivo dello snapshot coerente.
- `sian`: stato `intermediate_not_for_upload`, nessun invio e avvisi sui dati incompleti.
- `snapshot`: tutte le anagrafiche (`producers`, usate anche per clienti/fornitori), stabilimenti, contenitori, partite, restituzioni, lotti olio, giacenze sfuse, lotti imbottigliati e vendite. Conserva anche le registrazioni anteriori al giornale.
- `events`: giornale ordinato per `seq`, con UUID, operazione applicativa, data dichiarata, istante di registrazione, contesto e cambiamenti normalizzati `before`/`after`. I dati anagrafici di riferimento sono fotografati nel contesto del movimento. Nessuna API consente modifica o cancellazione degli eventi.
- `payload.submitted_fields`: campi originariamente inviati dal modulo; per la conversione usare i dati normalizzati di contesto/cambiamento, non i pesi testuali del modulo.

Gli identificativi locali collegano le tabelle senza dipendere dai nomi. `facility.sian_code` e `facility.cuaa` ospitano gli identificativi esterni. I codici applicativi (per esempio `oil.bottle`) NON sono codici operazione ICQRF.

Tutti i suffissi `_g` sono grammi interi, `_ml` millilitri interi, `units` confezioni intere. Le date sono `YYYY-MM-DD`; gli istanti ISO 8601 UTC. Non arrotondare durante il lavoro. L’eventuale precisione più limitata del tracciato va gestita e riconciliata nell’adattatore.

`olive_source`: `own` (oliveti propri), `purchased` (olive acquistate, lavorazione conto proprio), `third_party` (conto terzi), `unknown` solo per dati precedenti. `lot.ownership`: `own`/`third_party`. `lot.source`: `produced`/`purchased`/`legacy`. `quality`: `normal`/`dop`/`bio`/`dop_bio`; `designation` conserva il nome DOP. Queste indicazioni sono dichiarazioni dell’operatore, non certificazioni generate dal gestionale. `category`: `pending`/`extra`/`virgin`/`lampante`.

Sfuso: `stocks.amount_ml` è l’unica quantità canonica per lotto e contenitore. Le quantità olio inserite in kg vengono convertite con densità fissa 0,916 kg/L, arrotondando al millilitro. Le colonne `_g` dell’olio sono compatibilità storica, non ulteriori giacenze. Confezionato: `packages.units × unit_ml`; `initial_units` conserva il carico e `consumed_ml` lo scarico (0 per acquisto diretto di confezioni). `packagingFormats` contiene il catalogo; `format_name` e `unit_ml` fotografano il formato usato. Le partite comprendono `oil_ml`, `pomace_g`, `wastewater_ml` e `production_date`; null significa dato non disponibile, non zero.

Le rettifiche sono eventi `operation.correct` con motivo, riferimento originale e `effective_events`. Lo snapshot contiene lo stato ricalcolato: un adattatore deve riconciliare le rettifiche senza conteggiare due volte produzione o scarichi. Gli eventi originari restano intatti.

## Prima dell’invio reale

Occorre ottenere la versione vigente di tracciati e tabelle codici dall’area SIAN autorizzata, completare/validare le anagrafiche, mappare categorie/origini/DOP/bio/operazioni, integrare eventuali dati richiesti non ancora previsti (ad esempio codifiche territoriali, certificazioni e modalità di estrazione), gestire progressivi per impresa/stabilimento, precisioni e periodi, generare i diversi file richiesti, testarli sui controlli SIAN e conservare ricevute/esiti. Le operazioni storiche modificate non devono essere inviate due volte: gli eventi `batch.update` richiedono riconciliazione con lo stato effettivamente trasmesso.

Il giornale è append-only a livello applicativo e transazionale, non un sistema di conservazione fiscale o firma digitale. Fare backup del database PostgreSQL e scaricare periodicamente il JSON. Un’esportazione non sostituisce la verifica dei termini e degli obblighi di registrazione da parte del responsabile.
