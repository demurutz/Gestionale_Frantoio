# Migrazione locale da SQLite a PostgreSQL

Il database originario in .wrangler/state è conservato e non viene usato dalla versione SaaS. Un backup dei sorgenti precedenti è in backups/pre-saas-20260909-173137. La copia GitHub precedente resta invariata.

## Importazione facoltativa dello storico

1. Arresta il vecchio gestionale SQLite. Conserva un backup completo di .wrangler/state, inclusi eventuali file WAL.
2. Avvia solo il nuovo PostgreSQL con `pnpm db:start`.
3. Crea un'azienda vuota con `node --env-file=.env scripts/company-create.mjs "Archivio storico" "responsabile@example.test"`.
4. Leggi l'ID azienda nel file privato generato sotto .local.
5. In un altro terminale, dalla cartella del progetto:

```powershell
node --env-file=.env scripts/import-sqlite.mjs "C:\percorso\archivio.sqlite" "UUID-AZIENDA"
```

Usa il database applicativo nella sottocartella d1/miniflare-D1DatabaseObject, non metadata.sqlite.

L'importatore legge SQLite senza scriverlo e mantiene uno snapshot coerente della sorgente per tutta la lettura. Blocca l'azienda di destinazione e rifiuta un archivio non vuoto. Copia stato e storico in una sola transazione PostgreSQL; un errore produce rollback. Riconosce anche lo schema iniziale senza giornale eventi. Non attribuisce un autore inventato agli eventi precedenti. Le informazioni mancanti restano sconosciute e possono essere integrate dai flussi già presenti.

La procedura non azzera dati e non fonde automaticamente aziende o archivi. Le migrazioni SQL precedenti in drizzle restano come documentazione e fixture dei test di importazione.

Le configurazioni runtime obsolete Vite/Vinext, Wrangler e Drizzle, lo schema TypeScript SQLite e il vecchio script di pubblicazione sono stati rimossi dal progetto attivo. Sono recuperabili dal backup dei sorgenti indicato sopra. La configurazione Sites in .openai resta conservata ma inattiva.

## PostgreSQL

db/migrations contiene le nuove migrazioni versionate. Il relativo checksum impedisce di modificare silenziosamente una migrazione applicata. Non cambiare a mano le tabelle in uso: aggiungere una nuova migrazione.

Conserva insieme .env e .local per le prove locali. Copiare direttamente .local/postgres mentre il database è attivo non è un backup consistente: arrestalo prima oppure usa gli strumenti PostgreSQL. Il collaudo di backup/ripristino nel cloud è una fase successiva.
