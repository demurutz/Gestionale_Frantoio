# Architettura SaaS locale

## Applicazione

Un progetto Next.js 16 / React 19, Route Handler TypeScript su runtime Node.js e PostgreSQL 18. Non usa più Vinext, Cloudflare Workers o D1 durante l'esecuzione. La configurazione Sites precedente è conservata, ma inattiva.

Le regole operative restano in lib/repository.ts. lib/archive.ts legge e salva tabelle PostgreSQL normalizzate. lib/archive-tables.ts definisce le sole colonne persistenti, escludendo i valori calcolati dell'interfaccia.

## Isolamento e concorrenza

Tutte le tabelle gestionali hanno tenant_id, chiavi e riferimenti compositi per azienda, più Row Level Security con USING e WITH CHECK. Il ruolo applicativo non è proprietario, superuser o BYPASSRLS.

Ogni API aziendale verifica sessione e membership sul server. Le scritture bloccano la riga azienda prima di leggere le giacenze; stato e audit sono salvati nella stessa transazione. Le letture multiple usano REPEATABLE READ READ ONLY. set_config(..., true) limita il contesto aziendale alla transazione, evitando contaminazioni quando la connessione torna nel pool.

Le richieste duplicate sono identificate per azienda; lo stesso ID con dati diversi viene rifiutato. Gli eventi conservano autore e stato prima/dopo; il ruolo web può leggerli e inserirli, non modificarli o cancellarli.

## Ruoli

| Ruolo | Operazioni | Stabilimenti/contenitori | Azienda e utenti | Consultazione/export |
| --- | --- | --- | --- | --- |
| Amministratore | Sì | Sì | Sì | Sì |
| Operatore | Sì | No | No | Sì |
| Sola lettura | No | No | No | Sì |

L'azienda non coincide con uno stabilimento: un frantoio/azienda può avere diversi stabilimenti. Un utente può avere ruoli differenti in più aziende.

## Accessi e configurazione

Password scrypt con salt casuale, sessioni opache conservate come hash e cookie HttpOnly/SameSite; Secure su HTTPS. Sessioni revocate al logout e al cambio password, con controllo concorrente dell'hash. I POST verificano l'origine configurata; quelli autenticati richiedono anche il token CSRF. Sono applicati limiti alla dimensione delle richieste e ai tentativi login.

Nessuna dipendenza da email o account esterni nella prova locale. Gli utenti vengono creati dall'amministratore aziendale; l'associazione privilegiata di account esistenti resta alla piattaforma. Configurazioni e segreti sono esterni al codice.

## Limiti intenzionali prima del cloud

Questa versione non è un'autorizzazione al lancio pubblico. Restano da collaudare TLS/proxy, dominio, email di recupero/invito, backup e ripristino PostgreSQL, osservabilità, protezione distribuita dagli abusi e carico reale. Non ci sono abbonamenti/pagamenti automatici.

La logica attuale legge lo stato aziendale completo e serializza le scritture della stessa azienda: adatta alle prove e a piccoli volumi, da misurare prima del pilota. Paginazione e query mirate si aggiungeranno sulla base dei volumi reali, senza cambiare database.

Nessuna trasmissione SIAN o emissione fiscale automatica. Le specifiche ufficiali vigenti devono essere validate prima di costruire il convertitore.

## Riferimenti tecnici

- [Next.js: autenticazione](https://nextjs.org/docs/app/guides/authentication)
- [PostgreSQL: Row Security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)
- [PostgreSQL: isolamento transazioni](https://www.postgresql.org/docs/current/transaction-iso.html)
- [OWASP: password](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html)
