'use client';
import Link from 'next/link';
import { useState } from 'react';
import { Choice } from '@/components/operation-form';
import { Button } from '@/components/ui/button';
import { roleLabels } from '@/lib/access';
import type { Identity, Company } from '@/lib/access';
export default function AccountControls({
  user,
  company,
}: {
  user: Identity;
  company?: Company;
}) {
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  async function action(name: string, body: object = {}) {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      const response = await fetch('/api/auth/' + name, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': user.csrf,
        },
        body: JSON.stringify(body),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error);
      window.location.assign(name === 'logout' ? '/login' : '/');
    } catch (error) {
      setError(
        error instanceof Error ? error.message : 'Connessione non disponibile.',
      );
      setBusy(false);
    }
  }
  return (
    <div className="account-controls">
      {company && (
        <Choice
          label="Azienda attiva"
          value={company.id}
          options={user.companies.map((c) => ({ value: c.id, label: c.name }))}
          onChange={(id) => void action('switch', { companyId: id })}
        />
      )}
      <span>
        {user.name}
        {company ? ' · ' + roleLabels[company.role] : ''}
      </span>
      <Link prefetch={false} href="/account">
        Account
      </Link>
      {company?.role === 'admin' && (
        <Link prefetch={false} href="/admin">
          Azienda e utenti
        </Link>
      )}
      <Button
        variant="outline"
        disabled={busy}
        onClick={() => void action('logout')}
      >
        Esci
      </Button>
      {error && <p role="alert">{error}</p>}
    </div>
  );
}
