'use client';
import { createContext, useContext, useState } from 'react';
import { kg } from '@/lib/domain';
import { toGrams, inputMl } from '@/lib/quantity';
import type { OilUnit } from '@/lib/quantity';
export const OilUnitContext = createContext<OilUnit>('L');
export function oilText(ml: number, unit: OilUnit) {
  return (
    (unit === 'kg' ? '≈ ' : '') +
    kg(unit === 'kg' ? toGrams(ml) : ml) +
    ' ' +
    unit
  );
}
// Keep the exact millilitres while switching a draft's presentation unit.
export function useOilDraft(
  initialUnit: OilUnit,
  initialMl: number | null = null,
) {
  const text = (ml: number | null, unit: OilUnit) =>
    ml == null ? '' : String((unit === 'kg' ? toGrams(ml) : ml) / 1000);
  const [draft, setDraft] = useState({
    unit: initialUnit,
    ml: initialMl,
    value: text(initialMl, initialUnit),
  });
  return {
    ...draft,
    changeUnit: (value: string) => {
      if (value !== 'kg' && value !== 'L') return;
      setDraft((d) => ({ unit: value, ml: d.ml, value: text(d.ml, value) }));
    },
    setValue: (value: string) =>
      setDraft((d) => {
        let ml: number | null = null;
        try {
          ml = inputMl(value, d.unit, 'Quantità');
        } catch {
          /* Preserve invalid input for field validation. */
        }
        return { ...d, value, ml };
      }),
  };
}
export function useOilUnit() {
  const unit = useContext(OilUnitContext);
  return { unit, formatOil: (ml: number) => oilText(ml, unit) };
}
