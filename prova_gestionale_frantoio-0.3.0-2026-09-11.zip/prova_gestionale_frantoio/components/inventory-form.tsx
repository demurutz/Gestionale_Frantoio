'use client';
import { useState } from 'react';
import type { SubmitEvent } from 'react';
import {
  kg,
  today,
  qualityLabels,
  categoryLabels,
  sourceLabels,
  stockAmount,
  capacityLabel,
} from '@/lib/domain';
import type {
  Data,
  Batch,
  Facility,
  OilStock,
  OilLot,
  OilPackage,
} from '@/lib/domain';
import { Field, Pick, Documents, Amount } from './form-fields';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { PackageLines } from './production-forms';
import type { PackageLine } from './production-forms';
import { useOilUnit, useOilDraft } from './oil-unit';
import { toGrams, toMl } from '@/lib/quantity';

export type InventoryOperationInput =
  | { kind: 'facility.create' | 'container.create' | 'oil.receive' }
  | { kind: 'facility.update'; facility: Facility }
  | { kind: 'oil.adopt' | 'batch.integrate'; batch: Batch }
  | { kind: 'oil.classify'; lot: OilLot }
  | { kind: 'oil.transfer' | 'oil.return' | 'oil.bottle'; stock: OilStock }
  | { kind: 'package.sell' | 'package.return'; pack: OilPackage };
export type InventoryOperation = InventoryOperationInput & {
  requestId: string;
};
export const inventoryTitles = {
  'facility.create': 'Nuovo stabilimento / deposito',
  'facility.update': 'Dati stabilimento',
  'container.create': 'Censisci contenitore',
  'oil.receive': 'Carica olio in magazzino',
  'oil.adopt': 'Integra giacenza preesistente',
  'batch.integrate': 'Integra dati della partita',
  'oil.classify': 'Classifica olio',
  'oil.transfer': 'Trasferisci olio',
  'oil.return': 'Ritiro olio del cliente',
  'oil.bottle': 'Imbottiglia olio sfuso',
  'package.sell': 'Vendi olio imbottigliato',
  'package.return': 'Ritiro olio imbottigliato',
};
export function isInventoryOperation(op: {
  kind: string;
}): op is InventoryOperation {
  return op.kind in inventoryTitles;
}
const options = (labels: Record<string, string>) =>
  Object.entries(labels)
    .filter(([value]) => value !== 'unknown')
    .map(([value, label]) => ({ value, label }));

export default function InventoryForm({
  operation,
  data,
  busy,
  error,
  save,
  cancel,
}: {
  operation: InventoryOperation;
  data: Data;
  busy: boolean;
  error: string;
  save: (body: Record<string, unknown>) => Promise<void>;
  cancel: () => void;
}) {
  const kind = operation.kind;
  const b = 'batch' in operation ? operation.batch : undefined;
  const s = 'stock' in operation ? operation.stock : undefined;
  const pack = 'pack' in operation ? operation.pack : undefined;
  const lot =
    'lot' in operation
      ? operation.lot
      : data.lots.find((l) => l.id === (s?.lot_id ?? pack?.lot_id));
  const f = 'facility' in operation ? operation.facility : undefined;
  const [quality, setQuality] = useState(
    b?.quality === 'unknown' ? '' : (b?.quality ?? 'normal'),
  );
  const [source, setSource] = useState('purchased');
  const [ownership, setOwnership] = useState('own');
  const [format, setFormat] = useState('bulk');
  const { unit: preferred, formatOil } = useOilUnit();
  const quantity = useOilDraft(preferred, s ? stockAmount(s) : null);
  const { unit, changeUnit: setUnit } = quantity;
  const [lines, setLines] = useState<PackageLine[]>([
    { format_id: '', units: '1' },
  ]);
  const packagedVolume = lines.reduce(
    (n, r) =>
      n +
      (data.packagingFormats.find((f) => f.id === r.format_id)?.capacity_ml ??
        0) *
        (Number(r.units) || 0),
    0,
  );
  const packaging =
    kind === 'oil.bottle' || (kind === 'oil.receive' && format === 'packaged');
  const receive = kind === 'oil.receive' || kind === 'oil.adopt';
  const people = data.producers.map((p) => ({ value: p.id, label: p.name }));
  const facilities = data.facilities.map((f) => ({
    value: f.id,
    label: f.name,
  }));
  const sourceContainer = data.containers.find((c) => c.id === s?.container_id);
  const containers = data.containers
    .filter((c) => {
      if (c.id === s?.container_id) return false;
      if (
        lot?.ownership === 'third_party' &&
        sourceContainer &&
        c.facility_id !== sourceContainer.facility_id
      )
        return false;
      return !data.stocks.some(
        (stock) =>
          stock.container_id === c.id &&
          stockAmount(stock) > 0 &&
          stock.lot_id !== lot?.id,
      );
    })
    .map((c) => ({
      value: c.id,
      label:
        c.code +
        ' · ' +
        data.facilities.find((f) => f.id === c.facility_id)?.name +
        ' · capacità ' +
        capacityLabel(c),
    }));
  const needsContainer =
    (receive && (kind === 'oil.adopt' || format === 'bulk')) ||
    kind === 'oil.transfer';
  const needsPeople =
    kind === 'package.sell' ||
    (receive &&
      (ownership === 'third_party' ||
        (kind === 'oil.receive' && source === 'purchased')));
  const setupMissing =
    (packaging && !data.packagingFormats.some((f) => f.active)) ||
    (needsContainer && !containers.length) ||
    (needsPeople && !people.length) ||
    ((kind === 'container.create' ||
      (receive && format === 'packaged') ||
      kind === 'batch.integrate') &&
      !facilities.length);
  async function submit(event: SubmitEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || setupMissing) return;
    await save({
      ...Object.fromEntries(new FormData(event.currentTarget)),
      action: kind,
      requestId: operation.requestId,
      volume_unit: quantity.ml == null ? unit : 'L',
      ...(quantity.ml != null &&
      (kind === 'container.create' ||
        kind === 'oil.receive' ||
        kind === 'oil.return' ||
        kind === 'oil.transfer')
        ? {

            ...(kind === 'container.create'
              ? { capacity_l: quantity.ml / 1000 }
              : { amount: quantity.ml / 1000 }),
          }
        : {}),
      ...(packaging ? { items: lines } : {}),
      ...(b ? { id: b.id, revision: b.revision } : {}),
      ...(s ? { stock_id: s.id } : {}),
      ...(lot ? { lot_id: lot.id } : {}),
      ...(pack ? { package_id: pack.id } : {}),
      ...(f ? { id: f.id } : {}),
    });
  }
  return (
    <form className="operation-form" onSubmit={submit}>
      <fieldset disabled={busy}>
        {lot && (
          <div className="form-context">
            <strong>{lot.label}</strong>
            <span>
              {categoryLabels[lot.category]} ·{' '}
              {s
                ? formatOil(stockAmount(s)) + ' disponibili'
                : pack
                  ? pack.units + ' bottiglie disponibili'
                  : qualityLabels[lot.quality]}
            </span>
          </div>
        )}
        {kind.startsWith('facility.') && (
          <>
            <Field label="Nome stabilimento / deposito *">
              <Input
                name="name"
                defaultValue={f?.name}
                required
                maxLength={160}
              />
            </Field>
            <Field label="Indirizzo completo">
              <Input name="address" defaultValue={f?.address} maxLength={200} />
            </Field>
            <div className="form-grid">
              <Field label="CUAA impresa">
                <Input name="cuaa" defaultValue={f?.cuaa} maxLength={16} />
              </Field>
              <Field label="Identificativo stabilimento SIAN">
                <Input
                  name="sian_code"
                  defaultValue={f?.sian_code}
                  maxLength={40}
                />
              </Field>
            </div>
            <p className="form-explanation">
              Censisci i tuoi stabilimenti e depositi. CUAA e identificativo
              SIAN possono essere completati prima della conversione del
              registro.
            </p>
          </>
        )}
        {kind === 'container.create' && (
          <>
            <Pick
              name="facility_id"
              label="Stabilimento"
              options={facilities}
            />
            <Field label="Codice contenitore *">
              <Input
                name="code"
                maxLength={10}
                required
                placeholder="Es. CT-01"
              />
            </Field>
            <Pick
              name="volume_unit"
              label="Unità silos"
              value={unit}
              onChange={setUnit}
              options={[
                { value: 'kg', label: 'kg' },
                { value: 'L', label: 'litri' },
              ]}
            />
            <Amount
              name={unit === 'kg' ? 'capacity' : 'capacity_l'}
              label={'Capacità massima (' + unit + ')'}
              value={quantity.value}
              onChange={quantity.setValue}
            />
            <p className="form-explanation">
              Il contenitore viene creato vuoto. Carica l’olio con una
              produzione o con “Carica olio”. Un contenitore ospita un solo
              lotto attivo; non vengono miscelati oli diversi.
            </p>
          </>
        )}
        {kind === 'batch.integrate' && (
          <>
            <p className="form-explanation">
              Completa soltanto le informazioni mancanti della partita. Pesi,
              stato e lavorazioni già registrate non vengono cambiati.
            </p>
            <Pick
              name="facility_id"
              label="Stabilimento di molitura"
              options={facilities}
              defaultValue={b?.facility_id ?? ''}
            />
            <Pick
              name="olive_source"
              label="Olive e lavorazione"
              options={options(sourceLabels)}
              defaultValue={
                b?.olive_source === 'unknown' ? '' : b?.olive_source
              }
            />
          </>
        )}
        {receive && (
          <>
            {kind === 'oil.adopt' ? (
              <p className="form-explanation">
                Assegna{' '}
                {formatOil(
                  (b!.oil_ml ?? toMl(b!.oil_g)) -
                    (b!.returned_ml ?? toMl(b!.returned_g)),
                )}{' '}
                già registrati a un contenitore. Non è una nuova produzione né
                un nuovo acquisto.
              </p>
            ) : (
              <>
                <Pick
                  name="source"
                  label="Origine del carico"
                  value={source}
                  onChange={(value) => {
                    setSource(value);
                    if (value === 'purchased') setOwnership('own');
                  }}
                  options={[
                    {
                      value: 'purchased',
                      label: 'Olio acquistato dal cliente / fornitore',
                    },
                    {
                      value: 'produced',
                      label: 'Produzione interna preesistente',
                    },
                  ]}
                />
                <p className="form-explanation">
                  Per una nuova molitura usa “Partite e molitura”: il carico
                  dell’olio sarà automatico. Qui inserisci acquisti o giacenze
                  iniziali non ancora registrate.
                </p>
                <Field label="Riferimento lotto olio *">
                  <Input name="label" required maxLength={100} />
                </Field>
              </>
            )}
            <Pick
              name="ownership"
              label="Proprietà olio"
              value={ownership}
              onChange={setOwnership}
              options={
                kind === 'oil.receive' && source === 'purchased'
                  ? [{ value: 'own', label: 'Frantoio · olio proprio' }]
                  : [
                      { value: 'own', label: 'Frantoio · olio proprio' },
                      { value: 'third_party', label: 'Cliente · conto terzi' },
                    ]
              }
            />
            {ownership === 'third_party' && (
              <Pick
                name="owner_id"
                label="Proprietario / committente"
                options={people}
                defaultValue={b?.producer_id}
              />
            )}
            {kind === 'oil.receive' && source === 'purchased' && (
              <Pick
                name="supplier_id"
                label="Cliente / fornitore da cui acquisti"
                options={people}
              />
            )}
            {kind === 'oil.receive' && (
              <Field label="Origine dell’olio *">
                <Input
                  name="origin"
                  required
                  maxLength={160}
                  placeholder="Paese/i di origine e provenienza"
                />
              </Field>
            )}
          </>
        )}
        {(receive || kind === 'batch.integrate') && (
          <>
            <Pick
              name="quality"
              label="Tipologia olive / olio"
              value={quality}
              onChange={setQuality}
              options={options(qualityLabels)}
            />
            {quality.includes('dop') && (
              <Field label="Denominazione D.O.P. *">
                <Input
                  name="designation"
                  defaultValue={b?.designation}
                  required
                  maxLength={160}
                />
              </Field>
            )}
          </>
        )}
        {(receive || kind === 'oil.classify') && (
          <Pick
            name="category"
            label="Categoria dell’olio"
            options={options(categoryLabels).filter(
              (o) => kind !== 'oil.classify' || o.value !== 'pending',
            )}
            defaultValue={kind === 'oil.classify' ? '' : 'pending'}
          />
        )}
        {kind === 'oil.receive' && (
          <Pick
            name="format"
            label="Stato dell’olio"
            value={format}
            onChange={setFormat}
            options={[
              { value: 'bulk', label: 'Sfuso' },
              { value: 'packaged', label: 'Già imbottigliato' },
            ]}
          />
        )}
        {kind === 'oil.receive' && format === 'bulk' && (
          <Pick
            name="volume_unit"
            label="Unità giacenza"
            value={unit}
            onChange={setUnit}
            options={[
              { value: 'kg', label: 'kg' },
              { value: 'L', label: 'litri' },
            ]}
          />
        )}
        {needsContainer && (
          <Pick
            name="container_id"
            label="Contenitore di destinazione"
            options={containers}
          />
        )}
        {((kind === 'oil.receive' && format === 'bulk') ||
          (!!s && kind !== 'oil.bottle')) && (
          <Amount
            label={'Quantità olio (' + unit + ')'}
            max={
              s
                ? (unit === 'kg' ? toGrams(stockAmount(s)) : stockAmount(s)) /
                  1000
                : undefined
            }
            value={quantity.value}
            onChange={quantity.setValue}
          />
        )}
        {((kind === 'oil.receive' && format === 'packaged') ||
          kind === 'oil.bottle') && (
          <>
            {kind === 'oil.receive' && (
              <Pick
                name="facility_id"
                label="Stabilimento di deposito"
                options={facilities}
              />
            )}
            <Field label="Lotto imbottigliamento *">
              <Input name="package_code" required maxLength={100} />
            </Field>
            <PackageLines
              formats={data.packagingFormats}
              lines={lines}
              setLines={setLines}
            />
            {kind === 'oil.bottle' && (
              <output className="calculation">
                Scarico dal silos
                <strong>{formatOil(packagedVolume)}</strong>
              </output>
            )}
            <p className="form-explanation">
              Il totale è scaricato in litri. L’equivalente in kg usa 0,916 kg/L
              e non crea una seconda giacenza.
            </p>
          </>
        )}
        {pack && (
          <Field label="Numero bottiglie *">
            <Input
              name="units"
              type="number"
              min="1"
              max={pack?.units ?? 9999999}
              step="1"
              required
            />
          </Field>
        )}
        {kind === 'package.sell' && (
          <Pick
            name="customer_id"
            label="Cliente acquirente"
            options={people}
          />
        )}
        {!kind.startsWith('facility.') && kind !== 'container.create' && (
          <>
            <Field label="Data operazione *">
              <Input name="date" type="date" defaultValue={today()} required />
            </Field>
            <Documents
              required={
                kind === 'package.sell' ||
                kind === 'oil.classify' ||
                (kind === 'oil.receive' && source === 'purchased') ||
                (kind === 'oil.transfer' && lot?.ownership === 'own')
              }
            />
            <Field label="Note movimento">
              <textarea name="note" rows={2} maxLength={1200} />
            </Field>
          </>
        )}
        {kind === 'oil.classify' && (
          <p className="form-explanation">
            Indica il riferimento alle analisi o alla documentazione di
            classificazione. Il gestionale registra la categoria dichiarata
            dall’operatore, non la certifica.
          </p>
        )}
        {kind === 'package.sell' && (
          <p className="form-explanation">
            La vendita scarica le bottiglie dal deposito e conserva il
            riferimento al documento. Non emette una fattura.
          </p>
        )}
        {setupMissing && (
          <p role="alert" className="form-error">
            Prima di continuare, aggiungi in “Depositi e contenitori” uno
            stabilimento e un contenitore libero, oppure l’anagrafica necessaria
            in “Conferenti”. Chiudi questo modulo per completare la
            configurazione.
          </p>
        )}
        {error && (
          <p role="alert" className="form-error">
            {error}
          </p>
        )}
        <div className="form-actions">
          <Button variant="outline" type="button" onClick={cancel}>
            Annulla
          </Button>
          <Button type="submit" disabled={setupMissing}>
            {busy ? 'Salvataggio…' : 'Salva registrazione'}
          </Button>
        </div>
      </fieldset>
    </form>
  );
}
