import { ArrowRight, ChevronRight, Droplets, Pencil } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import {
  Table,
  TableHeader,
  TableHead,
  TableRow,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import {
  code,
  kg,
  phase,
  phaseLabels,
  sourceLabels,
  qualityLabels,
} from '@/lib/domain';
import type { Batch, Delivery } from '@/lib/domain';
import type { OperationInput } from '@/components/operation-form';
import { useOilUnit } from './oil-unit';
import { toMl, toGrams } from '@/lib/quantity';

function dateLabel(date: string) {
  return new Date(date + 'T12:00:00').toLocaleDateString('it-IT');
}
function timestamp(date: string | null) {
  return date
    ? new Date(date).toLocaleString('it-IT', {
        timeZone: 'Europe/Rome',
        dateStyle: 'short',
        timeStyle: 'short',
      })
    : '—';
}
function BatchStatus({ batch }: { batch: Batch }) {
  const status = phase(batch);
  return (
    <span className={'status-badge ' + status}>
      <span />
      {phaseLabels[status]}
    </span>
  );
}

export function BatchTable({
  batches,
  onSelect,
}: {
  batches: Batch[];
  onSelect: (id: number) => void;
}) {
  return (
    <Table className="records-table">
      <TableHeader>
        <TableRow>
          <TableHead>Partita / conferente</TableHead>
          <TableHead>Conferimento</TableHead>
          <TableHead>Olive nette</TableHead>
          <TableHead>Cultivar / tipologia</TableHead>
          <TableHead>Stato</TableHead>
          <TableHead>
            <span className="sr-only">Dettagli</span>
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {batches.map((batch) => (
          <TableRow key={batch.id}>
            <TableCell>
              <span className="batch-code">{code(batch)}</span>
              <strong>{batch.producer_name}</strong>
            </TableCell>
            <TableCell>{dateLabel(batch.date)}</TableCell>
            <TableCell className="numeric">
              {kg(batch.net_g)} <small>kg</small>
            </TableCell>
            <TableCell>
              {batch.variety}
              <small className="cell-note">
                {qualityLabels[batch.quality]} ·{' '}
                {sourceLabels[batch.olive_source]}
              </small>
            </TableCell>
            <TableCell>
              <BatchStatus batch={batch} />
            </TableCell>
            <TableCell>
              <Button
                variant="ghost"
                onClick={() => onSelect(batch.id)}
                aria-label={'Apri ' + code(batch)}
              >
                Apri <ChevronRight size={15} />
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

export function BatchDetails({
  batch,
  deliveries,
  onClose,
  onInventory,
  onOperation,
}: {
  batch: Batch | undefined;
  deliveries: Delivery[];
  onClose: () => void;
  onInventory: () => void;
  onOperation: (operation: OperationInput) => void;
}) {
  return (
    <Sheet
      open={!!batch}
      onOpenChange={(open) => {
        if (!open) onClose();
      }}
    >
      <SheetContent className="batch-sheet">
        <SheetHeader>
          <SheetTitle>{batch ? code(batch) : 'Partita'}</SheetTitle>
          <SheetDescription>{batch?.producer_name}</SheetDescription>
        </SheetHeader>
        {batch && (
          <BatchDetailBody
            batch={batch}
            deliveries={deliveries.filter(
              (delivery) => delivery.batch_id === batch.id,
            )}
            onInventory={onInventory}
            onOperation={onOperation}
          />
        )}
      </SheetContent>
    </Sheet>
  );
}

function BatchDetailBody({
  batch,
  deliveries,
  onInventory,
  onOperation,
}: {
  batch: Batch;
  onInventory: () => void;
  deliveries: Delivery[];
  onOperation: (operation: OperationInput) => void;
}) {
  const { formatOil, unit } = useOilUnit();
  const oilMl = batch.oil_ml ?? toMl(batch.oil_g);
  const incomplete =
    batch.olive_source === 'unknown' ||
    batch.quality === 'unknown' ||
    !batch.facility_id;
  return (
    <div className="detail-body">
      <BatchStatus batch={batch} />
      <div className="detail-stats">
        <div>
          <span>Olive nette</span>
          <strong>
            {kg(batch.net_g)} <small>kg</small>
          </strong>
        </div>
        <div>
          <span>Olio prodotto</span>
          <strong>{formatOil(oilMl)}</strong>
        </div>
        <div>
          <span>Resa</span>
          <strong>
            {batch.status === 'done'
              ? (
                  ((unit === 'kg' ? toGrams(oilMl) : oilMl) / batch.net_g) *
                  100
                ).toLocaleString('it-IT', {
                  maximumFractionDigits: 2,
                })
              : '—'}{' '}
            <small>{unit === 'kg' ? '%' : 'L/100 kg'}</small>
          </strong>
        </div>
      </div>
      <dl className="detail-list">
        {[
          ['Conferimento', dateLabel(batch.date)],
          ['Cultivar', batch.variety],
          ['Olive / lavorazione', sourceLabels[batch.olive_source]],
          [
            'Tipologia',
            qualityLabels[batch.quality] +
              (batch.designation ? ' · ' + batch.designation : ''),
          ],
          ['Provenienza', batch.origin],
          [
            'Peso lordo / tara',
            kg(batch.gross_g) + ' / ' + kg(batch.tare_g) + ' kg',
          ],
          ['Avvio molitura', timestamp(batch.started_at)],
          ['Fine molitura', timestamp(batch.completed_at)],
          ['Prima destinazione olio', batch.tank || '—'],
          ['Data operativa produzione', batch.production_date || '—'],
          [
            'Sansa prodotta',
            batch.pomace_g == null
              ? 'Non registrata'
              : kg(batch.pomace_g) + ' kg',
          ],
          [
            'Acqua di vegetazione',
            batch.wastewater_ml == null
              ? 'Non registrata'
              : kg(batch.wastewater_ml) + ' L',
          ],
        ].map(([label, value]) => (
          <div key={label}>
            <dt>{label}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>
      {batch.notes && (
        <div className="detail-note">
          <h3>Note di lavorazione</h3>
          <p>{batch.notes}</p>
        </div>
      )}
      <div className="detail-actions">
        {incomplete && (
          <Button
            onClick={() => onOperation({ kind: 'batch.integrate', batch })}
          >
            Integra dati mancanti
          </Button>
        )}
        {batch.status === 'waiting' && !incomplete && (
          <>
            <Button
              variant="outline"
              onClick={() => onOperation({ kind: 'batch.update', batch })}
            >
              <Pencil size={16} /> Modifica
            </Button>
            <Button onClick={() => onOperation({ kind: 'batch.start', batch })}>
              Avvia molitura <ArrowRight size={16} />
            </Button>
          </>
        )}
        {batch.status === 'working' && !incomplete && (
          <Button
            onClick={() => onOperation({ kind: 'batch.complete', batch })}
          >
            <Droplets size={16} /> Registra produzione
          </Button>
        )}
        {batch.status === 'done' && (
          <Button onClick={onInventory}>Apri magazzino</Button>
        )}
      </div>
      {batch.status === 'done' && (
        <section className="delivery-history">
          <div className="calculation">
            Giacenza sfusa
            <strong>{formatOil(batch.stock_ml ?? toMl(batch.stock_g))}</strong>
          </div>
          <p className="muted-copy">
            Imbottigliato ancora in deposito:{' '}
            {formatOil(batch.packaged_ml ?? 0)}. Trasferimenti, confezionamenti
            e vendite sono nel Registro operazioni.
          </p>
          <h3>Storico restituzioni sfuse</h3>
          {deliveries.length ? (
            deliveries.map((delivery) => (
              <div className="delivery" key={delivery.id}>
                <div>
                  <strong>
                    {formatOil(delivery.amount_ml ?? toMl(delivery.amount_g))}
                  </strong>
                  <span>{dateLabel(delivery.date)}</span>
                </div>
                {delivery.note && <p>{delivery.note}</p>}
              </div>
            ))
          ) : (
            <p className="muted-copy">Nessuna restituzione registrata.</p>
          )}
        </section>
      )}
      <p className="detail-disclaimer">
        Scheda operativa interna. Non sostituisce un documento fiscale o una
        registrazione SIAN.
      </p>
    </div>
  );
}
