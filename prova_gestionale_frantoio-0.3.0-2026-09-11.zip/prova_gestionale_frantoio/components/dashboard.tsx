'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Leaf,
  Warehouse,
  BookOpen,
  LayoutDashboard,
  Scale,
  Droplets,
  Users,
  ArrowUpRight,
  Plus,
  ChevronRight,
  CircleCheck,
  PackageCheck,
  Search,
  Download,
  RefreshCw,
  ArrowRight,
  X,
  BarChart3,
  Cylinder,
  Package,
} from 'lucide-react';
import {
  Sidebar,
  SidebarProvider,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarInset,
  SidebarTrigger,
  useSidebar,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { Empty } from '@/components/ui/empty';
import OperationForm, { Choice, titles } from '@/components/operation-form';
import type { Operation, OperationInput } from '@/components/operation-form';
import { kg, code, phase, phaseLabels, summary, emptyData } from '@/lib/domain';
import type { Data } from '@/lib/domain';
import { BatchTable, BatchDetails } from '@/components/batches';
import Producers from '@/components/producers';
import { Inventory, Deposits, Journal } from './inventory';
import { downloadBatches } from '@/lib/csv';
import AccountControls from '@/components/account-controls';
import { OilUnitContext, oilText } from './oil-unit';
import type { OilUnit } from '@/lib/quantity';
import { toMl } from '@/lib/quantity';
import {
  Silos,
  PackagingCatalog,
  Byproducts,
  Campaigns,
} from './production-views';
import { canWrite } from '@/lib/access';
import type { Identity, Company } from '@/lib/access';

const navigation = [
  { name: 'Panoramica', icon: LayoutDashboard },
  { name: 'Partite e molitura', icon: Scale },
  { name: 'Magazzino olio', icon: Droplets },
  { name: 'Depositi e contenitori', icon: Warehouse },
  { name: 'Silos', icon: Cylinder },
  { name: 'Confezioni', icon: Package },
  { name: 'Prodotti della molitura', icon: Droplets },
  { name: 'Campagne olearie', icon: BarChart3 },
  { name: 'Conferenti', icon: Users },
  { name: 'Registro operazioni', icon: BookOpen },
];
const descriptions: Record<string, string> = {
  Silos: 'Riempimento e giacenze, con cambio unità kg/litri.',
  Confezioni: 'I formati disponibili per bottiglie, latte e taniche.',
  'Prodotti della molitura': 'Olio, sansa e acqua di vegetazione.',
  'Campagne olearie': 'Confronto dal 1 agosto al 31 luglio.',
  Panoramica: 'Un unico punto di vista su olive, lavorazioni e olio.',
  'Partite e molitura':
    'Segui ogni partita, dal conferimento alla restituzione.',
  'Magazzino olio': 'Sfuso e imbottigliato, conto proprio e conto terzi.',
  'Depositi e contenitori':
    'Stabilimenti, recipienti e giacenze sempre visibili.',
  'Registro operazioni':
    'Storico completo ed esportazione dei dati per la futura conversione SIAN.',
  Conferenti:
    'Anagrafiche condivise di conferenti, clienti, fornitori e committenti.',
};
function Navigation({
  view,
  navigate,
}: {
  view: string;
  navigate: (v: string) => void;
}) {
  const { setOpenMobile } = useSidebar();
  return (
    <SidebarMenu>
      {navigation.map(({ name, icon: Icon }) => (
        <SidebarMenuItem key={name}>
          <SidebarMenuButton
            size="lg"
            isActive={view === name}
            onClick={() => {
              navigate(name);
              setOpenMobile(false);
            }}
          >
            <Icon />
            <span>{name}</span>
          </SidebarMenuButton>
        </SidebarMenuItem>
      ))}
    </SidebarMenu>
  );
}
export default function Dashboard({
  user,
  company,
}: {
  user: Identity;
  company: Company;
}) {
  const [view, setView] = useState('Panoramica');
  const [displayUnit, setDisplayUnit] = useState<OilUnit>('L');
  const [data, setData] = useState<Data>(emptyData);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [operation, setOperation] = useState<Operation | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');
  const operationLock = useRef(false);
  function navigate(next: string) {
    setView(next);
    setSearch('');
    setFilter('all');
  }
  const load = useCallback(
    (signal?: AbortSignal) => {
      return fetch('/api/frantoio', {
        cache: 'no-store',
        signal,
        headers: { 'X-Company-Id': company.id },
      })
        .then(async (response) => {
          const result = (await response.json()) as Data & { error?: string };
          if (response.status === 401) window.location.assign('/login');
          if (!response.ok)
            throw new Error(result.error ?? 'Impossibile leggere l’archivio.');
          return result;
        })
        .then((result) => {
          if (signal?.aborted) return;
          setData(result);
          setError('');
          return result;
        })
        .catch((error: unknown) => {
          if (!signal?.aborted)
            setError(
              error instanceof Error
                ? error.message
                : 'Errore di connessione. Riprova.',
            );
        })
        .finally(() => {
          if (!signal?.aborted) setLoading(false);
        });
    },
    [company.id],
  );
  useEffect(() => {
    const controller = new AbortController();
    void load(controller.signal);
    return () => controller.abort();
  }, [load]);
  function refresh() {
    setLoading(true);
    setError('');
    return load();
  }
  function open(input: OperationInput) {
    if (!canWrite(company.role, input.kind)) {
      setNotice('Il tuo ruolo non consente questa operazione.');
      return;
    }
    setSelected(null);
    setFormError('');
    setNotice('');
    const next: OperationInput =
      input.kind === 'batch.create' && !data.producers.length
        ? { kind: 'producer.create', next: 'batch.create' }
        : input;
    setOperation({ ...next, requestId: crypto.randomUUID() });
  }
  async function save(body: Record<string, unknown>) {
    if (operationLock.current) return;
    operationLock.current = true;
    setBusy(true);
    setFormError('');
    try {
      const response = await fetch('/api/frantoio', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Company-Id': company.id,
          'X-CSRF-Token': user.csrf,
        },
        body: JSON.stringify(body),
      });
      const result = (await response.json()) as {
        result: { id: string | number };
        error?: string;
      };
      if (!response.ok)
        throw new Error(
          result.error ?? 'Impossibile salvare la registrazione.',
        );
      setNotice('Registrazione salvata nell’archivio.');
      const refreshed = await refresh();
      if (
        refreshed &&
        operation?.kind === 'producer.create' &&
        operation.next === 'batch.create'
      ) {
        setOperation({
          kind: 'batch.create',
          producerId: String(result.result.id),
          requestId: crypto.randomUUID(),
        });
      } else setOperation(null);
    } catch (e) {
      setFormError(
        e instanceof Error
          ? e.message
          : 'Connessione interrotta. Riprova: la stessa operazione non verrà duplicata.',
      );
    } finally {
      operationLock.current = false;
      setBusy(false);
    }
  }
  const totals = summary(data.batches);
  const bulkStock =
    data.batches
      .filter((b) => !data.lots.some((l) => l.batch_id === b.id))
      .reduce((n, b) => n + b.oil_g - b.returned_g, 0) +
    data.stocks
      .filter((s) => s.amount_ml == null)
      .reduce((n, s) => n + s.amount_g, 0);
  const bulkMl = data.stocks.reduce((n, s) => n + (s.amount_ml ?? 0), 0);
  const producedMl = data.batches.reduce(
    (n, b) => n + (b.oil_ml ?? toMl(b.oil_g)),
    0,
  );
  const packagedMl = data.packages.reduce((n, p) => n + p.units * p.unit_ml, 0);
  const unavailable = loading || !!error;
  const query = search.trim().toLocaleLowerCase('it-IT');
  const matching = data.batches.filter(
    (b) =>
      (!query ||
        [code(b), b.producer_name, b.variety, b.origin, b.tank]
          .join(' ')
          .toLocaleLowerCase('it-IT')
          .includes(query)) &&
      (filter === 'all' || phase(b) === filter),
  );
  const rows = view === 'Panoramica' ? matching.slice(0, 6) : matching;
  const producers = data.producers.filter((p) =>
    [p.name, p.city, p.phone]
      .join(' ')
      .toLocaleLowerCase('it-IT')
      .includes(query),
  );
  const selectedBatch = data.batches.find((b) => b.id === selected);
  const stockView = view === 'Magazzino olio';
  function renderRecords() {
    if (loading)
      return (
        <output className="loading-rows" aria-label="Caricamento archivio">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-4/5" />
        </output>
      );
    if (error)
      return (
        <Empty className="empty-state">
          <h3>Archivio non raggiungibile</h3>
          <p>Riprova per visualizzare dati aggiornati e continuare.</p>
        </Empty>
      );
    if (view === 'Silos')
      return (
        <Silos
          data={data}
          query={query}
          onOperation={open}
          canManage={company.role === 'admin'}
        />
      );
    if (view === 'Confezioni')
      return (
        <PackagingCatalog
          data={data}
          query={query}
          onOperation={open}
          canManage={company.role === 'admin'}
        />
      );
    if (view === 'Prodotti della molitura')
      return <Byproducts data={data} query={query} />;
    if (view === 'Campagne olearie') return <Campaigns data={data} />;
    if (view === 'Magazzino olio')
      return <Inventory data={data} query={query} onOperation={open} />;
    if (view === 'Depositi e contenitori')
      return <Deposits data={data} query={query} onOperation={open} />;
    if (view === 'Registro operazioni')
      return (
        <Journal
          data={data}
          query={query}
          companyId={company.id}
          onOperation={open}
          canEdit={company.role === 'admin'}
        />
      );
    if (view === 'Conferenti')
      return (
        <Producers
          producers={producers}
          batches={data.batches}
          query={query}
          onCreate={() => open({ kind: 'producer.create' })}
          onEdit={(producer) => open({ kind: 'producer.update', producer })}
        />
      );
    if (rows.length)
      return (
        <>
          <BatchTable batches={rows} onSelect={setSelected} />
          <div className="table-foot">
            <span>
              {rows.length} {rows.length === 1 ? 'partita' : 'partite'}
              {view === 'Panoramica' ? ' visualizzate' : ''}
            </span>
            {view === 'Panoramica' && (
              <button onClick={() => navigate('Partite e molitura')}>
                Tutte le partite <ArrowRight size={15} />
              </button>
            )}
          </div>
        </>
      );
    return (
      <Empty className="empty-state">
        <Scale size={30} />
        <h3>
          {query || filter !== 'all'
            ? 'Nessuna partita corrispondente'
            : stockView
              ? 'Nessun olio in giacenza'
              : 'Il quaderno è pronto per la prima partita'}
        </h3>
        <p>
          {query || filter !== 'all'
            ? 'Modifica la ricerca o il filtro per trovare altre partite.'
            : stockView
              ? 'L’olio compare qui quando completi una molitura.'
              : 'Registra il conferente e il peso delle olive. Seguirai qui la molitura, la resa e l’olio restituito.'}
        </p>
        {!query && filter === 'all' && !stockView && (
          <Button
            className="primary-action"
            onClick={() => open({ kind: 'batch.create' })}
          >
            <Plus size={18} /> Registra il primo conferimento
          </Button>
        )}
        {stockView && (
          <Button
            variant="outline"
            onClick={() => navigate('Partite e molitura')}
          >
            Apri le partite <ArrowRight size={16} />
          </Button>
        )}
      </Empty>
    );
  }
  return (
    <OilUnitContext.Provider value={displayUnit}>
      <SidebarProvider>
        <Sidebar>
          <SidebarHeader className="brand">
            <div className="brand-mark">
              <Leaf size={25} />
            </div>
            <div>
              <strong>
                frantoio<span>.</span>
              </strong>
              <small>QUADERNO OPERATIVO</small>
            </div>
          </SidebarHeader>
          <SidebarContent className="nav-content">
            <p className="nav-label">IL TUO FRANTOIO</p>
            <Navigation view={view} navigate={navigate} />
          </SidebarContent>
          <SidebarFooter className="sidebar-note">
            <Leaf size={22} />
            <strong>Dall’oliva all’olio.</strong>
            <p>Ogni partita, il suo percorso.</p>
            <div>
              VERSIONE ESSENZIALE <span>01</span>
            </div>
          </SidebarFooter>
        </Sidebar>
        <SidebarInset className="min-w-0">
          <header className="topbar">
            <div className="flex items-center gap-3">
              <SidebarTrigger aria-label="Apri o chiudi navigazione" />
              <span>Gestione operativa</span>
              <ChevronRight size={14} />
              <strong>{view}</strong>
            </div>
            <AccountControls user={user} company={company} />
            <label className="unit-switch">
              Mostra olio in
              <select
                className="native-choice"
                value={displayUnit}
                onChange={(e) => setDisplayUnit(e.target.value as OilUnit)}
              >
                <option value="L">Litri</option>
                <option value="kg">kg · 0,916 kg/L</option>
              </select>
            </label>
          </header>
          <div className="workspace">
            <section className="page-heading">
              <div>
                <p className="eyebrow">IL LAVORO, SOTTO CONTROLLO</p>
                <h1>{view}</h1>
                <p>{descriptions[view]}</p>
              </div>
              <Button
                disabled={
                  unavailable ||
                  company.role === 'viewer' ||
                  (['Depositi e contenitori', 'Silos', 'Confezioni'].includes(
                    view,
                  ) &&
                    company.role !== 'admin')
                }
                className="primary-action"
                onClick={() =>
                  open({
                    kind:
                      view === 'Conferenti'
                        ? 'producer.create'
                        : view === 'Silos'
                          ? 'container.create'
                          : view === 'Confezioni'
                            ? 'format.create'
                            : view === 'Depositi e contenitori'
                              ? 'facility.create'
                              : view === 'Magazzino olio'
                                ? 'oil.receive'
                                : 'batch.create',
                  })
                }
              >
                <Plus size={18} />
                {view === 'Conferenti'
                  ? 'Nuova anagrafica'
                  : view === 'Silos'
                    ? 'Nuovo silos'
                    : view === 'Confezioni'
                      ? 'Nuova confezione'
                      : view === 'Depositi e contenitori'
                        ? 'Nuovo stabilimento'
                        : view === 'Magazzino olio'
                          ? 'Carica olio'
                          : 'Carica olive'}
              </Button>
            </section>
            {error && (
              <div role="alert" className="message error">
                <div>
                  <strong>Non è possibile aggiornare l’archivio.</strong>
                  <p>{error}</p>
                </div>
                <Button variant="outline" onClick={() => void refresh()}>
                  <RefreshCw size={16} /> Riprova
                </Button>
              </div>
            )}
            {notice && (
              <output className="message success">
                <CircleCheck size={18} />
                <span>{notice}</span>
                <button
                  aria-label="Chiudi conferma"
                  onClick={() => setNotice('')}
                >
                  <X size={16} />
                </button>
              </output>
            )}
            {view === 'Panoramica' && (
              <>
                <section
                  className="metric-grid"
                  aria-label="Totali dell’intero archivio"
                >
                  {[
                    {
                      label: 'Olive conferite',
                      value: kg(totals.olive),
                      unit: 'kg',
                      icon: Scale,
                      detail: 'Peso netto · intero archivio',
                    },
                    {
                      label: 'Olio prodotto',
                      value: oilText(producedMl, displayUnit),
                      unit: '',
                      icon: Droplets,
                      detail:
                        'Unica produzione · densità convenzionale 0,916 kg/L',
                    },
                    {
                      label: 'Resa media',
                      value: totals.yield.toLocaleString('it-IT', {
                        maximumFractionDigits: 2,
                      }),
                      unit: '%',
                      icon: ArrowUpRight,
                      detail: 'Ponderata · equivalente kg con densità 0,916',
                    },
                    {
                      label: 'Partite da lavorare',
                      value: totals.pending,
                      unit: '',
                      icon: PackageCheck,
                      detail: 'In attesa o in molitura',
                    },
                  ].map(({ label, value, unit, icon: Icon, detail }) => (
                    <article className="metric" key={label}>
                      <div>
                        {label}
                        <Icon size={20} />
                      </div>
                      <strong>
                        {unavailable ? '—' : value} <small>{unit}</small>
                      </strong>
                      <p>{detail}</p>
                    </article>
                  ))}
                </section>
                <section className="overview-grid">
                  <div className="panel">
                    <div className="panel-title">
                      <div>
                        <h2>Il percorso delle partite</h2>
                        <p>Dall’accettazione alla restituzione</p>
                      </div>
                      <span className="tag">
                        {unavailable ? '—' : data.batches.length} partite
                      </span>
                    </div>
                    <div className="process">
                      {Object.entries(phaseLabels).map(([key, label], i) => (
                        <div key={key}>
                          <span className="step-number">0{i + 1}</span>
                          <strong>
                            {unavailable
                              ? '—'
                              : data.batches.filter((b) => phase(b) === key)
                                  .length}
                          </strong>
                          <span>
                            {label === 'Restituita' ? 'Restituite' : label}
                          </span>
                        </div>
                      ))}
                    </div>
                    <div className="panel-foot">
                      <CircleCheck size={17} />
                      {unavailable
                        ? 'Aggiornamento del quaderno…'
                        : totals.pending
                          ? totals.pending + ' partite ancora da lavorare'
                          : 'Nessuna lavorazione in sospeso'}
                    </div>
                  </div>
                  <div className="oil-summary">
                    <Droplets size={25} />
                    <p>OLIO IN GIACENZA</p>
                    <strong>
                      {unavailable
                        ? '—'
                        : oilText(bulkMl + toMl(bulkStock), displayUnit)}
                    </strong>
                    <span>Sfuso · proprio e conto terzi</span>
                    <span>
                      {unavailable ? '—' : oilText(packagedMl, displayUnit)}{' '}
                      imbottigliati
                    </span>
                    <button onClick={() => navigate('Magazzino olio')}>
                      Apri il magazzino <ArrowUpRight size={18} />
                    </button>
                  </div>
                </section>
              </>
            )}
            <section className="panel">
              <div className="panel-title">
                <div>
                  <h2>
                    {[
                      'Silos',
                      'Confezioni',
                      'Prodotti della molitura',
                      'Campagne olearie',
                    ].includes(view)
                      ? view
                      : view === 'Conferenti'
                        ? 'Anagrafica conferenti'
                        : stockView
                          ? 'Giacenze di magazzino'
                          : view === 'Depositi e contenitori'
                            ? 'I tuoi depositi'
                            : view === 'Registro operazioni'
                              ? 'Giornale delle registrazioni'
                              : view === 'Panoramica'
                                ? 'Le ultime partite'
                                : 'Quaderno delle partite'}
                  </h2>
                  <p>
                    {view === 'Conferenti'
                      ? 'Contatti e riepilogo dei conferimenti'
                      : stockView
                        ? 'Produzione, acquisto, trasferimento, imbottigliamento e vendita'
                        : view === 'Panoramica'
                          ? 'Gli ultimi 6 conferimenti in ordine di data'
                          : 'Tutte le registrazioni dell’archivio'}
                  </p>
                </div>
                <div className="panel-tools">
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Aggiorna archivio"
                    disabled={loading || busy}
                    onClick={() => void refresh()}
                  >
                    <RefreshCw
                      size={17}
                      className={loading ? 'animate-spin' : ''}
                    />
                  </Button>
                  {['Panoramica', 'Partite e molitura'].includes(view) && (
                    <Button
                      variant="outline"
                      disabled={unavailable || !rows.length}
                      onClick={() => downloadBatches(rows, stockView)}
                    >
                      <Download size={16} />
                      <span className="export-label">Esporta CSV</span>
                    </Button>
                  )}
                </div>
              </div>
              {view !== 'Panoramica' && view !== 'Campagne olearie' && (
                <div className="filters">
                  <div className="search-field">
                    <Search size={17} />
                    <Input
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder={
                        view === 'Conferenti'
                          ? 'Cerca nome, comune o telefono…'
                          : 'Cerca lotto, nome, contenitore o operazione…'
                      }
                      aria-label={
                        view === 'Conferenti'
                          ? 'Cerca conferente'
                          : 'Cerca partite'
                      }
                    />
                  </div>
                  {view === 'Partite e molitura' && (
                    <Choice
                      label="Filtra per stato"
                      value={filter}
                      onChange={setFilter}
                      options={[
                        { value: 'all', label: 'Tutti gli stati' },
                        ...Object.entries(phaseLabels).map(
                          ([value, label]) => ({
                            value,
                            label,
                          }),
                        ),
                      ]}
                    />
                  )}
                </div>
              )}
              {renderRecords()}
            </section>
            <footer className="workspace-footer">
              <span>Frantoio · Quaderno operativo</span>
              <span>
                Export SIAN intermedio · nessun invio o documento fiscale
                automatico
              </span>
            </footer>
          </div>
        </SidebarInset>
        <Dialog
          open={!!operation}
          onOpenChange={(open) => {
            if (!open && !busy) setOperation(null);
          }}
        >
          <DialogContent className="operation-dialog" showCloseButton={!busy}>
            <DialogTitle>{operation ? titles[operation.kind] : ''}</DialogTitle>
            <DialogDescription>
              {operation?.kind === 'producer.create' && operation.next
                ? 'Aggiungi il primo conferente; poi potrai registrare le sue olive.'
                : operation?.kind.startsWith('producer.')
                  ? 'Dati condivisi di conferenti, clienti, fornitori e committenti.'
                  : 'Registrazione operativa del frantoio. I campi con * sono obbligatori.'}
            </DialogDescription>
            {operation && (
              <OperationForm
                key={operation.requestId}
                operation={operation}
                data={data}
                busy={busy}
                error={formError}
                save={save}
                cancel={() => setOperation(null)}
              />
            )}
          </DialogContent>
        </Dialog>
        <BatchDetails
          batch={selectedBatch}
          deliveries={data.deliveries}
          onInventory={() => {
            setSelected(null);
            navigate('Magazzino olio');
          }}
          onClose={() => setSelected(null)}
          onOperation={open}
        />
      </SidebarProvider>
    </OilUnitContext.Provider>
  );
}
