'use client';
import { useState } from 'react';
import type { SubmitEvent } from 'react';
import type { Batch, Data, Producer } from '@/lib/domain';
import {
  kg,
  code,
  today,
  qualityLabels,
  sourceLabels,
  stockAmount,
  capacityLabel,
} from '@/lib/domain';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Field, Choice, Pick, Documents } from './form-fields';
import InventoryForm, {
  inventoryTitles,
  isInventoryOperation,
} from './inventory-form';
import type { InventoryOperationInput } from './inventory-form';
import ExtraForm, { extraTitles, isExtra } from './production-forms';
import type { ExtraOperationInput } from './production-forms';
import { useOilUnit, useOilDraft } from './oil-unit';
export { Choice } from './form-fields';

type BatchOperationInput =
  | { kind: 'producer.create'; next?: 'batch.create' }
  | { kind: 'producer.update'; producer: Producer }
  | { kind: 'batch.create'; producerId?: string }
  | {
      kind: 'batch.update' | 'batch.start' | 'batch.complete';
      batch: Batch;
    };
export type OperationInput =
  | BatchOperationInput
  | InventoryOperationInput
  | ExtraOperationInput;
export type Operation = OperationInput & { requestId: string };
export const titles = {
  ...extraTitles,
  'producer.create': 'Nuovo conferente',
  'producer.update': 'Modifica conferente',
  'batch.create': 'Nuovo conferimento',
  'batch.update': 'Modifica conferimento',
  'batch.start': 'Avvia la molitura',
  'batch.complete': 'Registra la produzione',
  ...inventoryTitles,
};
function BatchOperationForm({
  operation,
  data,
  busy,
  error,
  save,
  cancel,
}: {
  operation: BatchOperationInput & { requestId: string };
  data: Data;
  busy: boolean;
  error: string;
  save: (body: Record<string, unknown>) => Promise<void>;
  cancel: () => void;
}) {
  const producers = data.producers;
  const b = 'batch' in operation ? operation.batch : undefined;
  const p =
    operation.kind === 'producer.update' ? operation.producer : undefined;
  const [producer, setProducer] = useState(
    b?.producer_id ??
      (operation.kind === 'batch.create' ? operation.producerId : undefined) ??
      producers[0]?.id ??
      '',
  );
  const [gross, setGross] = useState(b ? String(b.gross_g / 1000) : '');
  const [tare, setTare] = useState(b ? String(b.tare_g / 1000) : '0');
  const preferred = useOilUnit().unit;
  const oilDraft = useOilDraft(preferred);
  const { value: oil, setValue: setOil, unit, changeUnit: setUnit } = oilDraft;
  const [oilQuality, setOilQuality] = useState<string>(
    b?.quality === 'unknown' ? 'normal' : (b?.quality ?? 'normal'),
  );
  const [quality, setQuality] = useState(
    b?.quality === 'unknown' ? '' : (b?.quality ?? 'normal'),
  );
  const [destination, setDestination] = useState('store');
  const availableContainers = data.containers.filter(
    (c) =>
      c.facility_id === b?.facility_id &&
      !data.stocks.some((s) => s.container_id === c.id && stockAmount(s) > 0),
  );
  const facilities = data.facilities.map((f) => ({
    value: f.id,
    label: f.name,
  }));
  const isProducer = operation.kind.startsWith('producer.');
  const isBatch = ['batch.create', 'batch.update'].includes(operation.kind);
  async function submit(event: SubmitEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const values = Object.fromEntries(new FormData(event.currentTarget));
    await save({
      ...values,
      action: operation.kind,
      requestId: operation.requestId,
      ...(b ? { id: b.id, revision: b.revision } : {}),
      ...(p ? { id: p.id } : {}),
      ...(operation.kind === 'batch.complete' && oilDraft.ml != null
        ? { oil: oilDraft.ml / 1000, volume_unit: 'L' }
        : {}),
    });
  }
  return (
    <form onSubmit={submit} className="operation-form">
      <fieldset disabled={busy}>
        {b && (
          <div className="form-context">
            <strong>{code(b)}</strong>
            <span>
              {b.producer_name} · {kg(b.net_g)} kg di olive
            </span>
          </div>
        )}
        {isProducer && (
          <>
            <Field label="Nome o ragione sociale *">
              <Input
                name="name"
                defaultValue={p?.name}
                required
                maxLength={160}
                autoComplete="organization"
                placeholder="Es. Azienda agricola Rossi"
              />
            </Field>
            <div className="form-grid">
              <Field label="Comune *">
                <Input
                  name="city"
                  defaultValue={p?.city}
                  required
                  maxLength={160}
                  autoComplete="address-level2"
                  placeholder="Es. Bitonto"
                />
              </Field>
              <Field label="Telefono">
                <Input
                  type="tel"
                  name="phone"
                  defaultValue={p?.phone}
                  maxLength={40}
                  autoComplete="tel"
                />
              </Field>
            </div>
          </>
        )}
        {isProducer && (
          <div className="form-grid">
            <Field label="Codice fiscale / P. IVA">
              <Input
                name="fiscal_id"
                defaultValue={p?.fiscal_id}
                maxLength={30}
              />
            </Field>
            <Field label="Paese (codice ISO)">
              <Input
                name="country"
                defaultValue={p?.country ?? 'IT'}
                maxLength={2}
                required
              />
            </Field>
            <Field label="Indirizzo">
              <Input name="address" defaultValue={p?.address} maxLength={200} />
            </Field>
          </div>
        )}
        {isBatch && (
          <>
            <Pick
              name="facility_id"
              label="Stabilimento di molitura"
              options={facilities}
              defaultValue={b?.facility_id ?? ''}
            />
            <Pick
              name="olive_source"
              label="Olive e lavorazione"
              defaultValue={
                b?.olive_source === 'unknown'
                  ? ''
                  : (b?.olive_source ?? 'third_party')
              }
              options={Object.entries(sourceLabels)
                .filter(([value]) => value !== 'unknown')
                .map(([value, label]) => ({ value, label }))}
            />
            <Pick
              name="quality"
              label="Tipologia olive"
              value={quality}
              onChange={setQuality}
              options={Object.entries(qualityLabels)
                .filter(([value]) => value !== 'unknown')
                .map(([value, label]) => ({ value, label }))}
            />
            {quality.includes('dop') && (
              <Field label="Denominazione D.O.P. *">
                <Input
                  name="designation"
                  defaultValue={b?.designation}
                  maxLength={160}
                  required
                />
              </Field>
            )}
            <Field label="Conferente *">
              <Choice
                name="producer_id"
                value={producer}
                onChange={setProducer}
                options={producers.map((p) => ({
                  value: p.id,
                  label: `${p.name} · ${p.city}`,
                }))}
                label="Conferente"
              />
            </Field>
            <div className="form-grid">
              <Field label="Data conferimento *">
                <Input
                  type="date"
                  name="date"
                  defaultValue={b?.date ?? today()}
                  required
                />
              </Field>
              <Field label="Cultivar *">
                <Input
                  name="variety"
                  defaultValue={b?.variety}
                  required
                  maxLength={160}
                  placeholder="Es. Coratina / mista"
                />
              </Field>
            </div>
            <Field label="Provenienza delle olive *">
              <Input
                name="origin"
                defaultValue={b?.origin}
                required
                maxLength={160}
                placeholder="Comune, contrada o appezzamento"
              />
            </Field>
            <div className="form-grid">
              <Field label="Peso lordo (kg) *">
                <Input
                  type="number"
                  inputMode="decimal"
                  name="gross"
                  value={gross}
                  onChange={(e) => setGross(e.target.value)}
                  min="0.001"
                  max="1000000"
                  step="0.001"
                  required
                />
              </Field>
              <Field label="Tara (kg) *">
                <Input
                  type="number"
                  inputMode="decimal"
                  name="tare"
                  value={tare}
                  onChange={(e) => setTare(e.target.value)}
                  min="0"
                  max="1000000"
                  step="0.001"
                  required
                />
              </Field>
            </div>
            <output className="calculation">
              Peso netto olive{' '}
              <strong>
                {kg(Math.max(0, (Number(gross) - Number(tare)) * 1000))} kg
              </strong>
            </output>
            <Documents document={b?.document} date={b?.document_date} />
            <Field label="Note">
              <textarea
                name="notes"
                defaultValue={b?.notes}
                maxLength={1200}
                rows={2}
                placeholder="Indicazioni per la lavorazione"
              />
            </Field>
          </>
        )}
        {operation.kind === 'batch.start' && (
          <p className="form-explanation">
            La partita passerà da <strong>In attesa</strong> a{' '}
            <strong>In molitura</strong>. Controlla prima il peso netto: dopo
            l’avvio non sarà più modificabile.
          </p>
        )}
        {operation.kind === 'batch.complete' && (
          <>
            <div className="form-grid">
              <Pick
                name="olive_quality"
                label="Tipologia olive lavorate"
                value={quality}
                onChange={setQuality}
                options={Object.entries(qualityLabels)
                  .filter(([v]) => v !== 'unknown')
                  .map(([value, label]) => ({ value, label }))}
              />
              <Pick
                name="oil_quality"
                label="Tipologia olio prodotto"
                value={oilQuality}
                onChange={setOilQuality}
                options={Object.entries(qualityLabels)
                  .filter(([v]) => v !== 'unknown')
                  .map(([value, label]) => ({ value, label }))}
              />
            </div>
            {quality.includes('dop') && (
              <Field label="Denominazione D.O.P. olive *">
                <Input
                  name="olive_designation"
                  defaultValue={b?.designation}
                  required
                  maxLength={160}
                />
              </Field>
            )}
            {oilQuality.includes('dop') && (
              <Field label="Denominazione D.O.P. olio *">
                <Input
                  name="oil_designation"
                  defaultValue={b?.designation}
                  required
                  maxLength={160}
                />
              </Field>
            )}
            <Pick
              name="volume_unit"
              label="Unità olio"
              value={unit}
              onChange={setUnit}
              options={[
                { value: 'kg', label: 'Chilogrammi (kg)' },
                { value: 'L', label: 'Litri (L)' },
              ]}
            />
            <div className="form-grid">
              <Field label={'Olio prodotto (' + unit + ') *'}>
                <Input
                  name="oil"
                  type="number"
                  inputMode="decimal"
                  value={oil}
                  onChange={(e) => setOil(e.target.value)}
                  min="0.001"
                  max={unit === 'kg' ? operation.batch.net_g / 1000 : 1000000}
                  step="0.001"
                  required
                />
              </Field>
              <Field label="Data produzione *">
                <Input
                  name="date"
                  type="date"
                  defaultValue={today()}
                  required
                />
              </Field>
            </div>
            <div className="form-grid">
              <Field label="Sansa prodotta (kg) *">
                <Input
                  name="pomace"
                  type="number"
                  min="0"
                  max="1000000"
                  step="0.001"
                  required
                />
              </Field>
              <Field label="Acqua di vegetazione (L) *">
                <Input
                  name="wastewater"
                  type="number"
                  min="0"
                  max="1000000"
                  step="0.001"
                  required
                />
              </Field>
            </div>
            <Pick
              name="destination"
              label="Dopo la molitura"
              value={destination}
              onChange={setDestination}
              options={[
                {
                  value: 'store',
                  label:
                    'Presa in carico in deposito · in attesa di classificazione',
                },
                ...(b?.olive_source === 'third_party'
                  ? [{ value: 'return', label: 'Ritiro immediato del cliente' }]
                  : []),
              ]}
            />
            {destination === 'store' && (
              <Pick
                name="container_id"
                label="Silos nello stabilimento di molitura"
                options={availableContainers.map((c) => ({
                  value: c.id,
                  label: c.code + ' · ' + capacityLabel(c),
                }))}
              />
            )}
            {destination === 'store' && !availableContainers.length && (
              <p role="alert" className="form-error">
                Serve un silos libero nello stabilimento di molitura. Crealo
                nella scheda “Silos”.
              </p>
            )}
            <Documents />
            <output className="calculation">
              Resa della partita{' '}
              <strong>
                {(
                  ((Number(oil) * 1000) / operation.batch.net_g) *
                  100
                ).toLocaleString('it-IT', { maximumFractionDigits: 2 })}{' '}
                {unit === 'kg' ? '% (kg/100 kg)' : 'L/100 kg'}
              </strong>
            </output>
            <p className="form-explanation">
              Olio, sansa e acqua di vegetazione sono registrati separatamente.
              La resa volumetrica in L/100 kg non è una percentuale in massa.
            </p>
          </>
        )}
        {operation.kind === 'batch.start' && (
          <Field label="Data avvio molitura *">
            <Input name="date" type="date" defaultValue={today()} required />
          </Field>
        )}
        {isBatch && !data.facilities.length && (
          <p role="alert" className="form-error">
            Prima aggiungi uno stabilimento in “Depositi e contenitori”.
          </p>
        )}
        {error && (
          <p role="alert" className="form-error">
            {error}
          </p>
        )}
        <div className="form-actions">
          <Button variant="outline" type="button" onClick={cancel}>
            Annulla
          </Button>
          <Button
            type="submit"
            className="primary-action"
            disabled={
              (isBatch && !data.facilities.length) ||
              (operation.kind === 'batch.complete' &&
                destination === 'store' &&
                !availableContainers.length)
            }
          >
            {busy
              ? 'Salvataggio…'
              : operation.kind === 'batch.start'
                ? 'Conferma avvio'
                : 'Salva registrazione'}
          </Button>
        </div>
      </fieldset>
    </form>
  );
}

type FormProps = {
  operation: Operation;
  data: Data;
  busy: boolean;
  error: string;
  save: (body: Record<string, unknown>) => Promise<void>;
  cancel: () => void;
};
export default function OperationForm(props: FormProps) {
  if (isExtra(props.operation))
    return <ExtraForm {...props} operation={props.operation} />;
  if (isInventoryOperation(props.operation))
    return <InventoryForm {...props} operation={props.operation} />;
  return <BatchOperationForm {...props} operation={props.operation} />;
}
