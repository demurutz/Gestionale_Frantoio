'use client';
import { useState } from 'react';
import type { SubmitEvent } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Field, Pick, Amount } from './form-fields';
import {
  kg,
  today,
  actionLabels,
  qualityLabels,
  categoryLabels,
  capacityLabel,
} from '@/lib/domain';
import type { Data, PackagingFormat, ArchiveEvent } from '@/lib/domain';
const scalar = (v: unknown) =>
  typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean'
    ? String(v)
    : '';
export type PackageLine = { format_id: string; units: string | number };
export function PackageLines({
  formats,
  lines,
  setLines,
}: {
  formats: PackagingFormat[];
  lines: PackageLine[];
  setLines: (rows: PackageLine[]) => void;
}) {
  const total = lines.reduce(
    (n, r) =>
      n +
      (formats.find((f) => f.id === r.format_id)?.capacity_ml ?? 0) *
        (Number(r.units) || 0),
    0,
  );
  return (
    <section className="packaging-lines">
      <h3>Confezioni riempite</h3>
      {lines.map((row, i) => (
        <div className="packaging-line" key={i}>
          <Field label={'Formato ' + (i + 1)}>
            <select
              className="native-choice"
              required
              value={row.format_id}
              onChange={(e) =>
                setLines(
                  lines.map((r, j) =>
                    j === i ? { ...r, format_id: e.target.value } : r,
                  ),
                )
              }
            >
              <option value="">Seleziona formato…</option>
              {formats
                .filter((f) => f.active || f.id === row.format_id)
                .map((f) => (
                  <option value={f.id} key={f.id}>
                    {f.name} · {kg(f.capacity_ml)} L
                  </option>
                ))}
            </select>
          </Field>
          <Field label="Pezzi">
            <Input
              type="number"
              min="1"
              max="9999999"
              step="1"
              required
              value={row.units}
              onChange={(e) =>
                setLines(
                  lines.map((r, j) =>
                    j === i ? { ...r, units: e.target.value } : r,
                  ),
                )
              }
            />
          </Field>
          <Button
            type="button"
            variant="outline"
            disabled={lines.length === 1}
            aria-label={'Rimuovi riga ' + (i + 1)}
            onClick={() => setLines(lines.filter((_, j) => j !== i))}
          >
            Rimuovi
          </Button>
        </div>
      ))}
      <Button
        type="button"
        variant="outline"
        disabled={lines.length >= 20}
        onClick={() => setLines([...lines, { format_id: '', units: '1' }])}
      >
        Aggiungi formato
      </Button>
      <output className="calculation">
        Totale confezionato<strong>{kg(total)} L</strong>
      </output>
      {!formats.some((f) => f.active) && (
        <p role="alert" className="form-error">
          Crea prima i formati nella scheda “Confezioni”.
        </p>
      )}
    </section>
  );
}
export type ExtraOperationInput =
  | { kind: 'format.create' }
  | { kind: 'format.update'; format: PackagingFormat }
  | { kind: 'operation.correct'; event: ArchiveEvent };
export const extraTitles = {
  'format.create': 'Nuova confezione',
  'format.update': 'Modifica confezione',

  'operation.correct': 'Modifica operazione registrata',
};
export function isExtra(op: {
  kind: string;
}): op is ExtraOperationInput & { requestId: string } {
  return op.kind in extraTitles;
}
type Props = {
  operation: ExtraOperationInput & { requestId: string };
  data: Data;
  busy: boolean;
  error: string;
  save: (body: Record<string, unknown>) => Promise<void>;
  cancel: () => void;
};
const labels: Record<string, string> = {
  name: 'Nome',
  city: 'Comune',
  phone: 'Telefono',
  address: 'Indirizzo',
  country: 'Paese',
  fiscal_id: 'Codice fiscale/P.IVA',
  date: 'Data operazione',
  producer_id: 'Conferente',
  facility_id: 'Stabilimento',
  container_id: 'Silos destinazione',
  stock_id: 'Giacenza di origine',
  lot_id: 'Lotto olio',
  package_id: 'Lotto confezionato',
  owner_id: 'Proprietario',
  supplier_id: 'Fornitore',
  customer_id: 'Cliente',
  gross: 'Lordo olive (kg)',
  tare: 'Tara (kg)',
  oil: 'Olio prodotto',
  amount: 'Quantità olio',
  variety: 'Cultivar',
  origin: 'Provenienza',
  olive_source: 'Olive e lavorazione',
  quality: 'Tipologia',
  designation: 'Denominazione D.O.P.',
  olive_quality: 'Tipologia olive',
  olive_designation: 'D.O.P. olive',
  oil_quality: 'Tipologia olio',
  oil_designation: 'D.O.P. olio',
  category: 'Classificazione',
  destination: 'Destinazione',
  ownership: 'Proprietà',
  source: 'Origine carico',
  format: 'Stato olio',
  label: 'Nome lotto',
  package_code: 'Codice lotto confezionamento',
  unit_ml: 'Capacità confezione (ml)',
  units: 'Numero confezioni',
  capacity: 'Capacità (kg)',
  capacity_l: 'Capacità (L)',
  code: 'Codice silos',
  notes: 'Note',
  note: 'Note movimento',
  document: 'Documento',
  document_date: 'Data documento',
  pomace: 'Sansa (kg)',
  wastewater: 'Acqua di vegetazione (L)',
  density: 'Densità (kg/L)',
  reason: 'Motivo',
  unit: 'Unità destinazione',
  sian_code: 'Identificativo SIAN',
  cuaa: 'CUAA',
};
export function CorrectionForm({
  operation,
  data,
  busy,
  error,
  save,
  cancel,
}: Props & {
  operation: Extract<Props['operation'], { kind: 'operation.correct' }>;
}) {
  const original = JSON.parse(
    JSON.parse(operation.event.payload_json).request,
  ) as Record<string, unknown>;
  const [lines, setLines] = useState<PackageLine[]>(
    Array.isArray(original.items) ? original.items : [],
  );
  const hidden = new Set([
    'requestId',
    'action',
    'revision',
    'volume_unit',
    'expected_sequence',
    'id',
    'items',
  ]);
  const options = (key: string) => {
    if (['producer_id', 'owner_id', 'supplier_id', 'customer_id'].includes(key))
      return data.producers.map((p) => ({ value: p.id, label: p.name }));
    if (key === 'facility_id')
      return data.facilities.map((f) => ({ value: f.id, label: f.name }));
    if (key === 'container_id')
      return data.containers.map((c) => ({
        value: c.id,
        label: c.code + ' · ' + capacityLabel(c),
      }));
    if (key === 'stock_id')
      return data.stocks.map((s) => ({
        value: s.id,
        label:
          (data.lots.find((l) => l.id === s.lot_id)?.label ?? s.id) +
          ' · ' +
          data.containers.find((c) => c.id === s.container_id)?.code,
      }));
    if (key === 'lot_id')
      return data.lots.map((l) => ({ value: l.id, label: l.label }));
    if (key === 'package_id')
      return data.packages.map((p) => ({ value: p.id, label: p.code }));
    const dict: Record<string, Record<string, string>> = {
      quality: qualityLabels,
      olive_quality: qualityLabels,
      oil_quality: qualityLabels,
      category: categoryLabels,
      destination: { store: 'Deposito', return: 'Ritiro immediato' },
      ownership: { own: 'Frantoio', third_party: 'Cliente' },
      source: {
        produced: 'Produzione',
        purchased: 'Acquisto',
        legacy: 'Storico',
      },
      olive_source: {
        own: 'Proprie',
        purchased: 'Acquistate',
        third_party: 'Conto terzi',
      },
      format: { bulk: 'Sfuso', packaged: 'Confezionato' },
      unit: { kg: 'kg', L: 'litri' },
    };
    return dict[key]
      ? Object.entries(dict[key])
          .filter(([k]) => k !== 'unknown')
          .map(([value, label]) => ({ value, label }))
      : null;
  };
  async function submit(e: SubmitEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;
    const fields = Object.fromEntries(new FormData(e.currentTarget)),
      reason = scalar(fields.correction_reason);
    delete fields.correction_reason;
    const replacement = {
      ...original,
      ...fields,
      ...(lines.length ? { items: lines } : {}),
      ...(typeof original.active === 'boolean'
        ? { active: fields.active === 'true' }
        : {}),
    };
    await save({
      action: 'operation.correct',
      requestId: operation.requestId,
      event_id: operation.event.id,
      expected_sequence: data.events.at(-1)?.seq ?? 0,
      reason,
      replacement,
      date: today(),
    });
  }
  return (
    <form className="operation-form" onSubmit={submit}>
      <fieldset disabled={busy}>
        <div className="form-context">
          <strong>
            #{operation.event.seq} · {actionLabels[operation.event.action]}
          </strong>
          <span>
            Unità originale: {scalar(original.volume_unit ?? 'kg')} · storico
            conservato
          </span>
        </div>
        <p className="form-explanation">
          Puoi modificare quantità, date e dati. Se una lavorazione successiva
          diventa impossibile, la rettifica non viene salvata. Per visualizzare
          kg o litri usa il selettore generale: la giacenza non cambia.
        </p>
        <div className="form-grid">
          {Object.entries(original)
            .filter(([k]) => !hidden.has(k))
            .map(([key, value]) => {
              const choices = options(key),
                numeric = [
                  'gross',
                  'tare',
                  'oil',
                  'amount',
                  'units',
                  'unit_ml',
                  'capacity',
                  'capacity_l',
                  'pomace',
                  'wastewater',
                  'density',
                ].includes(key);
              return (
                <Field
                  key={key}
                  label={
                    (labels[key] ?? key) +
                    (['oil', 'amount'].includes(key)
                      ? ' (' + scalar(original.volume_unit ?? 'kg') + ')'
                      : '')
                  }
                >
                  {choices ? (
                    <select
                      className="native-choice"
                      name={key}
                      defaultValue={String(value)}
                    >
                      {choices.map((o) => (
                        <option value={o.value} key={o.value}>
                          {o.label}
                        </option>
                      ))}
                    </select>
                  ) : typeof value === 'boolean' ? (
                    <select
                      className="native-choice"
                      name={key}
                      defaultValue={String(value)}
                    >
                      <option value="true">Attivo</option>
                      <option value="false">Disattivato</option>
                    </select>
                  ) : (
                    <Input
                      name={key}
                      defaultValue={scalar(value)}
                      type={
                        key === 'date' || key === 'document_date'
                          ? 'date'
                          : numeric
                            ? 'number'
                            : 'text'
                      }
                      step={
                        numeric
                          ? key === 'units' || key === 'unit_ml'
                            ? '1'
                            : '0.001'
                          : undefined
                      }
                      min={numeric ? '0' : undefined}
                    />
                  )}
                </Field>
              );
            })}
        </div>
        {lines.length > 0 && (
          <PackageLines
            formats={data.packagingFormats}
            lines={lines}
            setLines={setLines}
          />
        )}
        <Field label="Motivo della modifica *">
          <Input name="correction_reason" required maxLength={1200} />
        </Field>
        {error && (
          <p role="alert" className="form-error">
            {error}
          </p>
        )}
        <div className="form-actions">
          <Button type="button" variant="outline" onClick={cancel}>
            Annulla
          </Button>
          <Button type="submit">
            {busy ? 'Salvataggio…' : 'Salva rettifica'}
          </Button>
        </div>
      </fieldset>
    </form>
  );
}
export default function ExtraForm(props: Props) {
  const { operation, busy, error, save, cancel } = props;
  const f = 'format' in operation ? operation.format : undefined;
  const [active, setActive] = useState(String(f?.active ?? true));
  if (operation.kind === 'operation.correct')
    return <CorrectionForm {...props} operation={operation} />;

  async function submit(e: SubmitEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;
    await save({
      ...Object.fromEntries(new FormData(e.currentTarget)),
      action: operation.kind,
      requestId: operation.requestId,
      date: today(),
      ...(f ? { id: f.id } : {}),
      active: active === 'true',
    });
  }
  return (
    <form className="operation-form" onSubmit={submit}>
      <fieldset disabled={busy}>
        <Field label="Nome confezione *">
          <Input
            name="name"
            defaultValue={f?.name}
            required
            maxLength={100}
            placeholder="Es. Bottiglia vetro 0,75 L"
          />
        </Field>
        <Amount
          name="capacity_l"
          label="Prodotto contenuto (L)"
          max={1000}
          value={f ? f.capacity_ml / 1000 : undefined}
        />
        <Pick
          name="active"
          label="Disponibilità"
          value={active}
          onChange={setActive}
          options={[
            { value: 'true', label: 'Disponibile' },
            { value: 'false', label: 'Disattivata' },
          ]}
        />

        {error && (
          <p role="alert" className="form-error">
            {error}
          </p>
        )}
        <div className="form-actions">
          <Button type="button" variant="outline" onClick={cancel}>
            Annulla
          </Button>
          <Button type="submit">{busy ? 'Salvataggio…' : 'Salva'}</Button>
        </div>
      </fieldset>
    </form>
  );
}
