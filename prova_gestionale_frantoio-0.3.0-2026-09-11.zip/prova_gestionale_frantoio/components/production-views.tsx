'use client';
import { useState } from 'react';
import { Button } from './ui/button';
import {
  Table,
  TableHeader,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from './ui/table';
import {
  kg,
  stockAmount,
  qualityLabels,
  categoryLabels,
  code,
  today,
} from '@/lib/domain';
import type { Data } from '@/lib/domain';
import type { OperationInput } from './operation-form';
import { fillLevel } from '@/lib/production';
import { useOilUnit } from './oil-unit';
import { toMl, toGrams } from '@/lib/quantity';
import {
  campaignYear,
  campaignLabel,
  campaignYears,
  campaignStats,
} from '@/lib/campaigns';
type Props = {
  data: Data;
  query: string;
  onOperation: (op: OperationInput) => void;
  canManage: boolean;
};
export function Silos({ data, query, onOperation, canManage }: Props) {
  const [facility, setFacility] = useState('all');
  const { formatOil } = useOilUnit();
  const visible = data.containers.filter(
    (c) =>
      (facility === 'all' || c.facility_id === facility) &&
      (c.code + ' ' + data.facilities.find((f) => f.id === c.facility_id)?.name)
        .toLowerCase()
        .includes(query),
  );
  return (
    <div>
      <div className="inventory-toolbar">
        <select
          className="native-choice"
          aria-label="Filtra stabilimento"
          value={facility}
          onChange={(e) => setFacility(e.target.value)}
        >
          <option value="all">Tutti gli stabilimenti</option>
          {data.facilities.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          ))}
        </select>
        {canManage && (
          <Button
            disabled={!data.facilities.length}
            onClick={() => onOperation({ kind: 'container.create' })}
          >
            Nuovo silos
          </Button>
        )}
      </div>
      <p className="silo-legend">
        <span data-level="high">Oltre 50%</span>
        <span data-level="medium">10–50%</span>
        <span data-level="low">Sotto 10%</span>
        <span data-level="empty">Vuoto</span>
      </p>
      <div className="silo-grid">
        {visible.map((c) => {
          const stocks = data.stocks.filter(
            (s) => s.container_id === c.id && stockAmount(s) > 0,
          );
          const amount = stocks.reduce((n, s) => n + stockAmount(s), 0),
            capacity = c.capacity_ml ?? c.capacity_g;
          const { percent, state } = fillLevel(amount, capacity);
          const clip = 'silo-' + c.id.replace(/[^a-zA-Z0-9-]/g, '');
          return (
            <article className="silo-card" data-level={state} key={c.id}>
              <h3>{c.code}</h3>
              <p>{data.facilities.find((f) => f.id === c.facility_id)?.name}</p>
              <svg
                className="silo-gauge"
                viewBox="0 0 120 160"
                aria-label={
                  c.code +
                  ': ' +
                  percent.toLocaleString('it-IT', {
                    maximumFractionDigits: 1,
                  }) +
                  '% pieno'
                }
              >
                <defs>
                  <clipPath id={clip}>
                    <rect x="15" y="20" width="90" height="120" rx="20" />
                  </clipPath>
                </defs>
                <rect
                  className="silo-shell"
                  x="15"
                  y="20"
                  width="90"
                  height="120"
                  rx="20"
                />
                <rect
                  className="silo-liquid"
                  x="15"
                  y={140 - Math.min(percent, 100) * 1.2}
                  width="90"
                  height={Math.min(percent, 100) * 1.2}
                  clipPath={'url(#' + clip + ')'}
                />
                <path
                  className="silo-outline"
                  d="M15 40h90M15 120h90M32 140v12M88 140v12"
                />
                <text x="60" y="87" textAnchor="middle">
                  {percent.toLocaleString('it-IT', {
                    maximumFractionDigits: 1,
                  })}
                  %
                </text>
              </svg>
              <strong>
                {formatOil(amount)} / {formatOil(capacity)}
              </strong>
              <small>
                {amount === 0
                  ? 'Vuoto'
                  : 'Disponibili ' + formatOil(capacity - amount)}
              </small>
              {stocks.map((s) => {
                const lot = data.lots.find((l) => l.id === s.lot_id)!;
                return (
                  <p key={s.id}>
                    {lot.label}
                    <small>
                      {categoryLabels[lot.category]} ·{' '}
                      {qualityLabels[lot.quality]}
                    </small>
                    <small>{formatOil(stockAmount(s))}</small>
                  </p>
                );
              })}
            </article>
          );
        })}
      </div>
      {!visible.length && (
        <p className="inventory-empty">
          Nessun silos censito per questo filtro. Aggiungi prima lo stabilimento
          in “Depositi e contenitori”.
        </p>
      )}
    </div>
  );
}
export function PackagingCatalog({
  data,
  query,
  onOperation,
  canManage,
}: Props) {
  const formats = data.packagingFormats.filter((f) =>
    f.name.toLowerCase().includes(query),
  );
  return (
    <div>
      {canManage && (
        <Button onClick={() => onOperation({ kind: 'format.create' })}>
          Nuova confezione
        </Button>
      )}
      <p className="inventory-footnote">
        Bottiglie, latte e taniche disponibili come formati di confezionamento.
        Le modifiche al catalogo non cambiano le confezioni già prodotte.
      </p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Capacità</TableHead>
            <TableHead>Stato</TableHead>
            <TableHead>Azioni</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {formats.map((f) => (
            <TableRow key={f.id}>
              <TableCell>
                <strong>{f.name}</strong>
              </TableCell>
              <TableCell>{kg(f.capacity_ml)} L</TableCell>
              <TableCell>{f.active ? 'Disponibile' : 'Disattivata'}</TableCell>
              <TableCell>
                {canManage && (
                  <Button
                    variant="outline"
                    onClick={() =>
                      onOperation({ kind: 'format.update', format: f })
                    }
                  >
                    Modifica
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {!formats.length && (
        <p className="inventory-empty">
          Crea i formati da selezionare durante l’imbottigliamento.
        </p>
      )}
    </div>
  );
}
export function Byproducts({ data, query }: { data: Data; query: string }) {
  const { formatOil } = useOilUnit();
  const batches = data.batches.filter(
    (b) =>
      b.status === 'done' &&
      (code(b) + ' ' + b.producer_name).toLowerCase().includes(query),
  );
  return (
    <>
      <p className="inventory-footnote">
        Quantità prodotte, non giacenze residue di sansa/acqua. Il trattino
        indica un dato non registrato, non zero.
      </p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Partita</TableHead>
            <TableHead>Data produzione</TableHead>
            <TableHead>Olio</TableHead>
            <TableHead>Sansa</TableHead>
            <TableHead>Acqua di vegetazione</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {batches.map((b) => (
            <TableRow key={b.id}>
              <TableCell>
                {code(b)}
                <small className="cell-note">{b.producer_name}</small>
              </TableCell>
              <TableCell>{b.production_date || 'Non disponibile'}</TableCell>
              <TableCell>{formatOil(b.oil_ml ?? toMl(b.oil_g))}</TableCell>
              <TableCell>
                {b.pomace_g == null ? '—' : kg(b.pomace_g) + ' kg'}
              </TableCell>
              <TableCell>
                {b.wastewater_ml == null ? '—' : kg(b.wastewater_ml) + ' L'}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {!batches.length && (
        <p className="inventory-empty">Nessuna molitura completata.</p>
      )}
    </>
  );
}
export function Campaigns({ data }: { data: Data }) {
  const { unit } = useOilUnit();
  const oil = (ml: number) => (unit === 'kg' ? toGrams(ml) : ml) / 1000;
  const years = campaignYears(data),
    current = campaignYear(today());
  const [first, setFirst] = useState(current),
    [second, setSecond] = useState(current - 1);
  const a = campaignStats(data, first),
    b = campaignStats(data, second);
  const metrics: [string, number | null, number | null, string][] = [
    ['Olive conferite', a.olive_g / 1000, b.olive_g / 1000, 'kg'],
    ['Olive molite', a.milled_g / 1000, b.milled_g / 1000, 'kg'],
    ['Olio prodotto', oil(a.oil_ml), oil(b.oil_ml), unit],
    [
      'Resa ponderata',
      unit === 'kg' ? a.mass_yield : a.volume_yield,
      unit === 'kg' ? b.mass_yield : b.volume_yield,
      unit + '/100 kg',
    ],
    ['Sansa registrata', a.pomace_g / 1000, b.pomace_g / 1000, 'kg'],
    ['Acqua vegetazione registrata', a.water_ml / 1000, b.water_ml / 1000, 'L'],
    ['Olio imbottigliato', oil(a.bottled_ml), oil(b.bottled_ml), unit],
    ['Olio venduto', oil(a.sold_ml), oil(b.sold_ml), unit],
    ['Moliture completate', a.count, b.count, ''],
  ];
  const fmt = (x: number | null) =>
    x == null ? '—' : x.toLocaleString('it-IT', { maximumFractionDigits: 3 });
  const options = years.map((y) => (
    <option key={y} value={y}>
      {campaignLabel(y)}
      {y === current ? ' · in corso' : y > current ? ' · futura' : ''}
    </option>
  ));
  return (
    <div>
      <div className="inventory-toolbar">
        <label className="campaign-choice">
          Campagna da analizzare
          <select
            className="native-choice"
            value={first}
            onChange={(e) => setFirst(Number(e.target.value))}
          >
            {options}
          </select>
        </label>
        <label className="campaign-choice">
          Campagna di confronto
          <select
            className="native-choice"
            value={second}
            onChange={(e) => setSecond(Number(e.target.value))}
          >
            {options}
          </select>
        </label>
      </div>
      <p className="inventory-footnote">
        Dal 1 agosto al 31 luglio, in base alle date operative. La campagna in
        corso è parziale.
      </p>
      <div className="campaign-chart" aria-label="Confronto olive molite">
        {[a, b].map((s, i) => (
          <div key={i}>
            <span>{s.label}</span>
            <div className="campaign-track">
              <div
                style={{
                  width:
                    (Math.max(a.milled_g, b.milled_g)
                      ? (s.milled_g / Math.max(a.milled_g, b.milled_g)) * 100
                      : 0) + '%',
                }}
              />
            </div>
            <strong>{kg(s.milled_g)} kg olive</strong>
          </div>
        ))}
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Indicatore</TableHead>
            <TableHead>{a.label}</TableHead>
            <TableHead>{b.label}</TableHead>
            <TableHead>Differenza</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {metrics.map(([label, x, y, u]) => (
            <TableRow key={label}>
              <TableCell>{label}</TableCell>
              <TableCell>
                {fmt(x)} {u}
              </TableCell>
              <TableCell>
                {fmt(y)} {u}
              </TableCell>
              <TableCell>
                {x == null || y == null || y === 0
                  ? '—'
                  : fmt(((x - y) / y) * 100) + '%'}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <p className="inventory-footnote">
        Produzione unica memorizzata in litri; i kg sono l’equivalente
        convenzionale a 0,916 kg/L. La resa usa tutte le olive molite. Acquisti
        e carichi iniziali non aumentano la produzione. Sansa/acqua mancanti:{' '}
        {a.missing} / {b.missing} moliture nelle due campagne.
      </p>
      {data.batches.some((b) => b.status === 'done' && !b.production_date) && (
        <p className="inventory-notice">
          Le moliture storiche prive di una data di produzione certa sono
          escluse dal confronto della produzione.
        </p>
      )}
    </div>
  );
}
