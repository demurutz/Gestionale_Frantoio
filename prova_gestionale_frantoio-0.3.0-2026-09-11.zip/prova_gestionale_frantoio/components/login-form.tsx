'use client';
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
export default function LoginForm() {
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  return (
    <form
      className="auth-card"
      onSubmit={async (event) => {
        event.preventDefault();
        if (busy) return;
        setBusy(true);
        setError('');
        const data = new FormData(event.currentTarget);
        try {
          const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: data.get('email'),
              password: data.get('password'),
            }),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error);
          window.location.assign('/');
        } catch (error) {
          setError(
            error instanceof Error
              ? error.message
              : 'Connessione non disponibile.',
          );
          setBusy(false);
        }
      }}
    >
      <p className="eyebrow">FRANTOIO · QUADERNO OPERATIVO</p>
      <h1>Accedi al tuo frantoio</h1>
      <p>Usa le credenziali assegnate dall’amministratore.</p>
      <label htmlFor="login-form-1">
        Email
        <Input
          id="login-form-1"
          name="email"
          type="email"
          autoComplete="username"
          required
          maxLength={254}
        />
      </label>
      <label htmlFor="login-form-2">
        Password
        <Input
          id="login-form-2"
          name="password"
          type="password"
          autoComplete="current-password"
          required
          maxLength={128}
        />
      </label>
      {error && (
        <p role="alert" className="message error">
          {error}
        </p>
      )}
      <Button type="submit" disabled={busy} className="primary-action">
        {busy ? 'Accesso in corso…' : 'Accedi'}
      </Button>
    </form>
  );
}
