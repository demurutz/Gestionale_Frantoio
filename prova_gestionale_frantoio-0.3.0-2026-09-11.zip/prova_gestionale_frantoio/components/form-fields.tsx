'use client';
import type { ReactNode } from 'react';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}
export function Choice({
  name,
  value,
  onChange,
  options,
  label,
}: {
  name?: string;
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  label: string;
}) {
  return (
    <Select
      name={name}
      value={value}
      onValueChange={(v) => onChange(v ?? '')}
      items={options}
    >
      <SelectTrigger className="choice" aria-label={label}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value}>
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
// Native fields keep the small operational forms accessible and serializable.
export function Pick({
  name,
  label,
  options,
  value,
  onChange,
  defaultValue,
}: {
  name: string;
  label: string;
  options: { value: string; label: string }[];
  value?: string;
  onChange?: (value: string) => void;
  defaultValue?: string;
}) {
  return (
    <Field label={label + ' *'}>
      <select
        className="native-choice"
        name={name}
        required
        value={value}
        defaultValue={defaultValue ?? (value === undefined ? '' : undefined)}
        onChange={(e) => onChange?.(e.target.value)}
      >
        <option value="" disabled>
          Seleziona…
        </option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </Field>
  );
}
export function Documents({
  required = false,
  document = '',
  date = '',
}: {
  required?: boolean;
  document?: string;
  date?: string;
}) {
  return (
    <div className="form-grid">
      <Field label={'Documento / riferimento' + (required ? ' *' : '')}>
        <Input
          name="document"
          defaultValue={document}
          required={required}
          maxLength={160}
          placeholder="Numero DDT, analisi o altro riferimento"
        />
      </Field>
      <Field label={'Data documento' + (required ? ' *' : '')}>
        <Input
          name="document_date"
          type="date"
          defaultValue={date}
          required={required}
        />
      </Field>
    </div>
  );
}
export function Amount({
  label = 'Quantità (kg)',
  value,
  max,
  name = 'amount',
  onChange,
}: {
  label?: string;
  value?: number | string;
  max?: number;
  name?: string;
  onChange?: (value: string) => void;
}) {
  return (
    <Field label={label + ' *'}>
      <Input
        name={name}
        type="number"
        inputMode="decimal"
        min="0.001"
        max={max ?? 1000000}
        step="0.001"
        defaultValue={onChange ? undefined : value}
        value={onChange ? value : undefined}
        onChange={onChange ? (e) => onChange(e.target.value) : undefined}
        required
      />
    </Field>
  );
}
