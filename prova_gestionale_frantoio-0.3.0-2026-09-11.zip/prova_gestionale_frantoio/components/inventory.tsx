'use client';
import { useState } from 'react';
import { Button } from './ui/button';
import {
  Table,
  TableHeader,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from './ui/table';
import type { OperationInput } from './operation-form';
import type { Data, OilLot } from '@/lib/domain';
import {
  kg,
  code,
  qualityLabels,
  categoryLabels,
  actionLabels,
  stockAmount,
} from '@/lib/domain';
import { effectiveEvents } from '@/lib/production';
import { useOilUnit } from './oil-unit';
import { toMl } from '@/lib/quantity';
import { exportWarnings, sianSources } from '@/lib/export';
type Props = {
  data: Data;
  query: string;
  onOperation: (operation: OperationInput) => void;
};
function owner(data: Data, lot: OilLot) {
  return lot.ownership === 'own'
    ? 'Frantoio · conto proprio'
    : (data.producers.find((p) => p.id === lot.owner_id)?.name ?? 'Cliente') +
        ' · conto terzi';
}
function lotDescription(data: Data, lot: OilLot) {
  return [
    lot.label,
    owner(data, lot),
    lot.origin,
    lot.designation,
    qualityLabels[lot.quality],
    categoryLabels[lot.category],
    lot.source === 'purchased'
      ? 'Acquistato'
      : lot.source === 'legacy'
        ? 'Preesistente'
        : 'Produzione interna',
  ].join(' · ');
}
function matches(text: string, query: string) {
  return text.toLocaleLowerCase('it-IT').includes(query);
}
function Blank({ children }: { children: React.ReactNode }) {
  return <p className="inventory-empty">{children}</p>;
}

export function Inventory({ data, query, onOperation }: Props) {
  const { formatOil } = useOilUnit();
  const [tab, setTab] = useState('bulk');
  const [facility, setFacility] = useState('all');
  const [ownership, setOwnership] = useState('all');
  const legacy = data.batches.filter(
    (b) =>
      b.status === 'done' &&
      b.oil_g > b.returned_g &&
      !data.lots.some((l) => l.batch_id === b.id),
  );
  const stocks = data.stocks
    .filter((s) => stockAmount(s) > 0)
    .filter((s) => {
      const lot = data.lots.find((l) => l.id === s.lot_id)!;
      const container = data.containers.find((c) => c.id === s.container_id)!;
      return (
        (ownership === 'all' || lot.ownership === ownership) &&
        (facility === 'all' || container.facility_id === facility) &&
        matches(lotDescription(data, lot) + ' ' + container.code, query)
      );
    });
  const packages = data.packages
    .filter((p) => p.units > 0)
    .filter((p) => {
      const lot = data.lots.find((l) => l.id === p.lot_id)!;
      return (
        (ownership === 'all' || lot.ownership === ownership) &&
        (facility === 'all' || p.facility_id === facility) &&
        matches(lotDescription(data, lot) + ' ' + p.code, query)
      );
    });
  const bulk = stocks
    .filter((s) => s.amount_ml == null)
    .reduce((n, s) => n + s.amount_g, 0);
  const bulkMl = stocks.reduce((n, s) => n + (s.amount_ml ?? 0), 0);
  const bottled = packages.reduce((n, p) => n + p.units * p.unit_ml, 0);
  return (
    <>
      <div className="inventory-toolbar">
        <div className="inventory-tabs" aria-label="Stato olio">
          <Button
            variant={tab === 'bulk' ? 'default' : 'outline'}
            aria-pressed={tab === 'bulk'}
            onClick={() => setTab('bulk')}
          >
            Sfuso · {formatOil(bulkMl + toMl(bulk))}
          </Button>
          <Button
            variant={tab === 'packaged' ? 'default' : 'outline'}
            aria-pressed={tab === 'packaged'}
            onClick={() => setTab('packaged')}
          >
            Imbottigliato · {formatOil(bottled)}
          </Button>
        </div>
        <select
          aria-label="Filtra stabilimento"
          className="native-choice"
          value={facility}
          onChange={(e) => setFacility(e.target.value)}
        >
          <option value="all">Tutti gli stabilimenti</option>
          {data.facilities.map((f) => (
            <option key={f.id} value={f.id}>
              {f.name}
            </option>
          ))}
        </select>
        <select
          aria-label="Filtra proprietà"
          className="native-choice"
          value={ownership}
          onChange={(e) => setOwnership(e.target.value)}
        >
          <option value="all">Tutte le proprietà</option>
          <option value="own">Olio proprio</option>
          <option value="third_party">Conto terzi</option>
        </select>
      </div>
      {legacy.length > 0 && (
        <div className="inventory-notice">
          <strong>Giacenze precedenti da integrare</strong>
          <p>
            Queste quantità restano conservate, ma non sono ancora assegnate ai
            contenitori del nuovo magazzino.
          </p>
          {legacy.map((batch) => (
            <div className="inventory-line" key={batch.id}>
              <span>
                {code(batch)} · {batch.producer_name} ·{' '}
                {kg(batch.oil_g - batch.returned_g)} kg
              </span>
              <Button
                variant="outline"
                onClick={() => onOperation({ kind: 'oil.adopt', batch })}
              >
                Integra giacenza
              </Button>
            </div>
          ))}
        </div>
      )}
      {tab === 'bulk' ? (
        stocks.length ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Lotto / proprietà</TableHead>
                <TableHead>Olio</TableHead>
                <TableHead>Deposito / contenitore</TableHead>
                <TableHead>Giacenza</TableHead>
                <TableHead>Operazioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stocks.map((stock) => {
                const lot = data.lots.find((l) => l.id === stock.lot_id)!;
                const container = data.containers.find(
                  (c) => c.id === stock.container_id,
                )!;
                const facility = data.facilities.find(
                  (f) => f.id === container.facility_id,
                )!;
                return (
                  <TableRow key={stock.id}>
                    <TableCell>
                      <strong>{lot.label}</strong>
                      <small className="cell-note">{owner(data, lot)}</small>
                      <small className="cell-note">
                        {lot.source === 'purchased'
                          ? 'Acquistato'
                          : lot.source === 'legacy'
                            ? 'Giacenza preesistente'
                            : 'Produzione interna'}
                      </small>
                    </TableCell>
                    <TableCell>
                      {categoryLabels[lot.category]}
                      <small className="cell-note">
                        {qualityLabels[lot.quality]} {lot.designation} ·{' '}
                        {lot.origin}
                      </small>
                    </TableCell>
                    <TableCell>
                      {facility.name}
                      <small className="cell-note">{container.code}</small>
                    </TableCell>
                    <TableCell className="numeric">
                      <strong>
                        {formatOil(stock.amount_ml ?? toMl(stock.amount_g))}
                      </strong>
                    </TableCell>
                    <TableCell>
                      <div className="inventory-actions">
                        {lot.category === 'pending' && (
                          <Button
                            variant="outline"
                            onClick={() =>
                              onOperation({ kind: 'oil.classify', lot })
                            }
                          >
                            Classifica
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          onClick={() =>
                            onOperation({ kind: 'oil.transfer', stock })
                          }
                        >
                          Sposta
                        </Button>
                        {['extra', 'virgin'].includes(lot.category) && (
                          <Button
                            variant="outline"
                            onClick={() =>
                              onOperation({ kind: 'oil.bottle', stock })
                            }
                          >
                            Imbottiglia
                          </Button>
                        )}
                        {lot.ownership === 'third_party' && (
                          <Button
                            onClick={() =>
                              onOperation({ kind: 'oil.return', stock })
                            }
                          >
                            Ritiro cliente
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        ) : (
          <Blank>
            Nessun olio sfuso corrispondente. Carica un acquisto, una giacenza
            iniziale o completa una molitura.
          </Blank>
        )
      ) : packages.length ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Lotto confezionamento</TableHead>
              <TableHead>Olio / proprietà</TableHead>
              <TableHead>Deposito</TableHead>
              <TableHead>Disponibilità</TableHead>
              <TableHead>Operazioni</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {packages.map((pack) => {
              const lot = data.lots.find((l) => l.id === pack.lot_id)!;
              return (
                <TableRow key={pack.id}>
                  <TableCell>
                    <strong>{pack.code}</strong>
                    <small className="cell-note">{pack.format_name}</small>
                    <small className="cell-note">
                      Olio {lot.label} · {pack.date}
                    </small>
                  </TableCell>
                  <TableCell>
                    {categoryLabels[lot.category]} ·{' '}
                    {qualityLabels[lot.quality]}
                    <small className="cell-note">{owner(data, lot)}</small>
                  </TableCell>
                  <TableCell>
                    {
                      data.facilities.find((f) => f.id === pack.facility_id)
                        ?.name
                    }
                  </TableCell>
                  <TableCell className="numeric">
                    <strong>
                      {pack.units} × {pack.unit_ml} ml
                    </strong>
                    <small className="cell-note">
                      {formatOil(pack.units * pack.unit_ml)}
                    </small>
                  </TableCell>
                  <TableCell>
                    <Button
                      onClick={() =>
                        onOperation({
                          kind:
                            lot.ownership === 'own'
                              ? 'package.sell'
                              : 'package.return',
                          pack,
                        })
                      }
                    >
                      {lot.ownership === 'own' ? 'Vendi' : 'Ritiro cliente'}
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      ) : (
        <Blank>
          Nessun olio imbottigliato corrispondente. Imbottiglia un lotto sfuso
          classificato o carica confezioni già disponibili.
        </Blank>
      )}
      <p className="inventory-footnote">
        Totali riferiti ai filtri selezionati. Un’unica giacenza in litri; i kg
        sono calcolati con densità 0,916 kg/L. La classificazione è distinta
        dalla tipologia normale, D.O.P. o biologica.
      </p>
    </>
  );
}

export function Deposits({ data, query, onOperation }: Props) {
  const { formatOil } = useOilUnit();
  return (
    <div className="deposits-list">
      <div className="inventory-actions">
        <Button
          onClick={() => onOperation({ kind: 'container.create' })}
          disabled={!data.facilities.length}
        >
          Nuovo contenitore
        </Button>
        <Button
          variant="outline"
          onClick={() => onOperation({ kind: 'facility.create' })}
        >
          Nuovo stabilimento
        </Button>
      </div>
      {!data.facilities.length && (
        <Blank>
          Aggiungi il primo stabilimento, poi censisci i suoi contenitori con
          codice e capacità in litri o kg.
        </Blank>
      )}
      {data.facilities.map((facility) => {
        const containers = data.containers.filter(
          (c) =>
            c.facility_id === facility.id &&
            matches(c.code + ' ' + facility.name, query),
        );
        const packaged = data.packages
          .filter((p) => p.facility_id === facility.id)
          .reduce((n, p) => n + p.units * p.unit_ml, 0);
        if (query && !containers.length && !matches(facility.name, query))
          return null;
        return (
          <section className="deposit" key={facility.id}>
            <div className="inventory-line">
              <div>
                <h3>{facility.name}</h3>
                <p>
                  {facility.address || 'Indirizzo da completare'} · SIAN{' '}
                  {facility.sian_code || 'da completare'}
                </p>
                <p>Imbottigliato in deposito: {formatOil(packaged)}</p>
              </div>
              <Button
                variant="outline"
                onClick={() =>
                  onOperation({ kind: 'facility.update', facility })
                }
              >
                Modifica dati
              </Button>
            </div>
            <div className="container-grid">
              {containers.map((container) => {
                const stocks = data.stocks.filter(
                  (s) => s.container_id === container.id && stockAmount(s) > 0,
                );
                const amount = stocks.reduce((n, s) => n + stockAmount(s), 0);
                return (
                  <article className="container-card" key={container.id}>
                    <div className="inventory-line">
                      <strong>{container.code}</strong>
                      <span>{amount ? 'In uso' : 'Vuoto'}</span>
                    </div>
                    <p>
                      <strong>{formatOil(amount)}</strong> /{' '}
                      {formatOil(
                        container.capacity_ml ?? toMl(container.capacity_g),
                      )}
                    </p>
                    <progress
                      aria-label={'Riempimento ' + container.code}
                      max={container.capacity_ml ?? container.capacity_g}
                      value={amount}
                    />
                    {stocks.map((s) => {
                      const lot = data.lots.find((l) => l.id === s.lot_id)!;
                      return (
                        <p key={s.id}>
                          {lot.label} · {categoryLabels[lot.category]}
                          <small className="cell-note">
                            {qualityLabels[lot.quality]} {lot.designation} ·{' '}
                            {owner(data, lot)}
                          </small>
                        </p>
                      );
                    })}
                  </article>
                );
              })}
            </div>
            {!containers.length && (
              <p className="muted-copy">
                Nessun contenitore {query ? 'corrispondente' : 'censito'}.
              </p>
            )}
          </section>
        );
      })}
    </div>
  );
}

export function Journal({
  data,
  query,
  companyId,
  onOperation,
  canEdit,
}: {
  data: Data;
  query: string;
  companyId: string;
  onOperation: (operation: OperationInput) => void;
  canEdit: boolean;
}) {
  const { formatOil } = useOilUnit();
  const [exportError, setExportError] = useState('');
  const [exporting, setExporting] = useState(false);
  const warnings = exportWarnings(data);
  const effective = new Map(effectiveEvents(data.events).map((e) => [e.id, e]));
  async function download() {
    setExporting(true);
    setExportError('');
    try {
      const response = await fetch('/api/frantoio/export', {
        cache: 'no-store',
        headers: { 'X-Company-Id': companyId },
      });
      if (!response.ok)
        throw new Error(
          'Esportazione non riuscita. Riprova: nessun file parziale è stato scaricato.',
        );
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download =
        'frantoio-registro-' + new Date().toISOString().slice(0, 10) + '.json';
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (error) {
      setExportError(
        error instanceof Error
          ? error.message
          : 'Errore durante l’esportazione.',
      );
    } finally {
      setExporting(false);
    }
  }
  const events = [...data.events]
    .reverse()
    .filter((e) =>
      matches(
        [e.date, actionLabels[e.action] ?? e.action, e.payload_json].join(' '),
        query,
      ),
    );
  return (
    <>
      <div className="inventory-notice">
        <div className="inventory-line">
          <div>
            <h3>Registro completo · formato intermedio SIAN</h3>
            <p>
              Il JSON conserva tutte le informazioni e lo storico, anche fuori
              dai filtri. Non è un file pronto per l’upload SIAN e non viene
              trasmesso automaticamente.
            </p>
          </div>
          <Button onClick={() => void download()} disabled={exporting}>
            {exporting ? 'Preparazione…' : 'Esporta registro JSON'}
          </Button>
        </div>
        <details>
          <summary>
            Verifiche prima della conversione ({warnings.length})
          </summary>
          <ul>
            {warnings.map((warning, i) => (
              <li key={i}>{warning}</li>
            ))}
          </ul>
          <p>
            Specifiche consultate:{' '}
            {sianSources.map((source, i) => (
              <span key={source.url}>
                {i ? ' · ' : ''}
                <a href={source.url} target="_blank" rel="noreferrer">
                  {source.title}
                </a>
              </span>
            ))}
          </p>
        </details>
        {exportError && (
          <p role="alert" className="form-error">
            {exportError}
          </p>
        )}
      </div>
      {events.length ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>N. / data</TableHead>
              <TableHead>Operazione</TableHead>
              <TableHead>Lotto / quantità</TableHead>
              <TableHead>Documento / percorso</TableHead>
              <TableHead>Dettagli</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {events.map((event) => {
              const payload = JSON.parse(event.payload_json);
              const { request: _request, ...detail } = payload;
              return (
                <TableRow key={event.id}>
                  <TableCell>
                    #{event.seq}
                    <small className="cell-note">{event.date}</small>
                  </TableCell>
                  <TableCell>
                    {actionLabels[event.action] ?? event.action}
                    {payload.corrected_event_id && (
                      <small className="cell-note">{payload.reason}</small>
                    )}
                  </TableCell>
                  <TableCell>
                    {payload.lot?.label ??
                      (payload.batch ? code(payload.batch) : '—')}
                    <small className="cell-note">
                      {payload.oil_ml != null || payload.oil_g
                        ? formatOil(payload.oil_ml ?? toMl(payload.oil_g)) +
                          ' olio'
                        : payload.olive_g
                          ? kg(payload.olive_g) + ' kg olive'
                          : ''}
                      {payload.packaged_ml
                        ? ' · ' +
                          payload.units +
                          ' confezioni / ' +
                          formatOil(payload.packaged_ml)
                        : ''}
                    </small>
                  </TableCell>
                  <TableCell>
                    {payload.document || '—'}
                    <small className="cell-note">
                      {payload.source_container?.code ??
                        payload.source_facility?.name ??
                        ''}
                      {payload.destination_container
                        ? ' → ' + payload.destination_container.code
                        : payload.destination_facility
                          ? ' → ' + payload.destination_facility.name
                          : ''}
                    </small>
                  </TableCell>
                  <TableCell>
                    <details className="event-details">
                      <summary>Apri</summary>
                      <pre>{JSON.stringify(detail, null, 2)}</pre>
                    </details>
                    {canEdit && event.action !== 'operation.correct' && (
                      <Button
                        variant="outline"
                        onClick={() =>
                          onOperation({
                            kind: 'operation.correct',
                            event: effective.get(event.id) ?? event,
                          })
                        }
                      >
                        Modifica
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      ) : (
        <Blank>
          Nessuna operazione nello storico per questa ricerca. Le registrazioni
          precedenti all’aggiornamento restano nell’archivio e
          nell’esportazione.
        </Blank>
      )}
    </>
  );
}
