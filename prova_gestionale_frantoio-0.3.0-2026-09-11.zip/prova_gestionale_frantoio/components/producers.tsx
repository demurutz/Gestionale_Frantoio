import { Pencil, Plus, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Empty } from '@/components/ui/empty';
import {
  Table,
  TableHeader,
  TableHead,
  TableRow,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import { kg } from '@/lib/domain';
import type { Batch, Producer } from '@/lib/domain';

export default function Producers({
  producers,
  batches,
  query,
  onCreate,
  onEdit,
}: {
  producers: Producer[];
  batches: Batch[];
  query: string;
  onCreate: () => void;
  onEdit: (producer: Producer) => void;
}) {
  if (!producers.length)
    return (
      <Empty className="empty-state">
        <Users size={30} />
        <h3>
          {query ? 'Nessun conferente trovato' : 'Conosciamo i tuoi conferenti'}
        </h3>
        <p>
          {query
            ? 'Prova con un nome o un comune diverso.'
            : 'Aggiungi il primo conferente per iniziare a registrare le olive.'}
        </p>
        {!query && (
          <Button onClick={onCreate}>
            <Plus size={17} /> Nuovo conferente
          </Button>
        )}
      </Empty>
    );

  const totals = new Map<string, { count: number; grams: number }>();
  for (const batch of batches) {
    const total = totals.get(batch.producer_id) ?? { count: 0, grams: 0 };
    total.count += 1;
    total.grams += batch.net_g;
    totals.set(batch.producer_id, total);
  }
  return (
    <Table className="records-table">
      <TableHeader>
        <TableRow>
          <TableHead>Conferente</TableHead>
          <TableHead>Comune</TableHead>
          <TableHead>Telefono</TableHead>
          <TableHead>Partite</TableHead>
          <TableHead>Olive conferite</TableHead>
          <TableHead>
            <span className="sr-only">Azioni</span>
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {producers.map((producer) => (
          <TableRow key={producer.id}>
            <TableCell>
              <strong>{producer.name}</strong>
            </TableCell>
            <TableCell>{producer.city}</TableCell>
            <TableCell>{producer.phone || '—'}</TableCell>
            <TableCell>{totals.get(producer.id)?.count ?? 0}</TableCell>
            <TableCell>{kg(totals.get(producer.id)?.grams ?? 0)} kg</TableCell>
            <TableCell>
              <Button
                variant="ghost"
                aria-label={'Modifica ' + producer.name}
                onClick={() => onEdit(producer)}
              >
                <Pencil size={15} />
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
