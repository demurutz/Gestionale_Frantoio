'use client';
import { useState, useEffect, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Choice } from '@/components/form-fields';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import type { Identity, Company, Role } from '@/lib/access';
import { roleLabels } from '@/lib/access';
type Member = {
  id: string;
  name: string;
  email: string;
  role: Role;
  active: boolean;
};
export default function CompanyAdmin({
  user,
  company,
}: {
  user: Identity;
  company: Company;
}) {
  const [data, setData] = useState<{
      company: Company;
      members: Member[];
    } | null>(null),
    [error, setError] = useState(''),
    [notice, setNotice] = useState(''),
    [busy, setBusy] = useState(false),
    [role, setRole] = useState('operator');
  const load = useCallback(async () => {
    const response = await fetch('/api/company', {
      headers: { 'X-Company-Id': company.id },
      cache: 'no-store',
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error);
    setData(result);
  }, [company.id]);
  useEffect(() => {
    const controller = new AbortController();
    void fetch('/api/company', {
      headers: { 'X-Company-Id': company.id },
      cache: 'no-store',
      signal: controller.signal,
    })
      .then(async (response) => {
        const result = await response.json();
        if (!response.ok) throw new Error(result.error);
        return result;
      })
      .then((result) => {
        if (!controller.signal.aborted) setData(result);
      })
      .catch((error) => {
        if (!controller.signal.aborted) setError(error.message);
      });
    return () => controller.abort();
  }, [company.id]);
  async function save(input: Record<string, unknown>) {
    if (busy) return false;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const response = await fetch('/api/company', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': user.csrf,
          'X-Company-Id': company.id,
        },
        body: JSON.stringify(input),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error);
      await load();
      setNotice('Modifica salvata.');
      return true;
    } catch (error) {
      setError(
        error instanceof Error ? error.message : 'Errore di connessione.',
      );
      return false;
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="settings-content">
      {error && (
        <p role="alert" className="message error">
          {error}
        </p>
      )}
      {notice && <output className="message success">{notice}</output>}
      {data && (
        <>
          <form
            className="auth-card"
            onSubmit={(event) => {
              event.preventDefault();
              void save({
                action: 'company.update',
                ...Object.fromEntries(new FormData(event.currentTarget)),
              });
            }}
          >
            <h2>Dati dell’azienda</h2>
            <label htmlFor="company-admin-1">
              Ragione sociale
              <Input
                id="company-admin-1"
                name="name"
                defaultValue={data.company.name}
                required
                maxLength={160}
              />
            </label>
            <label htmlFor="company-admin-2">
              Codice fiscale / P. IVA
              <Input
                id="company-admin-2"
                name="fiscal_id"
                defaultValue={data.company.fiscal_id}
                maxLength={30}
              />
            </label>
            <label htmlFor="company-admin-3">
              Indirizzo
              <Input
                id="company-admin-3"
                name="address"
                defaultValue={data.company.address}
                maxLength={200}
              />
            </label>
            <Button type="submit" disabled={busy}>
              Salva azienda
            </Button>
          </form>
          <section className="panel">
            <h2>Utenti di {data.company.name}</h2>
            <p>I permessi valgono solo per questa azienda.</p>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Utente</TableHead>
                  <TableHead>Ruolo</TableHead>
                  <TableHead>Stato</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.members.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell>
                      {member.name}
                      <br />
                      {member.email}
                    </TableCell>
                    <TableCell>
                      <Choice
                        label={'Ruolo di ' + member.name}
                        value={member.role}
                        options={Object.entries(roleLabels).map(
                          ([value, label]) => ({ value, label }),
                        )}
                        onChange={(role) => {
                          if (!busy)
                            void save({
                              action: 'member.update',
                              userId: member.id,
                              role,
                              active: member.active,
                            });
                        }}
                      />
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        disabled={busy}
                        onClick={() =>
                          void save({
                            action: 'member.update',
                            userId: member.id,
                            role: member.role,
                            active: !member.active,
                          })
                        }
                      >
                        {member.active
                          ? 'Disabilita accesso'
                          : 'Riattiva accesso'}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </section>
        </>
      )}
      <form
        className="auth-card"
        onSubmit={async (event) => {
          event.preventDefault();
          const form = event.currentTarget;
          if (
            await save({
              action: 'member.create',
              ...Object.fromEntries(new FormData(form)),
              role,
            })
          )
            form.reset();
        }}
      >
        <h2>Aggiungi un utente</h2>
        <p>
          Consegna le credenziali iniziali in modo riservato. L’utente può
          cambiare la password dal proprio account. Le email automatiche non
          sono ancora attive.
        </p>
        <label htmlFor="company-admin-4">
          Nome
          <Input id="company-admin-4" name="name" required maxLength={160} />
        </label>
        <label htmlFor="company-admin-5">
          Email
          <Input
            id="company-admin-5"
            name="email"
            type="email"
            required
            maxLength={254}
          />
        </label>
        <label htmlFor="company-admin-6">
          Password iniziale
          <Input
            id="company-admin-6"
            name="password"
            type="password"
            autoComplete="new-password"
            minLength={12}
            maxLength={128}
            required
          />
        </label>
        <Choice
          label="Ruolo del nuovo utente"
          value={role}
          onChange={setRole}
          options={Object.entries(roleLabels).map(([value, label]) => ({
            value,
            label,
          }))}
        />
        <Button type="submit" disabled={busy}>
          Crea utente
        </Button>
      </form>
    </div>
  );
}
