'use client';
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
export default function PasswordForm({ csrf }: { csrf: string }) {
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  return (
    <form
      className="auth-card"
      onSubmit={async (event) => {
        event.preventDefault();
        if (busy) return;
        setBusy(true);
        setError('');
        const data = new FormData(event.currentTarget);
        if (data.get('password') !== data.get('confirm')) {
          setError('Le nuove password non coincidono.');
          setBusy(false);
          return;
        }
        try {
          const response = await fetch('/api/auth/password', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-CSRF-Token': csrf,
            },
            body: JSON.stringify({
              currentPassword: data.get('current'),
              password: data.get('password'),
            }),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error);
          window.location.assign('/login');
        } catch (error) {
          setError(
            error instanceof Error ? error.message : 'Errore di connessione.',
          );
          setBusy(false);
        }
      }}
    >
      <h2>Cambia password</h2>
      <p>Dopo il cambio dovrai accedere nuovamente su tutti i dispositivi.</p>
      <label htmlFor="password-form-1">
        Password attuale
        <Input
          id="password-form-1"
          name="current"
          type="password"
          autoComplete="current-password"
          required
          maxLength={128}
        />
      </label>
      <label htmlFor="password-form-2">
        Nuova password
        <Input
          id="password-form-2"
          name="password"
          type="password"
          autoComplete="new-password"
          minLength={12}
          maxLength={128}
          required
        />
      </label>
      <label htmlFor="password-form-3">
        Ripeti la nuova password
        <Input
          id="password-form-3"
          name="confirm"
          type="password"
          autoComplete="new-password"
          minLength={12}
          maxLength={128}
          required
        />
      </label>
      {error && <p role="alert">{error}</p>}
      <Button type="submit" disabled={busy}>
        Salva nuova password
      </Button>
    </form>
  );
}
