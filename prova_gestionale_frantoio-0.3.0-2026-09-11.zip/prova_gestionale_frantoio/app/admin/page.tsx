import Link from 'next/link';
import { redirect } from 'next/navigation';
import { pageSession } from '@/lib/page-session';
import CompanyAdmin from '@/components/company-admin';
import AccountControls from '@/components/account-controls';
export const dynamic = 'force-dynamic';
export default async function Admin() {
  const { user, company } = await pageSession();
  if (!company || company.role !== 'admin') redirect('/');
  return (
    <main className="settings-screen">
      <Link prefetch={false} href="/">
        ← Torna al gestionale
      </Link>
      <h1>Azienda e utenti</h1>
      <AccountControls user={user} company={company} />
      <CompanyAdmin user={user} company={company} />
    </main>
  );
}
