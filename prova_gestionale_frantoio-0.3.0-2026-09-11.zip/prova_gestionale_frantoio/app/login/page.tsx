import LoginForm from '@/components/login-form';
export default function Login() {
  return (
    <main className="auth-screen">
      <LoginForm />
    </main>
  );
}
