import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Frantoio · Quaderno operativo',
  description:
    'Conferimenti, molitura, resa e restituzione dell’olio in un unico quaderno operativo.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="it">
      <body className="antialiased">{children}</body>
    </html>
  );
}
