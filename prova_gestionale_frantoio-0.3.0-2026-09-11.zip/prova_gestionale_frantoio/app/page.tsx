import Link from 'next/link';
import Dashboard from '@/components/dashboard';
import { pageSession } from '@/lib/page-session';
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
export default async function Home() {
  const { user, company } = await pageSession();
  if (!company)
    return (
      <main className="auth-screen">
        <h1>Nessuna azienda assegnata</h1>
        <p>Contatta l’amministratore per abilitare il tuo accesso.</p>
        <Link prefetch={false} href="/account">
          Gestisci il tuo account
        </Link>
      </main>
    );
  return <Dashboard user={user} company={company} />;
}
