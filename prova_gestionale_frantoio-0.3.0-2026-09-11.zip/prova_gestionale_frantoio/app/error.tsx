'use client';
import { Button } from '@/components/ui/button';
export default function ErrorPage({ retry }: { retry: () => void }) {
  return (
    <main className="auth-screen">
      <section className="auth-card">
        <h1>Gestionale temporaneamente non disponibile</h1>
        <p>
          Verifica che PostgreSQL sia avviato, poi riprova. Non viene creato un
          archivio vuoto al posto dei dati esistenti.
        </p>
        <Button onClick={() => retry()}>Riprova</Button>
      </section>
    </main>
  );
}
