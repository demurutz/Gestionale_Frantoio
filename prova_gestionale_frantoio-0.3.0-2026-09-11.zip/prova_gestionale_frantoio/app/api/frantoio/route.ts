import { companyTransaction } from '@/db';
import { readData, mutate } from '@/lib/repository';
import { identity, companyId } from '@/lib/auth';
import { authorize } from '@/lib/access';
import { checkCsrf, jsonBody, failure, noStore } from '@/lib/http';
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
export async function GET(request: Request) {
  try {
    const user = await identity(request);
    const data = await companyTransaction(
      user.id,
      companyId(request, user),
      false,
      readData,
    );
    return Response.json(data, { headers: noStore });
  } catch (error) {
    return failure(error);
  }
}
export async function POST(request: Request) {
  try {
    const user = await identity(request);
    checkCsrf(request, user);
    const input = await jsonBody(request);
    const result = await companyTransaction(
      user.id,
      companyId(request, user),
      true,
      async (store, role) => {
        authorize(role, String(input.action));
        return mutate(store, input);
      },
    );
    return Response.json({ result }, { headers: noStore });
  } catch (error) {
    return failure(error);
  }
}
