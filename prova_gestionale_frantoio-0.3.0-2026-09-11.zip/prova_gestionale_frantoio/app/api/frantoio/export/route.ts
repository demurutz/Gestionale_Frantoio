import { companyTransaction } from '@/db';
import { readData } from '@/lib/repository';
import { buildExport } from '@/lib/export';
import { identity, companyId } from '@/lib/auth';
import { failure, noStore } from '@/lib/http';
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
export async function GET(request: Request) {
  try {
    const user = await identity(request),
      id = companyId(request, user);
    const file = await companyTransaction(
      user.id,
      id,
      false,
      async (store) => ({
        ...buildExport(await readData(store)),
        company: user.companies.find((c) => c.id === id),
      }),
    );
    return new Response(JSON.stringify(file, null, 2), {
      headers: {
        ...noStore,
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition':
          'attachment; filename="frantoio-' +
          id +
          '-' +
          file.generated_at.slice(0, 10) +
          '.json"',
      },
    });
  } catch (error) {
    return failure(error);
  }
}
