import { randomUUID } from 'node:crypto';
import { companyTransaction } from '@/db';
import { identity, companyId, hashPassword, passwordField } from '@/lib/auth';
import { InputError, textField, option } from '@/lib/domain';
import { checkCsrf, jsonBody, failure, noStore } from '@/lib/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export async function GET(request: Request) {
  try {
    const user = await identity(request);
    const result = await companyTransaction(
      user.id,
      companyId(request, user),
      false,
      async (store, role) => {
        if (role !== 'admin')
          throw new InputError('Accesso riservato agli amministratori.', 403);
        const company = await store.client.query(
          'SELECT id,name,fiscal_id,address FROM companies WHERE id=$1',
          [store.tenantId],
        );
        const members = await store.client.query(
          'SELECT u.id,u.name,u.email,m.role,m.active FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.company_id=$1 ORDER BY u.name',
          [store.tenantId],
        );
        return { company: company.rows[0], members: members.rows };
      },
    );
    return Response.json(result, { headers: noStore });
  } catch (error) {
    return failure(error);
  }
}
export async function POST(request: Request) {
  try {
    const user = await identity(request);
    checkCsrf(request, user);
    const input = await jsonBody(request),
      id = companyId(request, user);
    if (user.companies.find((c) => c.id === id)?.role !== 'admin')
      throw new InputError('Accesso riservato agli amministratori.', 403);
    const passwordHash =
      input.action === 'member.create'
        ? await hashPassword(passwordField(input.password, 'Password iniziale'))
        : null;
    await companyTransaction(user.id, id, true, async (store, role) => {
      if (role !== 'admin')
        throw new InputError('Accesso riservato agli amministratori.', 403);
      const client = store.client;
      let details: Record<string, unknown> = {};
      if (input.action === 'company.update') {
        const name = textField(input.name, 'Ragione sociale');
        const fiscalId = textField(
          input.fiscal_id ?? '',
          'Codice fiscale / P. IVA',
          30,
          true,
        );
        const address = textField(input.address ?? '', 'Indirizzo', 200, true);
        await client.query(
          'UPDATE companies SET name=$1,fiscal_id=$2,address=$3 WHERE id=$4',
          [name, fiscalId, address, id],
        );
        details = { name, fiscal_id: fiscalId, address };
      } else if (input.action === 'member.create') {
        const email = textField(input.email, 'Email', 254).toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
          throw new InputError('Email non valida.');
        if (
          (await client.query('SELECT 1 FROM users WHERE email=$1', [email]))
            .rowCount
        )
          throw new InputError(
            'Indirizzo già registrato. L’associazione di un account esistente richiede l’amministratore della piattaforma.',
            409,
          );
        const name = textField(input.name, 'Nome'),
          memberRole = option(
            input.role,
            ['admin', 'operator', 'viewer'] as const,
            'Ruolo',
          ),
          newId = randomUUID();
        await client.query(
          'INSERT INTO users(id,email,name,password_hash) VALUES($1,$2,$3,$4)',
          [newId, email, name, passwordHash],
        );
        await client.query(
          'INSERT INTO memberships(company_id,user_id,role) VALUES($1,$2,$3)',
          [id, newId, memberRole],
        );
        details = { user_id: newId, role: memberRole };
      } else if (input.action === 'member.update') {
        const target = textField(input.userId, 'Utente', 36),
          memberRole = option(
            input.role,
            ['admin', 'operator', 'viewer'] as const,
            'Ruolo',
          );
        if (typeof input.active !== 'boolean')
          throw new InputError('Stato utente non valido.');
        const previous = (
          await client.query(
            'SELECT role,active FROM memberships WHERE company_id=$1 AND user_id=$2',
            [id, target],
          )
        ).rows[0];
        if (!previous) throw new InputError('Utente non disponibile.', 404);
        if (
          previous.active &&
          previous.role === 'admin' &&
          (!input.active || memberRole !== 'admin')
        ) {
          const count = await client.query(
            "SELECT count(*)::int AS n FROM memberships WHERE company_id=$1 AND active AND role='admin'",
            [id],
          );
          if (count.rows[0].n <= 1)
            throw new InputError(
              'Deve rimanere almeno un amministratore attivo.',
              409,
            );
        }
        await client.query(
          'UPDATE memberships SET role=$1,active=$2 WHERE company_id=$3 AND user_id=$4',
          [memberRole, input.active, id, target],
        );
        details = {
          user_id: target,
          before: previous,
          role: memberRole,
          active: input.active,
        };
      } else throw new InputError('Operazione non valida.');
      await client.query(
        'INSERT INTO security_events(company_id,actor_id,action,details) VALUES($1,$2,$3,$4)',
        [id, user.id, input.action, JSON.stringify(details)],
      );
    });
    return Response.json({ ok: true }, { headers: noStore });
  } catch (error) {
    return failure(error);
  }
}
