import { pool, transaction } from '@/db';
import {
  identity,
  login,
  cookie,
  cookieValue,
  sessionCookie,
  companyCookie,
  digest,
  hashPassword,
  verifyPassword,
  passwordField,
} from '@/lib/auth';
import { checkOrigin, checkCsrf, jsonBody, failure, noStore } from '@/lib/http';
import { config } from '@/lib/config';
import { InputError } from '@/lib/domain';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
type Context = { params: Promise<{ action: string }> };
export async function GET(request: Request, { params }: Context) {
  try {
    if ((await params).action !== 'session')
      throw new InputError('Risorsa non trovata.', 404);
    return Response.json(await identity(request), { headers: noStore });
  } catch (error) {
    return failure(error);
  }
}
export async function POST(request: Request, { params }: Context) {
  try {
    const { action } = await params;
    checkOrigin(request);
    if (action === 'login') {
      const body = await jsonBody(request),
        token = await login(body.email, body.password);
      return Response.json(
        { ok: true },
        {
          headers: {
            ...noStore,
            'Set-Cookie': cookie(
              sessionCookie,
              token,
              config().sessionHours * 3600,
            ),
          },
        },
      );
    }
    const user = await identity(request);
    checkCsrf(request, user);
    if (action === 'logout') {
      await pool().query('DELETE FROM sessions WHERE token_hash=$1', [
        digest(cookieValue(request, sessionCookie)),
      ]);
      return Response.json(
        { ok: true },
        { headers: { ...noStore, 'Set-Cookie': cookie(sessionCookie, '', 0) } },
      );
    }
    const body = await jsonBody(request);
    if (action === 'switch') {
      if (!user.companies.some((c) => c.id === body.companyId))
        throw new InputError('Azienda non accessibile.', 403);
      return Response.json(
        { ok: true },
        {
          headers: {
            ...noStore,
            'Set-Cookie': cookie(
              companyCookie,
              String(body.companyId),
              config().sessionHours * 3600,
            ),
          },
        },
      );
    }
    if (action === 'password') {
      const current = passwordField(body.currentPassword, 'Password attuale');
      const password = passwordField(body.password, 'Nuova password');
      const record = await pool().query(
        'SELECT password_hash FROM users WHERE id=$1',
        [user.id],
      );
      const oldHash = record.rows[0]?.password_hash;
      if (!oldHash || !(await verifyPassword(current, oldHash)))
        throw new InputError('Password attuale non valida.', 400);
      const hash = await hashPassword(password);
      await transaction(async (client) => {
        const changed = await client.query(
          'UPDATE users SET password_hash=$1 WHERE id=$2 AND password_hash=$3',
          [hash, user.id, oldHash],
        );
        if (!changed.rowCount)
          throw new InputError(
            'Credenziali già modificate. Accedi nuovamente.',
            409,
          );
        await client.query('DELETE FROM sessions WHERE user_id=$1', [user.id]);
        await client.query(
          'INSERT INTO security_events(actor_id,action) VALUES($1,$2)',
          [user.id, 'password.changed'],
        );
      });
      return Response.json(
        { ok: true },
        { headers: { ...noStore, 'Set-Cookie': cookie(sessionCookie, '', 0) } },
      );
    }
    throw new InputError('Operazione non trovata.', 404);
  } catch (error) {
    return failure(error);
  }
}
