import Link from 'next/link';
import { pageSession } from '@/lib/page-session';
import AccountControls from '@/components/account-controls';
import PasswordForm from '@/components/password-form';
export const dynamic = 'force-dynamic';
export default async function Account() {
  const { user, company } = await pageSession();
  return (
    <main className="settings-screen">
      <Link prefetch={false} href="/">
        ← Torna al gestionale
      </Link>
      <h1>Il tuo account</h1>
      <AccountControls user={user} company={company} />
      <PasswordForm csrf={user.csrf} />
    </main>
  );
}
